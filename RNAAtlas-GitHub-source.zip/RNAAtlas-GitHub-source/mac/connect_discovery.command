#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -x .venv-web/bin/python ]]; then
  echo "Start RNA Atlas once before reconnecting."
  exit 1
fi
.venv-web/bin/python personal_launcher.py --connect
