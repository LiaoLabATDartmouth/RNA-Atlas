import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from app.config import PortalSettings
from app.hpc import (
    APPROVED_REMOTE_ROOT,
    APPROVED_SSH_HOST,
    HpcServiceClient,
    HpcServiceError,
    HpcValidationError,
)


class HpcServiceClientTests(unittest.TestCase):
    def make_client(self, mount_root):
        return HpcServiceClient(
            PortalSettings(
                execution_backend="mounted",
                email="researcher@dartmouth.edu",
                ssh_host=APPROVED_SSH_HOST,
                remote_root=APPROVED_REMOTE_ROOT,
                mount_root=Path(mount_root),
                kerberos_cache=None,
                ssh_control_path=None,
            )
        )

    def test_resolves_only_paths_inside_mounted_service_root(self):
        with tempfile.TemporaryDirectory() as directory:
            client = self.make_client(directory)
            expected = (Path(directory) / "projects" / "demo" / "results.zip").resolve()
            resolved = client.resolve_mounted_path(
                APPROVED_REMOTE_ROOT + "/projects/demo/results.zip"
            )
            self.assertEqual(resolved, expected)
            with self.assertRaises(HpcServiceError):
                client.resolve_mounted_path("/tmp/outside.zip")

    def test_resolves_only_paths_inside_remote_service_root(self):
        with tempfile.TemporaryDirectory() as directory:
            client = self.make_client(directory)
            expected = APPROVED_REMOTE_ROOT + "/projects/demo/results.zip"
            self.assertEqual(client.resolve_remote_path(expected), expected)
            with self.assertRaises(HpcServiceError):
                client.resolve_remote_path("/tmp/outside.zip")

    def test_slurm_download_transfers_to_temporary_file(self):
        with tempfile.TemporaryDirectory() as directory:
            known_hosts = Path(directory) / "known_hosts"
            known_hosts.write_text("discovery ssh-ed25519 test\n")
            client = HpcServiceClient(
                PortalSettings(
                    execution_backend="slurm",
                    email="researcher@dartmouth.edu",
                    ssh_host=APPROVED_SSH_HOST,
                    remote_root=APPROVED_REMOTE_ROOT,
                    mount_root=Path(directory) / "not-mounted",
                    kerberos_cache=None,
                    ssh_control_path=None,
                    ssh_known_hosts=str(known_hosts),
                )
            )
            remote_path = APPROVED_REMOTE_ROOT + "/projects/demo/results.zip"
            payload = {"path": remote_path, "filename": "results.zip", "size": 4}

            def transfer(*_, **kwargs):
                kwargs["stdout"].write(b"data")
                return subprocess.CompletedProcess(args=["ssh"], returncode=0, stdout=None, stderr=b"")

            with patch.object(client, "_read", return_value=payload), patch(
                "app.hpc.subprocess.run", side_effect=transfer,
            ):
                result = client.download("researcher@dartmouth.edu", "job-1")
            local_path = Path(result["local_path"])
            try:
                self.assertTrue(result["temporary"])
                self.assertEqual(local_path.read_bytes(), b"data")
            finally:
                local_path.unlink(missing_ok=True)

    def test_rejects_unapproved_ssh_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            settings = PortalSettings(
                execution_backend="slurm",
                email="researcher@dartmouth.edu",
                ssh_host="someone@example.org",
                remote_root=APPROVED_REMOTE_ROOT,
                mount_root=Path(directory),
                kerberos_cache=None,
                ssh_control_path=None,
            )
            with self.assertRaises(HpcServiceError):
                HpcServiceClient(settings)

    def test_parses_json_after_scheduler_messages(self):
        payload = HpcServiceClient._parse_json('module notice\n{"status":"ok"}\n')
        self.assertEqual(payload, {"status": "ok"})

    def test_existing_ssh_connection_does_not_start_another_master(self):
        with tempfile.TemporaryDirectory() as directory:
            known_hosts = Path(directory) / "known_hosts"
            known_hosts.write_text("discovery ssh-ed25519 test\n")
            settings = PortalSettings(
                execution_backend="slurm", email="researcher@dartmouth.edu",
                ssh_host=APPROVED_SSH_HOST, remote_root=APPROVED_REMOTE_ROOT,
                mount_root=Path(directory), kerberos_cache=None,
                ssh_control_path="/tmp/test-rnaseq-%C", ssh_known_hosts=str(known_hosts),
            )
            client = HpcServiceClient(settings)
            with patch.object(client, "ssh_connection_ready", return_value=True), patch(
                "app.hpc.subprocess.run",
            ) as remote:
                self.assertTrue(client.connect())
                remote.assert_not_called()

    def test_personal_connection_checks_remote_ticket_and_handles_timeout(self):
        with tempfile.TemporaryDirectory() as directory:
            client = HpcServiceClient(PortalSettings(
                execution_backend="slurm", email="f123abc@dartmouth.edu",
                ssh_host="f123abc@discovery.dartmouth.edu",
                remote_root="/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas",
                mount_root=Path(directory), kerberos_cache=None, ssh_control_path="/tmp/member.sock",
                portal_mode="personal", shared_root=APPROVED_REMOTE_ROOT,
            ))
            with patch("app.hpc.subprocess.run", return_value=subprocess.CompletedProcess(
                args=["ssh"], returncode=0,
            )) as remote:
                self.assertTrue(client.ssh_connection_ready())
            self.assertEqual(remote.call_count, 2)
            self.assertIn("-O", remote.call_args_list[0].args[0])
            self.assertIn("klist -s", remote.call_args.args[0][-1])
            self.assertIn("PubkeyAuthentication=no", remote.call_args.args[0])
            self.assertIn("PasswordAuthentication=no", remote.call_args.args[0])
            with patch("app.hpc.subprocess.run", side_effect=subprocess.TimeoutExpired("ssh", 10)):
                self.assertFalse(client.ssh_connection_ready())

    def test_personal_connection_without_socket_fails_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            client = HpcServiceClient(PortalSettings(
                execution_backend="slurm", email="f123abc@dartmouth.edu",
                ssh_host="f123abc@discovery.dartmouth.edu",
                remote_root="/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas",
                mount_root=Path(directory), kerberos_cache=None, ssh_control_path=None,
                portal_mode="personal", shared_root=APPROVED_REMOTE_ROOT,
            ))
            with patch("app.hpc.subprocess.run") as remote:
                self.assertFalse(client.ssh_connection_ready())
                with self.assertRaisesRegex(HpcServiceError, "not configured"):
                    client._ssh_command()
            remote.assert_not_called()

    def test_maps_remote_value_error_to_validation_error(self):
        with tempfile.TemporaryDirectory() as directory:
            client = self.make_client(directory)
            completed = subprocess.CompletedProcess(
                args=["service"], returncode=1,
                stdout='{"error":"missing GT","error_type":"ValueError"}\n', stderr="",
            )
            with patch("app.hpc.subprocess.run", return_value=completed):
                with self.assertRaisesRegex(HpcValidationError, "missing GT"):
                    client._run(["service"])


if __name__ == "__main__":
    unittest.main()
