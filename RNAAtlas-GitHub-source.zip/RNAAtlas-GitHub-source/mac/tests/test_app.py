import unittest
from dataclasses import replace
from unittest.mock import patch

from fastapi.testclient import TestClient

from app import main


class FakeHpcClient:
    submission_enabled = False

    def __init__(self):
        self.project_request = None
        self.reference_request = None
        self.genotype_request = None
        self.intake_request = None

    def ssh_connection_ready(self):
        return False

    def connect(self):
        return self.ssh_connection_ready()

    def snapshot(self, email):
        return {
            "service_root": "/Volumes/LiaoC/Service_Account/RNAseq_atlas",
            "user": {
                "email": email,
                "display_name": "Test User",
                "status": "approved",
                "is_admin": True,
            },
            "projects": [],
            "references": [],
            "jobs": [],
            "storage": {"total_bytes": 100, "used_bytes": 50, "free_bytes": 50, "percent_used": 50.0},
            "trinity_ready": False,
            "qc_ready": True,
            "slurm_ready": False,
        }

    def project(self, email, name, reference_id=""):
        self.project_request = (email, name, reference_id)
        return {"project": name, "reference_id": reference_id}

    def prepare_intake(self, request):
        self.intake_request = request
        return {"project": request["project"], "directory": "/mounted/user_data/owner/Example"}

    def attach_intake(self, request):
        self.intake_request = request
        return {"project": request["project"], "sample_count": 2}

    def intake_preview(self, email, project):
        return {
            "dataset": project, "metadata_file": "/private/intake/meta_data/sample_sheet.tsv",
            "sample_count": 2, "conditions": ["control", "treated"],
            "samples": [{"sample_id": "S1", "condition": "control"}], "truncated": False,
        }

    def datasets(self, email):
        return {"directory": "/private/datasets", "datasets": [{"name": "experiment1"}]}

    def project_folders(self, email):
        return {"folders": [{"name": "experiment1", "path": "/private/projects/experiment1", "kind": "prepared"}]}

    def prepared_project_preview(self, email, name):
        self.project_request = (email, name, "preview")
        return {"project": name, "sample_count": 2, "errors": []}

    def dataset_preview(self, email, dataset):
        return {
            "dataset": dataset, "metadata_file": "/private/datasets/experiment1/meta_data/sample_sheet.tsv",
            "sample_count": 2, "conditions": ["control", "treated"],
            "samples": [{"sample_id": "S1", "condition": "control"}], "truncated": False,
        }

    def attach_dataset(self, request):
        self.intake_request = request
        return {"project": request["project"], "dataset": request["dataset"], "sample_count": 2}

    def users(self, admin_email):
        return {"users": [{"email": admin_email, "status": "approved"}]}

    def stage_reference(self, request):
        self.reference_request = request
        return {"reference_id": request["reference_id"], "directory": "/mounted/reference_inputs/test"}

    def upload_ase_genotypes(self, email, project_name, reference_id, vcf_stream, vcf_filename, sample_map_stream=None):
        self.genotype_request = {
            "email": email,
            "project": project_name,
            "reference_id": reference_id,
            "vcf_filename": vcf_filename,
            "vcf_bytes": vcf_stream.read(),
            "sample_map_bytes": sample_map_stream.read() if sample_map_stream else None,
        }
        return {"project": project_name, "ase_genotypes": {"ready": True, "vcf_filename": vcf_filename}}


class MacPortalApiTests(unittest.TestCase):
    def setUp(self):
        self.fake_hpc = FakeHpcClient()
        self.hpc_patch = patch.object(main, "HPC", self.fake_hpc)
        self.token_patch = patch.object(main, "APP_TOKEN", "test-portal-token")
        self.hpc_patch.start()
        self.token_patch.start()
        self.client = TestClient(main.app, headers={"x-rnaseq-token": "test-portal-token"})

    def tearDown(self):
        self.client.close()
        self.token_patch.stop()
        self.hpc_patch.stop()

    def test_api_rejects_missing_token(self):
        response = self.client.get("/api/snapshot", headers={"x-rnaseq-token": "invalid"})
        self.assertEqual(response.status_code, 401)

    def test_discovery_stays_disconnected_until_folder_connection(self):
        settings = replace(main.SETTINGS, execution_backend="slurm")
        self.fake_hpc.submission_enabled = True
        with patch.object(main, "SETTINGS", settings), patch.object(
            self.fake_hpc, "ssh_connection_ready", return_value=True,
        ) as connection:
            self.assertFalse(self.client.get("/api/config").json()["connected"])
            self.assertEqual(self.client.get("/api/snapshot").status_code, 409)
            self.assertEqual(self.client.post("/api/connect").status_code, 200)
            self.assertTrue(self.client.get("/api/config").json()["connected"])
            connection.return_value = False
            unavailable = self.client.get("/api/config").json()
            self.assertTrue(unavailable["connected"])
            self.assertFalse(unavailable["ssh_ready"])
            self.assertEqual(self.client.get("/api/project-folders").status_code, 200)
            self.assertEqual(self.client.post("/api/disconnect").status_code, 200)
            self.assertEqual(self.client.get("/api/project-folders").status_code, 409)

    def test_failed_discovery_connection_does_not_unlock_folders(self):
        settings = replace(main.SETTINGS, execution_backend="slurm")
        self.fake_hpc.submission_enabled = True
        with patch.object(main, "SETTINGS", settings):
            self.assertEqual(self.client.post("/api/connect").status_code, 503)
            self.assertFalse(self.client.get("/api/config").json()["connected"])
            self.assertEqual(self.client.get("/api/project-folders").status_code, 409)

    def test_dataset_metadata_preview_is_authenticated(self):
        response = self.client.get("/api/datasets/experiment1/preview")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["sample_count"], 2)
        self.assertEqual(self.client.get(
            "/api/datasets/experiment1/preview", headers={"x-rnaseq-token": "invalid"},
        ).status_code, 401)

    def test_project_folder_browser_is_authenticated(self):
        response = self.client.get("/api/project-folders")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["folders"][0]["name"], "experiment1")
        self.assertEqual(self.client.get(
            "/api/project-folders", headers={"x-rnaseq-token": "invalid"},
        ).status_code, 401)

    def test_intake_metadata_preview_is_authenticated(self):
        response = self.client.get("/api/intake/Example/preview")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["sample_count"], 2)
        self.assertEqual(self.client.get(
            "/api/intake/Example/preview", headers={"x-rnaseq-token": "invalid"},
        ).status_code, 401)

    def test_simplified_page_exposes_four_modules_and_metadata(self):
        page = self.client.get("/")
        self.assertEqual(page.status_code, 200)
        for phrase in (
            "Load RNA-seq data and metadata", "Open project folder", "Load data",
            "De novo transcriptome", "sample_sheet_template.tsv", "read-preparation-intro",
            "genotype_VCF/", "Species biological ploidy default", "Trinity 2.15.2", "DESeq2 1.46.0",
            "bcftools 1.24", "GATK ASEReadCounter 4.6.2.0",
        ):
            self.assertIn(phrase, page.text)
        self.assertNotIn("Add a reference genome", page.text)
        self.assertNotIn("Non-reference RNA screen", page.text)
        self.assertNotIn("02 · Reference", page.text)
        self.assertNotIn("02 · Metadata", page.text)
        self.assertNotIn("Resume an existing analysis", page.text)
        self.assertNotIn("Previous processing", page.text)
        self.assertNotIn('id="sample-ploidy"', page.text)
        self.assertNotIn("Sample ploidy affects SNV and ASE", page.text)
        javascript = self.client.get("/static/app.js").text
        self.assertIn("fungidb71_candida_sc5314", javascript)
        self.assertIn("fungidb71_af293", javascript)
        self.assertIn("species: typically diploid (2n) · reference: haploid A-only (no B)", javascript)
        self.assertIn("species: haploid (1n) · reference: haploid assembly", javascript)
        self.assertIn("ploidy: biologicalPloidy()", javascript)
        self.assertNotIn("elements.sample_ploidy", javascript)
        self.assertNotIn("Showing only folders available to this single-user service session", javascript)
        self.assertNotIn("Ready · click to add", page.text)
        self.assertNotIn("new-project-organism", page.text)
        self.assertNotIn('class="allocation-card"', page.text)
        self.assertNotIn('class="side-column"', page.text)
        self.assertNotIn("Sample snapshot", page.text)
        self.assertIn('id="project-history"', page.text)
        self.assertNotIn('id="metadata-path"', page.text)
        self.assertIn('id="raw-data-path"', page.text)
        self.assertIn('id="sample-sheet-path"', page.text)
        self.assertIn('id="project-root-path"', page.text)
        self.assertIn('id="data-guide"', page.text)
        self.assertIn('id="reconnect-discovery"', page.text)
        self.assertIn('"Discovery disconnected"', javascript)
        self.assertIn('state.config = await api("/api/config")', javascript)
        self.assertIn('id="service-workspace-notice" hidden', page.text)
        self.assertIn("Prepare one project folder first", page.text)
        self.assertIn('id="project-output-path"', page.text)
        self.assertIn("The folder name becomes the project name", javascript)
        self.assertIn('`${root}/projects/`', javascript)
        self.assertIn('`${projectRoot}<project_folder>`', javascript)
        self.assertNotIn('`${projectRoot}${safeName}`', javascript)
        self.assertIn('`${folder}/datasets/meta_data/sample_sheet.tsv`', javascript)
        self.assertIn('`${folder}/datasets/raw_data/`', javascript)
        self.assertIn('`${folder}/results/<module>/<job-id>/`', javascript)
        self.assertNotIn('The included <code>Calbicans_WT_YL_HL</code> folder is an optional example', page.text)
        self.assertNotIn('api("/api/intake/from-dataset"', javascript)
        self.assertIn('elements.service_workspace_notice.hidden = personal', javascript)
        self.assertNotIn("once to create its folder", page.text)
        self.assertIn("full-file FASTQ validation runs when analysis starts", page.text)
        self.assertIn('id="memory-gb"', page.text)
        self.assertIn('max="32"', page.text)
        self.assertIn('max="256"', page.text)
        self.assertIn('id="walltime-days"', page.text)
        self.assertIn('id="walltime-hours"', page.text)
        self.assertNotIn('id="previous-results"', page.text)
        self.assertNotIn("Choose the RNA-seq results you need", page.text)
        self.assertNotIn("Applies to STAR and the selected module", page.text)
        script = self.client.get("/static/app.js").text
        self.assertNotIn("Metadata: <code>", script)
        self.assertIn("memory_gb: Number(elements.memory_gb.value)", script)
        self.assertIn('walltime_hours: walltimeHours', script)
        self.assertIn('elements.walltime_days, elements.walltime_hours].forEach', script)
        self.assertEqual(page.text.count('name="analysis-module" type="radio"'), 4)
        for control in ("de-padj-cutoff", "de-log2fc-cutoff", "library-strandedness",
                        "snv-min-depth", "snv-min-quality", "ase-min-depth", "ase-min-allele-count"):
            self.assertIn('id="{}"'.format(control), page.text)
        self.assertIn('strandedness: elements.library_strandedness.value', script)

    def test_job_model_bounds_free_tier_resources(self):
        request = main.JobRequest(project="Example", reference_id="fungus_v1", threads=32, memory_gb=256, walltime_hours=720)
        self.assertEqual((request.threads, request.memory_gb, request.walltime_hours), (32, 256, 720))
        for resources in ({"threads": 33}, {"memory_gb": 257}, {"memory_gb": 7},
                          {"walltime_hours": 0}, {"walltime_hours": 721},
                          {"threads": 1.5}, {"memory_gb": True}, {"walltime_hours": 2.5},
                          {"ploidy": 0}, {"ploidy": 17}, {"ploidy": 2.5}):
            with self.assertRaises(ValueError):
                main.JobRequest(project="Example", reference_id="fungus_v1", **resources)

    def test_job_rejects_multiple_modules(self):
        response = self.client.post("/api/jobs", json={
            "project": "Example", "reference_id": "candida_test",
            "run_differential_expression": True, "run_rna_variants": True,
        })
        self.assertEqual(response.status_code, 400)
        self.assertIn("exactly one", response.json()["detail"])

    def test_api_fails_closed_when_server_token_is_missing(self):
        with patch.object(main, "APP_TOKEN", ""):
            response = self.client.get("/api/snapshot")
        self.assertEqual(response.status_code, 401)

    def test_private_token_mode_ignores_forwarded_identity(self):
        response = self.client.get(
            "/api/snapshot",
            headers={"x-forwarded-email": "spoofed-admin@dartmouth.edu"},
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["user"]["email"], main.SETTINGS.email)

    def test_health_and_snapshot(self):
        health = self.client.get("/healthz")
        self.assertEqual(health.status_code, 200)
        snapshot = self.client.get("/api/snapshot")
        self.assertEqual(snapshot.status_code, 200)
        self.assertEqual(snapshot.json()["user"]["email"], main.SETTINGS.email)

    def test_project_request_carries_user_and_reference(self):
        response = self.client.get(
            "/api/projects/Calbicans_WT_YL_HL",
            params={"reference_id": "candida_reference"},
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            self.fake_hpc.project_request,
            (main.SETTINGS.email, "Calbicans_WT_YL_HL", "candida_reference"),
        )

    def test_intake_requests_carry_authenticated_identity(self):
        prepared = self.client.post("/api/intake/prepare", json={"project": "Example"})
        self.assertEqual(prepared.status_code, 201)
        self.assertEqual(self.fake_hpc.intake_request, {"email": main.SETTINGS.email, "project": "Example"})
        attached = self.client.post("/api/intake/attach", json={"project": "Example"})
        self.assertEqual(attached.status_code, 200)
        self.assertEqual(attached.json()["sample_count"], 2)
        bad = self.client.post("/api/intake/prepare", json={"project": "../Elsewhere"})
        self.assertEqual(bad.status_code, 422)

    def test_personal_prepared_project_preview_uses_authenticated_identity(self):
        with patch.object(main, "SETTINGS", replace(main.SETTINGS, portal_mode="personal")):
            folders = self.client.get("/api/project-folders")
            self.assertEqual(folders.json()["folders"][0]["path"], "/private/projects/experiment1")
            preview = self.client.get("/api/projects/experiment1/preview")
            self.assertEqual(preview.status_code, 200)
            self.assertEqual(preview.json()["sample_count"], 2)
            self.assertEqual(self.fake_hpc.project_request, (main.SETTINGS.email, "experiment1", "preview"))
            invalid_preview = self.client.get("/api/projects/../preview")
            self.assertNotEqual(invalid_preview.status_code, 200)

    def test_legacy_personal_dataset_routes_use_authenticated_identity(self):
        with patch.object(main, "SETTINGS", replace(main.SETTINGS, portal_mode="personal")):
            listed = self.client.get("/api/datasets")
            self.assertEqual(listed.json()["datasets"][0]["name"], "experiment1")
            attached = self.client.post(
                "/api/intake/from-dataset", json={"project": "Example", "dataset": "experiment1"},
            )
            self.assertEqual(attached.status_code, 200)
            self.assertEqual(self.fake_hpc.intake_request, {
                "email": main.SETTINGS.email, "project": "Example", "dataset": "experiment1",
            })
            invalid = self.client.post(
                "/api/intake/from-dataset", json={"project": "Example", "dataset": "../Other"},
            )
            self.assertEqual(invalid.status_code, 422)

    def test_proxy_mode_rejects_browser_token_and_unverified_identity(self):
        settings = replace(main.SETTINGS, trust_email_header=True, proxy_secret="proxy-only-secret")
        with patch.object(main, "SETTINGS", settings):
            direct = self.client.get("/api/snapshot", headers={"x-forwarded-email": "member@dartmouth.edu"})
            self.assertEqual(direct.status_code, 401)
            missing_identity = self.client.get("/api/snapshot", headers={"x-rnaseq-proxy-secret": "proxy-only-secret"})
            self.assertEqual(missing_identity.status_code, 401)
            verified = self.client.get("/api/snapshot", headers={
                "x-rnaseq-proxy-secret": "proxy-only-secret", "x-forwarded-email": "member@dartmouth.edu",
            })
            self.assertEqual(verified.status_code, 200)
            self.assertEqual(verified.json()["user"]["email"], "member@dartmouth.edu")
            page = self.client.get("/", headers={
                "x-rnaseq-proxy-secret": "proxy-only-secret", "x-forwarded-email": "member@dartmouth.edu",
            })
            self.assertEqual(page.status_code, 200)
            self.assertNotIn("set-cookie", page.headers)
            self.assertIn("Validate and import data", page.text)
            shared_link = self.client.get("/?token=test-portal-token", follow_redirects=False)
            self.assertEqual(shared_link.status_code, 401)
        with patch.object(main, "SETTINGS", replace(settings, proxy_secret="")):
            missing_secret = self.client.get("/api/snapshot", headers={
                "x-rnaseq-proxy-secret": "proxy-only-secret", "x-forwarded-email": "member@dartmouth.edu",
            })
            self.assertEqual(missing_secret.status_code, 401)

    def test_config_marks_mounted_preview_non_submitting(self):
        response = self.client.get("/api/config")
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.json()["submission_enabled"])

    def test_reference_staging_carries_authenticated_email(self):
        response = self.client.post(
            "/api/references/stage",
            json={
                "reference_id": "fungus_v1", "label": "Fungus v1", "organism": "Fungus",
                "assembly": "v1", "recommended_ploidy": 2, "max_read_length": 150,
            },
        )
        self.assertEqual(response.status_code, 201)
        self.assertEqual(self.fake_hpc.reference_request["email"], main.SETTINGS.email)

    def test_reference_model_restricts_prokka_to_bacteria(self):
        request = main.ReferenceRequest(
            reference_id="bacterium_v1", annotation_mode="prokka", prokka_kingdom="Bacteria",
            confirm_bacterial_genome=True,
        )
        self.assertEqual(request.annotation_mode, "prokka")
        self.assertTrue(request.confirm_bacterial_genome)
        with self.assertRaises(ValueError):
            main.ReferenceRequest(
                reference_id="archaeon_v1", annotation_mode="prokka", prokka_kingdom="Archaea",
            )

    def test_ase_vcf_upload_carries_project_reference_and_optional_map(self):
        response = self.client.post(
            "/api/projects/Example/ase-genotypes",
            data={"reference_id": "fungus_v1"},
            files={
                "vcf_file": ("calls.vcf.gz", b"compressed-vcf", "application/gzip"),
                "sample_map_file": ("samples.tsv", b"sample_id\tvcf_sample_id\n", "text/tab-separated-values"),
            },
        )
        self.assertEqual(response.status_code, 201)
        self.assertEqual(self.fake_hpc.genotype_request["project"], "Example")
        self.assertEqual(self.fake_hpc.genotype_request["reference_id"], "fungus_v1")
        self.assertEqual(self.fake_hpc.genotype_request["vcf_filename"], "calls.vcf.gz")
        self.assertEqual(self.fake_hpc.genotype_request["sample_map_bytes"], b"sample_id\tvcf_sample_id\n")

    def test_ase_vcf_upload_rejects_non_vcf_file(self):
        response = self.client.post(
            "/api/projects/Example/ase-genotypes",
            data={"reference_id": "fungus_v1"},
            files={"vcf_file": ("calls.txt", b"not-vcf", "text/plain")},
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn(".vcf", response.json()["detail"])

    def test_job_model_accepts_independent_ase_source(self):
        request = main.JobRequest(
            project="Example", reference_id="fungus_v1", run_rna_variants=False,
            run_ase=True, ase_source="external_dna_vcf",
        )
        self.assertFalse(request.run_rna_variants)
        self.assertEqual(request.ase_source, "external_dna_vcf")

    def test_job_model_accepts_automatic_and_custom_preprocessing(self):
        automatic = main.JobRequest(project="Example", reference_id="fungus_v1", trimming_mode="auto")
        self.assertEqual(automatic.library_type, "standard_bulk")
        custom = main.JobRequest(
            project="Example", reference_id="fungus_v1", trimming_mode="custom", library_type="custom_bulk",
            library_prep="Lab protocol v2", adapter_handling="provided",
            adapter_read1="ACGTACGT", adapter_read2="TGCATGCA", trim_front_read1=8,
        )
        self.assertEqual(custom.library_prep, "Lab protocol v2")
        self.assertEqual(custom.trim_front_read1, 8)

    def test_job_model_validates_discovery_parameters(self):
        request = main.JobRequest(
            project="Example", reference_id="fungus_v1", run_trinity=True, run_unmapped_rna=True,
            trinity_min_contig_length=250, unmapped_rna_min_pairs=5000,
            unmapped_rna_host_min_identity=92.5, candidate_cross_min_identity=97.0,
            candidate_cross_min_shorter_coverage=85.0,
        )
        self.assertEqual(request.trinity_min_contig_length, 250)
        self.assertEqual(request.candidate_cross_min_identity, 97.0)
        with self.assertRaises(ValueError):
            main.JobRequest(
                project="Example", reference_id="fungus_v1", candidate_cross_min_identity=101,
            )

    def test_job_model_validates_result_changing_module_settings(self):
        request = main.JobRequest(
            project="Example", reference_id="fungus_v1", strandedness="unstranded",
            padj_cutoff=0.01, log2fc_cutoff=1.0, variant_min_depth=15,
            variant_min_quality=25.5, ase_min_depth=30, ase_min_allele_count=0,
        )
        self.assertEqual(request.ase_min_allele_count, 0)
        self.assertEqual(request.strandedness, "unstranded")
        for setting in ({"padj_cutoff": 0}, {"padj_cutoff": float("nan")},
                        {"log2fc_cutoff": -1}, {"variant_min_depth": 1.5},
                        {"variant_min_quality": float("inf")}, {"ase_min_depth": 0},
                        {"ase_min_allele_count": -1}):
            with self.subTest(setting=setting), self.assertRaises(ValueError):
                main.JobRequest(project="Example", reference_id="fungus_v1", **setting)

    def test_job_api_forwards_selected_thresholds(self):
        requested = {
            "project": "Example", "reference_id": "fungus_v1",
            "padj_cutoff": 0.01, "log2fc_cutoff": 1.0,
            "variant_min_depth": 15, "variant_min_quality": 25.5,
            "ase_min_depth": 30, "ase_min_allele_count": 0,
            "strandedness": "unstranded",
        }
        with patch.object(self.fake_hpc, "submit", return_value={"job_id": "prepared"}, create=True) as submit:
            response = self.client.post("/api/jobs", json=requested)
        self.assertEqual(response.status_code, 201)
        for key, value in requested.items():
            self.assertEqual(submit.call_args.args[0][key], value)

    def test_results_download_streams_without_browser_blob(self):
        script = (main.STATIC_DIR / "app.js").read_text()
        self.assertIn('href="/api/jobs/${encodeURIComponent(job.job_id)}/download"', script)
        self.assertNotIn("response.blob()", script)
        self.assertIn("job.download_expires_at", script)


if __name__ == "__main__":
    unittest.main()
