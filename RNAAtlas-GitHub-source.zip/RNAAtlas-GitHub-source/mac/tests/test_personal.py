import io
import json
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import personal_launcher
from app.config import PortalSettings
from app.hpc import HpcServiceClient, HpcServiceError
from personal_bundle import bundle_paths


class PersonalLauncherTests(unittest.TestCase):
    def test_setup_authenticates_before_retrying_workspace(self):
        events = []

        def answer(prompt):
            events.append(prompt)
            return answers.pop(0)

        answers = ["f123abc", "not-a-dartfs-path", "/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas"]

        def connect(netid):
            events.append("SSH for " + netid)

        with tempfile.TemporaryDirectory() as directory, patch.object(
            personal_launcher, "CONFIG_ROOT", Path(directory)
        ), patch.object(personal_launcher, "CONFIG_PATH", Path(directory) / "personal.json"), patch(
            "builtins.input", side_effect=answer
        ), patch.object(personal_launcher, "connect_master", side_effect=connect):
            config = personal_launcher.configure(authenticate_first=True)
            self.assertEqual(events[1], "SSH for f123abc")
            self.assertEqual(len(events), 4)
            self.assertEqual(config["workspace"], "/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas")
            self.assertEqual(json.loads(personal_launcher.CONFIG_PATH.read_text()), config)

    def test_workspace_must_stay_outside_service_account(self):
        valid = personal_launcher.validate_config({
            "netid": "f123abc", "workspace": "/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas",
        })
        self.assertEqual(valid["netid"], "f123abc")
        for workspace in (
            "/tmp/atlas",
            "/dartfs/rc/lab/L/LiaoC/Service_Account/RNAseq_atlas/user_data/f123abc",
            "/dartfs/rc/lab/L/LiaoC/Alice/../Service_Account/RNAseq_atlas",
        ):
            with self.subTest(workspace=workspace), self.assertRaises(ValueError):
                personal_launcher.validate_config({"netid": "f123abc", "workspace": workspace})

    def test_upload_contains_only_pipeline_python(self):
        calls = []

        def fake_ssh_run(netid, command, input_bytes=None):
            calls.append((netid, command, input_bytes))
            if command == "id -un":
                return netid
            if command.startswith("realpath -m"):
                return config["workspace"]
            return "ready"

        config = {"netid": "f123abc", "workspace": "/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas"}
        with patch.object(personal_launcher, "ssh_run", side_effect=fake_ssh_run):
            personal_launcher.install_remote_code(config)
        self.assertTrue(any("mkdir -m 700" in command and "/projects" in command for _, command, _ in calls))
        self.assertTrue(any("test ! -L" in command and "/projects" in command for _, command, _ in calls))
        archive_bytes = calls[-1][2]
        with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:gz") as archive:
            names = set(archive.getnames())
        self.assertIn("scripts/service_api.py", names)
        self.assertIn("scripts/run_pipeline.py", names)
        self.assertIn("scripts/submit_prepared.py", names)
        self.assertNotIn("scripts/probe_scratch.py", names)
        self.assertIn("app/rnaseq_service/paths.py", names)
        self.assertIn("app/rnaseq_service/quality_summary.py", names)
        self.assertNotIn("app/rnaseq_service/afumigatus_discovery.py", names)
        self.assertNotIn("app/rnaseq_service/logan_local.py", names)
        self.assertTrue(all(name.endswith(".py") for name in names))
        self.assertFalse(any(name.startswith(("projects/", "shared/")) for name in names))
        self.assertFalse(any(".secret" in name or "keytab" in name for name in names))

    def test_upload_rejects_a_symlinked_workspace_before_writing(self):
        config = {"netid": "f123abc", "workspace": "/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas"}
        with patch.object(personal_launcher, "ssh_run", side_effect=[
            "f123abc", "", "/dartfs/rc/lab/L/LiaoC/Service_Account/RNAseq_atlas",
        ]) as run:
            with self.assertRaisesRegex(RuntimeError, "canonical DartFS workspace"):
                personal_launcher.install_remote_code(config)
        self.assertEqual(run.call_count, 3)

    def test_personal_ssh_uses_socket_without_authentication_fallback(self):
        command = personal_launcher.ssh_base("f123abc")
        self.assertIn(str(personal_launcher.control_path("f123abc")), command)
        self.assertIn("GSSAPIAuthentication=no", command)
        self.assertIn("PubkeyAuthentication=no", command)
        self.assertIn("PasswordAuthentication=no", command)
        self.assertIn("KbdInteractiveAuthentication=no", command)

    def test_disconnected_launcher_does_not_attempt_direct_ssh(self):
        with patch.object(personal_launcher, "master_ready", return_value=False), patch(
            "personal_launcher.subprocess.run"
        ) as remote:
            with self.assertRaisesRegex(RuntimeError, "disconnected"):
                personal_launcher.ssh_run("f123abc", "id -un")
        remote.assert_not_called()

    def test_password_master_only_runs_in_terminal(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(
            personal_launcher, "CONFIG_ROOT", Path(directory)
        ), patch.object(personal_launcher, "master_ready", side_effect=[False, True]), patch(
            "personal_launcher.subprocess.run", return_value=type("Result", (), {"returncode": 0})()
        ) as remote:
            personal_launcher.connect_master("f123abc")
        command = remote.call_args.args[0]
        self.assertIn("ControlMaster=yes", command)
        self.assertIn("GSSAPIAuthentication=no", command)
        self.assertIn("PubkeyAuthentication=no", command)
        self.assertIn("StrictHostKeyChecking=ask", command)
        self.assertNotIn("BatchMode=yes", command)
        self.assertNotIn("capture_output", remote.call_args.kwargs)

    def test_bundle_excludes_local_runtime_and_credentials(self):
        paths = [str(path) for path in bundle_paths()]
        self.assertTrue(any(path.endswith("mac/personal_launcher.py") for path in paths))
        self.assertTrue(any(path.endswith("mac/app/static/sample_sheet_template.tsv") for path in paths))
        self.assertFalse(any("/.runtime/" in path or "/runtime/mac/" in path for path in paths))
        self.assertFalse(any("afumigatus_" in path or "logan_local.py" in path for path in paths))

    def test_personal_client_uses_member_identity_and_private_root(self):
        with tempfile.TemporaryDirectory() as directory:
            settings = PortalSettings(
                execution_backend="slurm", email="f123abc@dartmouth.edu",
                ssh_host="f123abc@discovery.dartmouth.edu",
                remote_root="/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas",
                mount_root=Path(directory), kerberos_cache=None, ssh_control_path="/tmp/member.sock",
                portal_mode="personal", shared_root=str(personal_launcher.SERVICE_ROOT),
            )
            client = HpcServiceClient(settings)
            with patch.object(client, "_run", return_value={}) as run:
                client.snapshot(settings.email)
            command = run.call_args.args[0][-1]
            self.assertIn("LIAO_RNASEQ_PERSONAL_MODE=1", command)
            self.assertIn("LIAO_RNASEQ_SHARED_ROOT={}".format(settings.shared_root), command)
            self.assertIn(settings.remote_root, command)
            self.assertIn(settings.remote_root + "/scripts/service_api.py", command)
            self.assertNotIn(".secrets", command)
            with patch.object(client, "_write", return_value={}) as write:
                client.submit({"project": "test_project"})
            self.assertEqual(write.call_args.args[0][-1], "--prepare-only")
            with self.assertRaises(HpcServiceError):
                HpcServiceClient(settings.__class__(
                    **{**settings.__dict__, "remote_root": str(personal_launcher.SERVICE_ROOT)},
                ))

    def test_personal_ase_upload_stages_inside_project_datasets(self):
        settings = PortalSettings(
            execution_backend="slurm", email="f123abc@dartmouth.edu",
            ssh_host="f123abc@discovery.dartmouth.edu",
            remote_root="/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas",
            mount_root=Path("/nonexistent"), kerberos_cache=None, ssh_control_path=None,
            portal_mode="personal", shared_root=str(personal_launcher.SERVICE_ROOT),
        )
        client = HpcServiceClient(settings)
        with patch.object(client, "project", return_value={}), patch.object(
            client, "_upload_remote_stream"
        ) as upload, patch.object(client, "_write", return_value={}), patch.object(client, "_remove_remote_uploads"):
            client.upload_ase_genotypes(
                settings.email, "Example", "af293", io.BytesIO(b"vcf"), "dna.vcf",
            )
        self.assertIn("/projects/Example/datasets/meta_data/.dna_genotypes.upload.", upload.call_args.args[1])


if __name__ == "__main__":
    unittest.main()
