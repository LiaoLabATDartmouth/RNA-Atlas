import io
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import personal_launcher
from app.config import PortalSettings
from app.hpc import HpcServiceClient, HpcServiceError
from personal_bundle import bundle_paths


class PersonalLauncherTests(unittest.TestCase):
    def test_workspace_must_stay_outside_service_account(self):
        valid = personal_launcher.validate_config({
            "netid": "f123abc", "workspace": "/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas",
        })
        self.assertEqual(valid["netid"], "f123abc")
        for workspace in (
            "/tmp/atlas",
            "/dartfs/rc/lab/L/LiaoC/Service_Account/RNAseq_atlas/user_data/f123abc",
            "/dartfs/rc/lab/L/LiaoC/Alice/../Service_Account/RNAseq_atlas",
        ):
            with self.subTest(workspace=workspace), self.assertRaises(ValueError):
                personal_launcher.validate_config({"netid": "f123abc", "workspace": workspace})

    def test_upload_contains_only_pipeline_python(self):
        calls = []

        def fake_ssh_run(netid, command, input_bytes=None):
            calls.append((netid, command, input_bytes))
            if command == "id -un":
                return netid
            if command.startswith("realpath -m"):
                return config["workspace"]
            return "ready"

        config = {"netid": "f123abc", "workspace": "/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas"}
        with patch.object(personal_launcher, "ssh_run", side_effect=fake_ssh_run):
            personal_launcher.install_remote_code(config)
        archive_bytes = calls[-1][2]
        with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:gz") as archive:
            names = set(archive.getnames())
        self.assertIn("scripts/service_api.py", names)
        self.assertIn("scripts/run_pipeline.py", names)
        self.assertIn("app/rnaseq_service/paths.py", names)
        self.assertIn("app/rnaseq_service/quality_summary.py", names)
        self.assertNotIn("app/rnaseq_service/afumigatus_discovery.py", names)
        self.assertNotIn("app/rnaseq_service/logan_local.py", names)
        self.assertTrue(all(name.endswith(".py") for name in names))
        self.assertFalse(any(".secret" in name or "keytab" in name for name in names))

    def test_upload_rejects_a_symlinked_workspace_before_writing(self):
        config = {"netid": "f123abc", "workspace": "/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas"}
        with patch.object(personal_launcher, "ssh_run", side_effect=[
            "f123abc", "/dartfs/rc/lab/L/LiaoC/Service_Account/RNAseq_atlas",
        ]) as run:
            with self.assertRaisesRegex(RuntimeError, "canonical DartFS workspace"):
                personal_launcher.install_remote_code(config)
        self.assertEqual(run.call_count, 2)

    def test_bundle_excludes_local_runtime_and_credentials(self):
        paths = [str(path) for path in bundle_paths()]
        self.assertTrue(any(path.endswith("mac/personal_launcher.py") for path in paths))
        self.assertTrue(any(path.endswith("mac/app/static/sample_sheet_template.tsv") for path in paths))
        self.assertFalse(any("/.runtime/" in path or "/runtime/mac/" in path for path in paths))
        self.assertFalse(any("afumigatus_" in path or "logan_local.py" in path for path in paths))

    def test_personal_client_uses_member_identity_and_private_root(self):
        with tempfile.TemporaryDirectory() as directory:
            settings = PortalSettings(
                execution_backend="slurm", email="f123abc@dartmouth.edu",
                ssh_host="f123abc@discovery.dartmouth.edu",
                remote_root="/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas",
                mount_root=Path(directory), kerberos_cache=None, ssh_control_path=None,
                portal_mode="personal", shared_root=str(personal_launcher.SERVICE_ROOT),
            )
            client = HpcServiceClient(settings)
            with patch.object(client, "_run", return_value={}) as run:
                client.snapshot(settings.email)
            command = run.call_args.args[0][-1]
            self.assertIn("LIAO_RNASEQ_PERSONAL_MODE=1", command)
            self.assertIn("LIAO_RNASEQ_SHARED_ROOT={}".format(settings.shared_root), command)
            self.assertIn(settings.remote_root, command)
            self.assertIn(settings.remote_root + "/scripts/service_api.py", command)
            self.assertNotIn(".secrets", command)
            with self.assertRaises(HpcServiceError):
                HpcServiceClient(settings.__class__(
                    **{**settings.__dict__, "remote_root": str(personal_launcher.SERVICE_ROOT)},
                ))

    def test_personal_ase_upload_stages_inside_project_datasets(self):
        settings = PortalSettings(
            execution_backend="slurm", email="f123abc@dartmouth.edu",
            ssh_host="f123abc@discovery.dartmouth.edu",
            remote_root="/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas",
            mount_root=Path("/nonexistent"), kerberos_cache=None, ssh_control_path=None,
            portal_mode="personal", shared_root=str(personal_launcher.SERVICE_ROOT),
        )
        client = HpcServiceClient(settings)
        with patch.object(client, "project", return_value={}), patch.object(
            client, "_upload_remote_stream"
        ) as upload, patch.object(client, "_write", return_value={}), patch.object(client, "_remove_remote_uploads"):
            client.upload_ase_genotypes(
                settings.email, "Example", "af293", io.BytesIO(b"vcf"), "dna.vcf",
            )
        self.assertIn("/Example/datasets/meta_data/.dna_genotypes.upload.", upload.call_args.args[1])


if __name__ == "__main__":
    unittest.main()
