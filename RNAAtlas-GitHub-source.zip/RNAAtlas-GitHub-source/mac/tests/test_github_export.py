import hashlib
import gzip
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile

import github_export


class GithubExportTests(unittest.TestCase):
    def test_allowlist_excludes_runtime_results_and_clinical_code(self):
        names = {str(name) for name, _, _ in github_export.source_files()}
        self.assertIn("mac/personal_launcher.py", names)
        self.assertIn("discovery/scripts/service_api.py", names)
        self.assertIn("discovery/r/run_deseq2.R", names)
        self.assertIn("README.md", names)
        self.assertIn(".gitignore", names)
        self.assertIn("examples/Calbicans_WT_YL_HL/datasets/raw_data/WT01/WT01_1.fq.gz", names)
        self.assertNotIn("mac/logs/mac-web.out", names)
        self.assertNotIn("discovery/app/rnaseq_service/afumigatus_discovery.py", names)
        self.assertTrue(all("/.runtime/" not in name and "/results/" not in name for name in names))

    def test_generated_tree_and_archive_match_hash_manifest(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            source_directory = directory / github_export.PACKAGE_NAME
            archive_path = directory / (github_export.PACKAGE_NAME + ".zip")
            with patch.object(github_export, "DIST", directory), patch.object(
                github_export, "SOURCE_DIRECTORY", source_directory,
            ), patch.object(github_export, "ARCHIVE_PATH", archive_path):
                github_export.main()
            with ZipFile(archive_path) as archive:
                self.assertIsNone(archive.testzip())
                launcher = archive.getinfo(github_export.PACKAGE_NAME + "/mac/start_personal.command")
                self.assertTrue((launcher.external_attr >> 16) & 0o111)
                self.assertTrue((source_directory / "mac" / "start_personal.command").stat().st_mode & 0o111)
                for line in (source_directory / "SOURCE_SHA256SUMS.txt").read_text().splitlines():
                    digest, name = line.split("  ", 1)
                    contents = (source_directory / name).read_bytes()
                    self.assertEqual(hashlib.sha256(contents).hexdigest(), digest)
                    self.assertEqual(archive.read(github_export.PACKAGE_NAME + "/" + name), contents)
                self.assertFalse(any("__pycache__" in name or ".venv-web" in name for name in archive.namelist()))

    def test_example_fastqs_match_manifest_and_pair_counts(self):
        root = github_export.ROOT / github_export.EXAMPLE_ROOT
        for line in (root / "SOURCE_SHA256SUMS.txt").read_text().splitlines():
            digest, name = line.split("  ", 1)
            self.assertEqual(hashlib.sha256((root / name).read_bytes()).hexdigest(), digest)
        for sample in github_export.EXAMPLE_SAMPLES:
            records = []
            for mate in (1, 2):
                with gzip.open(root / "datasets" / "raw_data" / sample / "{}_{}.fq.gz".format(sample, mate), "rt") as handle:
                    lines = handle.readlines()
                self.assertEqual(len(lines), 80_000)
                records.append([lines[index].split()[0].removesuffix("/{}".format(mate)) for index in range(0, len(lines), 4)])
            self.assertEqual(records[0], records[1])


if __name__ == "__main__":
    unittest.main()
