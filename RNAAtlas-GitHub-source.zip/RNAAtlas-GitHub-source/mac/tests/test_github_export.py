import hashlib
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile

import github_export


class GithubExportTests(unittest.TestCase):
    def test_allowlist_excludes_runtime_results_and_clinical_code(self):
        names = {str(name) for name, _, _ in github_export.source_files()}
        self.assertIn("mac/personal_launcher.py", names)
        self.assertIn("discovery/scripts/service_api.py", names)
        self.assertIn("discovery/r/run_deseq2.R", names)
        self.assertIn("discovery/tests/test_fastq_validation.py", names)
        self.assertIn("discovery/tests/test_trinity.py", names)
        self.assertIn("README.md", names)
        self.assertIn(".gitignore", names)
        self.assertFalse(any(name.startswith("examples/") for name in names))
        self.assertNotIn("mac/logs/mac-web.out", names)
        self.assertNotIn("discovery/app/rnaseq_service/afumigatus_discovery.py", names)
        self.assertTrue(all("/.runtime/" not in name and "/results/" not in name for name in names))

    def test_generated_tree_and_archive_match_hash_manifest(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            source_directory = directory / github_export.PACKAGE_NAME
            archive_path = directory / (github_export.PACKAGE_NAME + ".zip")
            checksum_path = directory / (github_export.PACKAGE_NAME + ".zip.sha256")
            with patch.object(github_export, "DIST", directory), patch.object(
                github_export, "SOURCE_DIRECTORY", source_directory,
            ), patch.object(github_export, "ARCHIVE_PATH", archive_path), patch.object(
                github_export, "CHECKSUM_PATH", checksum_path,
            ):
                github_export.main()
            self.assertEqual(
                checksum_path.read_text(),
                "{}  {}\n".format(hashlib.sha256(archive_path.read_bytes()).hexdigest(), archive_path.name),
            )
            with ZipFile(archive_path) as archive:
                self.assertIsNone(archive.testzip())
                launcher = archive.getinfo(github_export.PACKAGE_NAME + "/mac/start_personal.command")
                self.assertTrue((launcher.external_attr >> 16) & 0o111)
                self.assertTrue((source_directory / "mac" / "start_personal.command").stat().st_mode & 0o111)
                reconnect = archive.getinfo(github_export.PACKAGE_NAME + "/mac/connect_discovery.command")
                self.assertTrue((reconnect.external_attr >> 16) & 0o111)
                for line in (source_directory / "SOURCE_SHA256SUMS.txt").read_text().splitlines():
                    digest, name = line.split("  ", 1)
                    contents = (source_directory / name).read_bytes()
                    self.assertEqual(hashlib.sha256(contents).hexdigest(), digest)
                    self.assertEqual(archive.read(github_export.PACKAGE_NAME + "/" + name), contents)
                self.assertFalse(any("__pycache__" in name or ".venv-web" in name for name in archive.namelist()))

if __name__ == "__main__":
    unittest.main()
