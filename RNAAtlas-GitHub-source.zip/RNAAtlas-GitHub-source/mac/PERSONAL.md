# Personal RNA Atlas (macOS)

This is a **per-member localhost app**, not a shared website. Each member runs the browser UI on their own Mac at `127.0.0.1`; the app logs in to Discovery as that member and submits Slurm jobs under their NetID. It never asks for or stores a Dartmouth password. Do not forward its localhost port or share its private URL token.

## Before distributing

- The member needs a Discovery/HPC account, Dartmouth network or VPN access, and a member-owned workspace under `/dartfs/rc/lab/L/LiaoC/` **outside** `Service_Account`. The launcher creates the configured workspace directory if needed. The lab can organize workspaces as, for example, `/dartfs/rc/lab/L/LiaoC/RNAseq_atlas_members/<netid>/RNAseq_atlas/`, if permissions allow; this layout is not required.
- The member must be able to read the existing `Service_Account/RNAseq_atlas/shared/references`, `shared/runtime_v2`, and `r/run_deseq2.R` assets. Lab owners should make pipeline assets read-only to ordinary members; no member should receive the service keytab, service registry, or write access to service scripts. The launcher fails if these core assets cannot be read.
- The current personal release uses preinstalled lab references; it cannot build new references. Each member prepares a project directly under `<personal-workspace>/` and keeps both its inputs and results there, not in the service-account projects folder. They still need read/traverse access to the shared reference and runtime paths inside `Service_Account`; if the lab wants no service-account access at all, those read-only assets must first be relocated and the launcher updated.
- The Discovery compute node must receive the member's delegated Kerberos ticket. Personal jobs check this at start and fail clearly if unavailable. Long jobs also require a site-supported ticket-renewal strategy; this has not been verified here.

## Share and start

1. For the private lab GitHub repository, run `python3 mac/github_export.py` and publish the **contents** of `mac/dist/RNAAtlas-GitHub-source/`, including its intentionally allowlisted Candida example. For a smaller direct handoff without that example, run `python3 mac/personal_bundle.py` and share `mac/dist/RNAAtlas-personal.zip`. Neither package contains runtime credentials, results, service configuration, or deployment files.
2. On each member's Mac, unzip the GitHub source or personal package in a private local directory. Follow the member-facing README's three Terminal checks: obtain and inspect a Kerberos ticket, verify Discovery's SSH host identity and remote ticket, then confirm a passwordless `BatchMode=yes` SSH connection. The launcher uses that same non-interactive GSSAPI/delegation pattern. **Do not send credentials to the lab owner or enter them in the app**.
3. Double-click `mac/start_personal.command`. The first launch installs the local Python dependencies and asks only for the member's NetID and the path to their private workspace, for example `/dartfs/rc/lab/L/LiaoC/Alice/RNAseq_atlas`. It then copies non-secret pipeline Python code into that workspace and opens the private browser page.
4. To reconfigure, run `.venv-web/bin/python personal_launcher.py --configure` from the `mac` directory. To diagnose access without opening a browser, use `--check`. Local settings and the URL token live in `~/.rnaseq-atlas/` with user-only permissions.

## Prepare and open a project

Create one project folder directly under `<personal-workspace>/` on DartFS. Its folder name becomes the project name; no `projects/` folder is required. Put the data in its `datasets/` subfolder before opening it in the app. The app creates `results/` and its module folders when you load the project:

```text
experiment_1/
  datasets/
    meta_data/sample_sheet.tsv
    raw_data/S1/S1_1.fq.gz
    raw_data/S1/S1_2.fq.gz
  genotype_VCF/dna_genotypes.vcf.gz   # ASE only, if used
  results/
    differential_expression/<job-id>/
    rna_snv/<job-id>/
    ase/<job-id>/
    trinity/<job-id>/
```

The sample sheet needs `sample_id` and `condition` columns; each sample needs paired FASTQs with matching IDs. Download the sample-sheet template from the browser. Under **Load RNA-seq data and metadata**, click **Open project folder** to connect this browser session to Discovery, choose the prepared project folder, select a preinstalled reference, and click **Load data**. The browser never asks for a Discovery password: sign in using your own launcher or Terminal if the connection fails. **Disconnect** closes only the browser session; running Slurm jobs and the local SSH control connection are unaffected. The app checks the sample sheet, matches sample IDs to R1/R2 filenames, and profiles up to 2,000 read pairs per sample without moving the data. With the default complete-pair check enabled, full-file FASTQ validation runs at analysis preflight; the initial check alone does not prove that every gzip block is intact. The app registers the prepared folder and creates its result directories. Reopening that same project shows its prior jobs; each new analysis runs exactly one module and writes to `results/<module>/<job-id>/` there. Previous results are retained. A ZIP download is available for three days after job completion when it is at most 2 GiB; larger bundles stay on DartFS. The underlying DartFS results are not automatically deleted.

The browser shows absolute paths for the selected project's FASTQs, sample sheet, and result folder. Each job can request 1–32 CPUs and 8–256 GB RAM; these controls use Dartmouth's published free-tier account limits, while actual Slurm scheduling and node availability may be more restrictive.

For ASE, place `dna_genotypes.vcf.gz` or `dna_genotypes.vcf` in the project's `genotype_VCF/` folder after loading the reads. The app detects and validates it automatically and warns if it is missing. The ASE card remains selectable so the warning is visible, but validation/submission is blocked without a compatible VCF. A sample map (`ase_genotype_map.tsv`) goes in the same folder when RNA sample IDs differ from VCF sample IDs. ASE does not call genotypes from the RNA reads. SNV and ASE show the species' biological ploidy default recorded in the selected reference manifest; the browser no longer asks for a ploidy value. This value is curated independently of the reference FASTA's chromosome copy representation: an A-only *C. albicans* reference still defaults to diploid (2n), while Af293 defaults to haploid (1n). It is not a measurement of the sample. ASE requires a default of at least two; samples with known atypical ploidy need separate review before variant analysis.

The browser offers validated NCBI RefSeq and FungiDB Release 71 references for Candida SC5314 and *Aspergillus fumigatus* Af293. The FungiDB packages were built from user-supplied matching FASTA/GFF archives and have separate immutable IDs and STAR indexes; they do not replace the NCBI packages. *Candida albicans* is typically diploid, but both offered SC5314 references use a haploid A-only coordinate set rather than concatenated A+B chromosomes. Af293 and its reference assembly are haploid. The browser labels species ploidy separately from reference representation. Dh68 remains in the shared catalog for existing projects but is not offered for new analyses. The personal bundle does not carry genome data; the lab's shared Discovery reference packages must already be installed and readable. `Service_Account/RNAseq_atlas/examples/` is an input example only; old service demo runs are archived outside the active RNA Atlas root.

The module cards show the pinned Discovery analysis versions: STAR 2.7.10b and DESeq2 1.46.0 for differential expression; STAR 2.7.10b and bcftools 1.24 for RNA SNV; STAR 2.7.10b, bcftools 1.24, and GATK ASEReadCounter 4.6.2.0 for ASE; Trinity 2.15.2 for de novo assembly. `QC only · do not trim` requires no processing-history entry. Such history can be useful for provenance, but it is not needed for QC or analysis.

Module settings expose only consequential choices: the DE reference group and library strandedness, DE reporting cutoffs, SNV site-depth/QUAL filters, ASE informative depth and minimum count **for each allele**, and Trinity's minimum contig length/read normalization. The DE cutoffs change the `significant` column and volcano plot, not DESeq2 model fitting. Setting the ASE per-allele minimum to zero retains monoallelic sites; the default of three requires support for both alleles. Confirm library strandedness from the library protocol because it changes STAR gene counts and Trinity orientation, and it is independent of trimming. DESeq2 uses the full variance-stabilizing transform for PCA automatically; fast versus full transform is not offered because it does not change the DE statistical test and the fast form failed on the small Candida example.

The resource form requests 1–32 CPUs, 8–256 GB RAM, and 1 hour–30 days of walltime on the standard partition, with a 48-hour default. Values are checked in the browser, API, and Discovery service before submission; Slurm can impose stricter account or node limits and stops a job at its walltime. The result bundle includes a per-sample QC summary with non-exclusion warnings. Trinity jobs attempt paired-read representation against the assembly; BUSCO completeness remains unmeasured without a pinned lineage database.

The member's effective DartFS permissions, shared asset readability, Slurm allocation, and compute-node Kerberos behavior must be checked on Discovery before claiming lab-wide readiness. Local tests and isolated live service-account QA cover the browser and DE, RNA SNV, DNA-informed ASE, and a Trinity mini run. The mini run validates Trinity input/output plumbing, not full-size completion. No live job has been run through a member's personal installation or identity.

## Lab handoff audit

- **Do not share the service-account website or token.** Share only a private copy of the personal ZIP; each member must use their own NetID, SSH/Kerberos login, and writable private DartFS workspace. Verify that other members cannot read the workspace or its results while they can read the shared references and runtime.
- **Validate one member-owned job before wider distribution.** On that member's Mac, check Python setup, VPN/SSH host trust, `personal_launcher.py --check`, prepared project selection, Slurm submission under that NetID, compute-node ticket availability, result ownership, and download. This has not yet been done.
- **Make code releases immutable before routine use.** The launcher currently extracts pipeline code into the same workspace on every start, while submitted Slurm jobs execute code from that workspace. Reopening the app during a running job can change its code mid-run. Move to versioned, read-only release directories with each job pinned to one version and a rollback path.
- **Set an operations policy.** The three-day browser download window is not a DartFS deletion policy. Define result retention, quota monitoring, backup expectations, and who maintains shared references and runtime. The current launcher is macOS-only; other operating systems need separate packaging and testing.
