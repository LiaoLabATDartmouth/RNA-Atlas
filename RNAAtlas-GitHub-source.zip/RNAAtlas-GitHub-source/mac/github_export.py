#!/usr/bin/env python3
"""Build an allowlisted personal-app source tree for a private GitHub repository."""

import hashlib
import shutil
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from personal_bundle import ROOT, bundle_paths


PACKAGE_NAME = "RNAAtlas-GitHub-source"
DIST = ROOT / "mac" / "dist"
SOURCE_DIRECTORY = DIST / PACKAGE_NAME
ARCHIVE_PATH = DIST / (PACKAGE_NAME + ".zip")
EXTRA_FILES = (
    "discovery/r/run_deseq2.R",
    "mac/github_export.py",
    "mac/GITHUB_SOURCE_README.md",
    "mac/GITHUB_SOURCE.gitignore",
    "mac/tests/test_app.py",
    "mac/tests/test_hpc.py",
    "mac/tests/test_personal.py",
    "mac/tests/test_github_export.py",
    "discovery/tests/test_personal_mode.py",
    "discovery/tests/test_project.py",
    "discovery/tests/test_service_api.py",
)
ROOT_FILES = {
    "README.md": ROOT / "mac" / "GITHUB_SOURCE_README.md",
    ".gitignore": ROOT / "mac" / "GITHUB_SOURCE.gitignore",
}
EXAMPLE_ROOT = Path("examples/Calbicans_WT_YL_HL")
EXAMPLE_SAMPLES = ("WT01", "WT02", "YL01", "YL02")
BLOCKED_MARKERS = (
    b"-----BEGIN " + b"PRIVATE KEY-----",
    b"-----BEGIN OPENSSH " + b"PRIVATE KEY-----",
    b"github_" + b"pat_",
    b"gh" + b"p_",
    b"xo" + b"xb-",
)


def source_files():
    files = {path.relative_to(ROOT): path for path in bundle_paths()}
    files.update({Path(name): ROOT / name for name in EXTRA_FILES})
    files.update({Path(name): path for name, path in ROOT_FILES.items()})
    for name in ("README.md", "SOURCE_SHA256SUMS.txt", "datasets/meta_data/sample_sheet.tsv"):
        relative = EXAMPLE_ROOT / name
        files[relative] = ROOT / relative
    for sample in EXAMPLE_SAMPLES:
        for mate in (1, 2):
            relative = EXAMPLE_ROOT / "datasets" / "raw_data" / sample / "{}_{}.fq.gz".format(sample, mate)
            files[relative] = ROOT / relative
    for relative, source in sorted(files.items()):
        if source.is_symlink() or not source.is_file():
            raise ValueError("Release source is missing or symlinked: {}".format(relative))
        is_example_fastq = relative.parts[:len(EXAMPLE_ROOT.parts)] == EXAMPLE_ROOT.parts and relative.name.endswith(".fq.gz")
        if source.stat().st_size > (10_000_000 if is_example_fastq else 2_000_000):
            raise ValueError("Release source is unexpectedly large: {}".format(relative))
        if any(part.startswith(".") and part != ".gitignore" for part in relative.parts):
            raise ValueError("Hidden release source is not allowed: {}".format(relative))
        if any(part in {"runtime", "logs", "dist", "output", "outputs", "__pycache__"} for part in relative.parts):
            raise ValueError("Runtime or result path is not allowed: {}".format(relative))
        contents = source.read_bytes()
        if is_example_fastq:
            if not contents.startswith(b"\x1f\x8b"):
                raise ValueError("Example FASTQ is not gzip-compressed: {}".format(relative))
        elif b"\0" in contents or any(marker in contents for marker in BLOCKED_MARKERS):
            raise ValueError("Release source contains binary data or a credential marker: {}".format(relative))
        yield relative, contents, source.stat().st_mode & 0o777


def main():
    sources = list(source_files())
    DIST.mkdir(parents=True, exist_ok=True)
    if SOURCE_DIRECTORY.is_symlink():
        raise ValueError("Release destination must not be a symlink.")
    if SOURCE_DIRECTORY.exists():
        shutil.rmtree(SOURCE_DIRECTORY)
    SOURCE_DIRECTORY.mkdir()
    manifest = []
    for relative, contents, mode in sources:
        destination = SOURCE_DIRECTORY / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(contents)
        destination.chmod(mode)
        manifest.append("{}  {}".format(hashlib.sha256(contents).hexdigest(), relative))
    (SOURCE_DIRECTORY / "SOURCE_SHA256SUMS.txt").write_text("\n".join(manifest) + "\n", encoding="utf-8")
    with ZipFile(ARCHIVE_PATH, "w", ZIP_DEFLATED) as archive:
        for source in sorted(SOURCE_DIRECTORY.rglob("*")):
            if source.is_file():
                archive.write(source, arcname="{}/{}".format(PACKAGE_NAME, source.relative_to(SOURCE_DIRECTORY)))
    print(SOURCE_DIRECTORY)
    print(ARCHIVE_PATH)
    print("{} source files plus checksum manifest".format(len(sources)))


if __name__ == "__main__":
    main()
