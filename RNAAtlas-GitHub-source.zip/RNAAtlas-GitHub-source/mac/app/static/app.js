const state = {
  config: null,
  snapshot: null,
  project: null,
  projectName: "",
  referenceId: "",
  validated: false,
  intakePath: "",
  polling: null,
  pollingInProgress: false,
};

const elements = Object.fromEntries([
  "email-pill", "cluster-dot", "cluster-label", "reconnect-discovery", "disconnect-discovery", "registration-card",
  "registration-form", "display-name", "workspace", "refresh-service",
  "new-project-reference", "reference-availability", "create-project-form", "new-project-name", "open-project-folder", "folder-dialog", "folder-list", "folder-dialog-message", "close-folder-dialog", "retry-discovery", "data-guide", "service-workspace-notice", "project-root-path", "project-folder-instruction", "raw-data-path", "sample-sheet-path", "project-output-path",
  "create-project-message", "create-project-button",
  "intake-card", "prepare-intake-button", "read-intake-metadata-button", "attach-intake-button", "intake-message", "intake-explanation", "intake-metadata-preview",
  "metadata-preview",
  "analysis-choice-note", "run-de", "run-rna-variants", "run-ase", "run-trinity",
  "module-options", "basic-module-options", "reference-condition", "reference-condition-group", "ploidy-group", "reference-ploidy", "ase-vcf-status",
  "library-strandedness-group", "de-padj-group", "de-padj-cutoff", "de-log2fc-group", "de-log2fc-cutoff",
  "snv-depth-group", "snv-min-depth", "snv-quality-group", "snv-min-quality",
  "ase-depth-group", "ase-min-depth", "ase-allele-group", "ase-min-allele-count",
  "trinity-settings-group", "trinity-min-contig-length", "trinity-normalize-reads",
  "trimming-mode", "fastq-inference", "custom-preparation", "no-trimming-details",
  "library-type", "library-prep", "selection-method", "umi-status", "adapter-handling", "adapter-sequences",
  "adapter-read1", "adapter-read2", "library-strandedness", "strand-review-confirmation", "strandedness-reviewed", "trim-quality-tails", "trim-quality-threshold",
  "trim-minimum-length", "trim-front-read1", "trim-front-read2", "trim-tail-read1", "trim-tail-read2",
  "cpu-threads", "memory-gb", "walltime-days", "walltime-hours", "resource-error",
  "verify-md5", "validate-fastq", "review-card", "review-step-label", "review-heading", "validation-banner", "validate-button", "submit-button", "manual-handoff",
  "project-history", "results-path", "jobs-section",
  "jobs-grid", "refresh-jobs", "admin-section", "admin-users", "toast",
].map((id) => [id.replaceAll("-", "_"), document.getElementById(id)]));

const referenceLabels = new Map([
  ["candida_albicans_SC5314_GCF_000182965.3", "NCBI RefSeq · Candida albicans SC5314 · species: typically diploid (2n) · reference: haploid A-only (no B)"],
  ["af293", "NCBI RefSeq · Aspergillus fumigatus Af293 · species: haploid (1n) · reference: haploid assembly"],
  ["fungidb71_candida_sc5314", "FungiDB 71 · Candida albicans SC5314 · species: typically diploid (2n) · reference: haploid A-only (no B)"],
  ["fungidb71_af293", "FungiDB 71 · Aspergillus fumigatus Af293 · species: haploid (1n) · reference: haploid assembly"],
  ["debaryomyces_hansenii_Dh68", "Lab Dh68 · Debaryomyces hansenii · Dh68 strain: lab-confirmed haploid (1n) · species: ploidy varies · reference: one chromosome set"],
]);

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character]));
}

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (!(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
  const response = await fetch(path, {
    ...options,
    headers,
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.detail || payload.error || `Request failed (${response.status}).`);
  return payload;
}

function showToast(message, type = "success") {
  elements.toast.textContent = message;
  elements.toast.className = `toast visible ${type === "error" ? "error" : ""}`;
  window.clearTimeout(showToast.timeout);
  showToast.timeout = window.setTimeout(() => { elements.toast.className = "toast"; }, 4200);
}

function setValidation(message, type = "") {
  elements.validation_banner.textContent = message;
  elements.validation_banner.className = `validation-banner ${type}`.trim();
}

function invalidateValidation(message = "Configuration changed. Validate again before submission.") {
  state.validated = false;
  elements.submit_button.disabled = true;
  if (state.projectName) setValidation(message, "warning");
  renderReview();
}

function selectedReference() {
  return state.snapshot?.references?.find((reference) => reference.id === state.referenceId) || null;
}

function biologicalPloidy() {
  const ploidy = Number(selectedReference()?.recommended_ploidy);
  return Number.isInteger(ploidy) && ploidy >= 1 && ploidy <= 16 ? ploidy : null;
}

function selectedReferenceHasAnnotation() {
  const reference = selectedReference();
  return !reference || reference.has_annotation !== false;
}

function updateLoadDataButton() {
  const connectionReady = !state.config?.submission_enabled || (state.config.connected && state.config.ssh_ready);
  elements.create_project_button.disabled = !connectionReady || !elements.new_project_name.value.trim() || !elements.new_project_reference.value;
}

function renderFastqInference() {
  const profiles = Object.entries(state.project?.fastq_profile?.samples || {});
  if (!profiles.length) {
    elements.fastq_inference.innerHTML = "<strong>Information inferred from FASTQ</strong><p>No sampled FASTQ profile is available yet.</p>";
    return;
  }
  const [sampleId, profile] = profiles[0];
  const single = profile.layout === "single-end";
  const header = profile.headers?.read1 || {};
  const read1Length = profile.read_lengths?.read1 || {};
  const read2Length = profile.read_lengths?.read2 || {};
  const prefix1 = profile.leading_sequence_signals?.read1 || {};
  const prefix2 = profile.leading_sequence_signals?.read2 || {};
  const facts = [
    profile.layout || "paired-end",
    `${read1Length.minimum ?? "?"}–${read1Length.maximum ?? "?"} bp ${single ? "reads" : "R1"}`,
    ...(!single ? [`${read2Length.minimum ?? "?"}–${read2Length.maximum ?? "?"} bp R2`] : []),
    `${profile.compression?.read1 || "unknown"} compression`,
    profile.quality_encoding || "quality encoding unknown",
  ];
  if (header.instrument) facts.push(`instrument ${header.instrument}`);
  if (header.flowcell) facts.push(`flowcell ${header.flowcell}`);
  if (header.lane) facts.push(`lane ${header.lane}`);
  if (header.sample_index) facts.push(`index ${header.sample_index}`);
  const signals = [];
  if (Number(prefix1.fraction || 0) >= 0.05) signals.push(`${single ? "Reads" : "R1"} leading ${prefix1.sequence} in ${(100 * prefix1.fraction).toFixed(1)}%`);
  if (Number(prefix2.fraction || 0) >= 0.05) signals.push(`R2 leading ${prefix2.sequence} in ${(100 * prefix2.fraction).toFixed(1)}%`);
  elements.fastq_inference.innerHTML = `
    <strong>Detected from ${escapeHtml(sampleId)} FASTQ</strong>
    <div class="inference-tags">${facts.map((fact) => `<span>${escapeHtml(fact)}</span>`).join("")}</div>
    ${signals.length ? `<p><strong>Fixed-prefix signal:</strong> ${escapeHtml(signals.join("; "))}. This is evidence only and is never automatically hard-trimmed.</p>` : ""}
    <p>Sampled ${escapeHtml(single ? profile.sampled_reads : profile.sampled_read_pairs)} ${single ? "reads" : "pairs"} from each of ${profiles.length} sample profile${profiles.length === 1 ? "" : "s"}. Kit, UMI meaning, and selection method still require metadata. FASTQ alone cannot establish strandedness; DE and Trinity check a small alignment against annotated genes after the job starts.</p>`;
}

function singleEndProject() {
  return state.project?.read_layout === "single" ||
    Object.values(state.project?.fastq_profile?.samples || {})[0]?.layout === "single-end";
}

function renderPreprocessingOptions() {
  const mode = elements.trimming_mode.value;
  elements.custom_preparation.hidden = mode !== "custom";
  elements.no_trimming_details.hidden = mode !== "none";
  elements.adapter_sequences.hidden = mode !== "custom" || elements.adapter_handling.value !== "provided";
  for (const element of [elements.adapter_read2, elements.trim_front_read2, elements.trim_tail_read2]) {
    element.closest(".field-group").hidden = Boolean(singleEndProject());
  }
  renderFastqInference();
}

function preprocessingPayload() {
  const custom = elements.trimming_mode.value === "custom";
  const single = singleEndProject();
  return {
    trimming_mode: elements.trimming_mode.value,
    library_type: custom ? elements.library_type.value : "standard_bulk",
    library_prep: custom ? elements.library_prep.value.trim() : "",
    adapter_handling: custom ? elements.adapter_handling.value : (elements.trimming_mode.value === "auto" ? "detect" : "none"),
    adapter_read1: custom ? elements.adapter_read1.value.trim().toUpperCase() : "",
    adapter_read2: custom && !single ? elements.adapter_read2.value.trim().toUpperCase() : "",
    trim_quality_tails: custom ? elements.trim_quality_tails.checked : true,
    trim_quality_threshold: custom ? Number(elements.trim_quality_threshold.value) : 15,
    trim_minimum_length: custom ? Number(elements.trim_minimum_length.value) : 30,
    trim_front_read1: custom ? Number(elements.trim_front_read1.value) : 0,
    trim_front_read2: custom && !single ? Number(elements.trim_front_read2.value) : 0,
    trim_tail_read1: custom ? Number(elements.trim_tail_read1.value) : 0,
    trim_tail_read2: custom && !single ? Number(elements.trim_tail_read2.value) : 0,
    umi_status: custom ? elements.umi_status.value : "unknown",
    selection_method: custom ? elements.selection_method.value : "unknown",
    strandedness: elements.library_strandedness.value,
    strandedness_reviewed: elements.strandedness_reviewed.checked && elements.library_strandedness.value !== "auto",
    prior_processing: "",
  };
}

function validatePreprocessing() {
  if (elements.trimming_mode.value !== "custom") return;
  if (!["standard_bulk", "custom_bulk"].includes(elements.library_type.value)) {
    throw new Error("This app currently supports standard or custom bulk RNA-seq only. Select a dedicated workflow for specialized libraries.");
  }
  if (!elements.library_prep.value.trim()) throw new Error("Enter the kit or preparation name for custom preprocessing.");
  if (elements.umi_status.value === "present") throw new Error("UMI-containing libraries require molecule-aware extraction and counting, which this bulk workflow does not yet implement.");
  if (elements.adapter_handling.value === "provided") {
    if (!elements.adapter_read1.value || (!singleEndProject() && !elements.adapter_read2.value)) throw new Error(singleEndProject() ? "Provide an adapter sequence." : "Provide both R1 and R2 adapter sequences.");
    if (!elements.adapter_read1.checkValidity() || (!singleEndProject() && !elements.adapter_read2.checkValidity())) throw new Error("Adapter sequences must contain 6–200 bases using A, C, G, T, or N.");
  }
  const profiles = Object.values(state.project?.fastq_profile?.samples || {});
  if (!profiles.length) return;
  const minimumR1 = Math.min(...profiles.map((profile) => Number(profile.read_lengths?.read1?.minimum || 0)).filter(Boolean));
  const minimumR2 = singleEndProject() ? Infinity : Math.min(...profiles.map((profile) => Number(profile.read_lengths?.read2?.minimum || 0)).filter(Boolean));
  const remainingR1 = minimumR1 - Number(elements.trim_front_read1.value) - Number(elements.trim_tail_read1.value);
  const remainingR2 = singleEndProject() ? Infinity : minimumR2 - Number(elements.trim_front_read2.value) - Number(elements.trim_tail_read2.value);
  if (remainingR1 < 1 || remainingR2 < 1) throw new Error("Fixed trimming would remove an entire sampled read. Reduce the declared fixed-base trims.");
  if (Number(elements.trim_minimum_length.value) > Math.min(remainingR1, remainingR2)) {
    throw new Error("Minimum retained length exceeds the sampled read length remaining after fixed trimming.");
  }
}

function validateDiscoverySettings() {
  const checkNumber = (element, label) => {
    const value = Number(element.value);
    if (!element.value.trim() || !Number.isSafeInteger(value) || !element.checkValidity()) throw new Error(`${label} must be a whole number within its allowed range.`);
    return value;
  };
  checkNumber(elements.cpu_threads, "CPUs");
  checkNumber(elements.memory_gb, "RAM");
  const days = checkNumber(elements.walltime_days, "Run time days");
  const hours = checkNumber(elements.walltime_hours, "Additional hours");
  if (days * 24 + hours < 1 || days * 24 + hours > 720) throw new Error("Run time must be between 1 hour and 30 days.");
  if (elements.run_trinity.checked) checkNumber(elements.trinity_min_contig_length, "Minimum Trinity contig length");
  const checkFloat = (element, label) => {
    const value = Number(element.value);
    if (!element.value.trim() || !Number.isFinite(value) || !element.checkValidity()) throw new Error(`${label} must be within its allowed range.`);
  };
  if (elements.run_de.checked) {
    checkFloat(elements.de_padj_cutoff, "Adjusted p-value cutoff");
    if (Number(elements.de_padj_cutoff.value) <= 0) throw new Error("Adjusted p-value cutoff must be greater than zero.");
    checkFloat(elements.de_log2fc_cutoff, "Log2 fold-change cutoff");
  }
  if (elements.run_rna_variants.checked) {
    checkNumber(elements.snv_min_depth, "Minimum RNA site depth");
    checkFloat(elements.snv_min_quality, "Minimum variant QUAL");
  }
  if (elements.run_ase.checked) {
    checkNumber(elements.ase_min_depth, "Minimum informative allele depth");
    checkNumber(elements.ase_min_allele_count, "Minimum reads for each allele");
  }
  return days * 24 + hours;
}

function showResourceError() {
  try {
    validateDiscoverySettings();
    elements.resource_error.hidden = true;
    elements.resource_error.textContent = "";
  } catch (error) {
    elements.resource_error.hidden = false;
    elements.resource_error.textContent = error.message;
  }
}

function configuredWalltimeHours(value) {
  const match = String(value || "").match(/^(?:(\d+)-)?(\d+):\d{2}:\d{2}$/);
  if (!match) return 48;
  const total = Number(match[1] || 0) * 24 + Number(match[2]);
  return total >= 1 && total <= 720 ? total : 48;
}

function toggleCards() {
  const hasAnnotation = selectedReferenceHasAnnotation();
  const deCard = elements.run_de.closest(".analysis-card");
  if (!hasAnnotation) elements.run_de.checked = false;
  elements.run_de.disabled = !hasAnnotation;
  deCard.classList.toggle("disabled", !hasAnnotation);
  deCard.title = hasAnnotation ? "" : "Differential expression requires an annotated reference.";
  const asePloidy = biologicalPloidy();
  const aseCard = elements.run_ase.closest(".analysis-card");
  aseCard.title = asePloidy !== null && asePloidy < 2 ? "ASE requires a diploid or polyploid sample; this species defaults to haploid." : "";
  if (!document.querySelector('input[name="analysis-module"]:checked')) {
    (elements.run_de.disabled ? elements.run_rna_variants : elements.run_de).checked = true;
  }
  elements.analysis_choice_note.textContent = hasAnnotation
    ? "Choose exactly one module per run. FASTQ QC and STAR alignment run with the selected analysis."
    : "Choose one module. This FASTA-only reference supports alignment, SNV, ASE, and Trinity, but not differential expression.";
  document.querySelectorAll("[data-toggle-card]").forEach((card) => {
    const input = card.querySelector("input");
    card.classList.toggle("selected", input.checked);
  });
  elements.reference_condition_group.hidden = !state.project || !elements.run_de.checked;
  elements.library_strandedness_group.hidden = !elements.run_de.checked && !elements.run_trinity.checked;
  elements.strand_review_confirmation.hidden = elements.library_strandedness_group.hidden || elements.library_strandedness.value === "auto";
  elements.de_padj_group.hidden = !elements.run_de.checked;
  elements.de_log2fc_group.hidden = !elements.run_de.checked;
  elements.snv_depth_group.hidden = !elements.run_rna_variants.checked;
  elements.snv_quality_group.hidden = !elements.run_rna_variants.checked;
  elements.ase_depth_group.hidden = !elements.run_ase.checked;
  elements.ase_allele_group.hidden = !elements.run_ase.checked;
  elements.ploidy_group.hidden = !elements.run_rna_variants.checked && !elements.run_ase.checked;
  elements.reference_ploidy.textContent = asePloidy === null ? "Unavailable" : `${asePloidy}n`;
  elements.ase_vcf_status.hidden = !elements.run_ase.checked;
  elements.trinity_settings_group.hidden = !elements.run_trinity.checked;
  elements.basic_module_options.hidden = elements.run_de.checked && !state.project;
  elements.module_options.hidden = elements.run_de.checked && !state.project;
  const genotypeStatus = state.project?.ase_genotypes || {};
  if (elements.run_ase.checked) {
    const genotypeMessage = genotypeStatus.ready
      ? `Validated genotype VCF: ${genotypeStatus.vcf_filename}.`
      : (genotypeStatus.error || "No genotype VCF found. Add dna_genotypes.vcf.gz (or .vcf) under this project's genotype_VCF/ folder.");
    elements.ase_vcf_status.className = `form-message ${genotypeStatus.ready && asePloidy >= 2 ? "success" : "error"}`;
    elements.ase_vcf_status.textContent = `${asePloidy !== null && asePloidy < 2 ? "ASE requires a diploid or polyploid sample; this species defaults to haploid. " : ""}${genotypeMessage}`;
  }
}

function renderService() {
  const { snapshot, config } = state;
  const personal = config.portal_mode === "personal";
  elements.review_step_label.textContent = personal ? "03 · Review and create job" : "03 · Review and submit";
  elements.review_heading.textContent = personal ? "Validate before creating" : "Validate before submission";
  elements.submit_button.textContent = personal ? "Create Slurm job" : "Submit Slurm job";
  const backendReady = config.submission_enabled ? config.connected && config.ssh_ready : Boolean(snapshot?.service_root?.includes("/Volumes/"));
  elements.email_pill.textContent = config.portal_mode === "personal"
    ? (backendReady ? `${config.email} · ${config.hpc_user}` : "Discovery sign-in needed")
    : (backendReady ? `${config.email} · service session` : "Discovery disconnected");
  elements.cluster_dot.className = `status-dot ${backendReady ? "ready" : config.submission_enabled ? "error" : ""}`;
  elements.cluster_label.textContent = config.submission_enabled
    ? (backendReady ? "Discovery connected" : "Discovery disconnected")
    : "Mounted preview";
  elements.reconnect_discovery.hidden = !config.submission_enabled || backendReady;
  elements.disconnect_discovery.hidden = !config.submission_enabled || !backendReady;
  if (!backendReady) elements.folder_dialog_message.textContent = personal
    ? "This button uses your password-authenticated Discovery connection. If disconnected, double-click mac/connect_discovery.command in your downloaded folder, enter your password in Terminal, then retry here. This page never asks for your password."
    : "This button reconnects the administrator's existing Discovery session; this page never asks for a password.";
}

function renderAccess() {
  const user = state.snapshot.user;
  const registered = Boolean(user);
  elements.registration_card.hidden = registered;
  elements.workspace.hidden = !registered || user.status !== "approved";
  elements.jobs_section.hidden = !registered || user.status !== "approved";
  if (registered && user.status !== "approved") {
    elements.registration_card.hidden = false;
    elements.registration_card.querySelector("h2").textContent = "Registration awaiting approval";
    elements.registration_card.querySelector("p:last-child").textContent = "An administrator must approve this account before jobs can be submitted.";
    elements.registration_form.hidden = true;
  }
}

function renderProjects() {
  renderDataPaths();
  renderIntake();
}

function renderDataPaths() {
  const personal = state.config?.portal_mode === "personal";
  elements.service_workspace_notice.hidden = personal;
  const root = personal ? state.config?.remote_root || state.snapshot?.service_root : "<personal-workspace>";
  if (!root) return;
  const projectRoot = `${root}/projects/`;
  const folder = `${projectRoot}<project_folder>`;
  elements.project_root_path.textContent = projectRoot;
  elements.project_folder_instruction.textContent = "The folder name becomes the project name. Put inputs in its datasets/ subfolder before loading it; subsequent analyses retain results in this same project.";
  elements.raw_data_path.textContent = `${folder}/datasets/raw_data/`;
  elements.sample_sheet_path.textContent = `${folder}/datasets/meta_data/sample_sheet.tsv`;
  elements.project_output_path.textContent = `${folder}/results/<module>/<job-id>/`;
}

function renderIntake() {
  const project = state.snapshot.projects?.find((item) => item.name === state.projectName);
  const canUse = Boolean(project && project.owner_email === state.snapshot.user?.email);
  const personal = state.config?.portal_mode === "personal";
  elements.intake_card.hidden = personal || !canUse;
  elements.prepare_intake_button.disabled = !canUse || Boolean(project?.intake_imported);
  elements.read_intake_metadata_button.disabled = !canUse || Boolean(project?.intake_imported);
  elements.attach_intake_button.disabled = !canUse || Boolean(project?.intake_imported);
  elements.intake_card.querySelector("summary").textContent = personal
    ? "Advanced: import from a project intake folder" : "Import RNA-seq data and read metadata";
  if (!personal && canUse) elements.intake_card.open = true;
  if (personal) elements.intake_explanation.innerHTML = "For data already placed in this project's private intake folder, validate and import them here.";
  else elements.intake_explanation.innerHTML = "Prepare a private DartFS folder, place <code>meta_data/sample_sheet.tsv</code> and FASTQs under <code>raw_data/&lt;sample_id&gt;/</code>, then read its metadata and import it.";
  if (canUse && !state.intakePath) {
    elements.intake_message.textContent = project.intake_imported
      ? "Inputs were imported into this project. Create a new project for a replacement dataset."
      : "Your intake folder has not been imported yet.";
  }
}

function renderMetadataPreview(target, preview) {
  target.hidden = false;
  const fileDetails = Boolean(preview.input_checks?.length || preview.samples?.some((sample) => sample.read1 || sample.read2));
  const issues = (preview.input_checks || []).filter((sample) => sample.issues?.length)
    .map((sample) => `<li><strong>${escapeHtml(sample.sample_id)}:</strong> ${escapeHtml(sample.issues.join("; "))}</li>`);
  const errors = [...(preview.errors || []), ...(preview.warnings || []).filter((warning) => warning.startsWith("Folders in raw_data/"))]
    .map((error) => `<li>${escapeHtml(error)}</li>`);
  const profile = preview.fastq_profile?.samples || {};
  const profileCount = Object.keys(profile).length;
  const single = preview.read_layout === "single" ||
    (preview.input_checks?.length && preview.input_checks.every((sample) => sample.layout === "single"));
  target.innerHTML = `<strong>${escapeHtml(preview.sample_count)} samples · ${escapeHtml((preview.conditions || []).length)} groups</strong>
    ${issues.length || errors.length ? `<div class="input-checks"><strong>Data needing attention</strong><ul>${[...issues, ...errors].join("")}</ul></div>` : fileDetails && profileCount === Number(preview.sample_count) ? `<p class="input-checks-ok">Sample sheet and FASTQ names match. Up to 2,000 ${single ? "reads" : "read pairs"} per sample passed the initial format check; the default complete-file check validates whole files when analysis starts.</p>` : fileDetails ? `<p>Sample sheet and FASTQ names match; read contents have not been checked yet.</p>` : ""}
    <div class="sample-table-wrap"><table><thead><tr><th>Sample</th><th>Group</th>${fileDetails ? `<th>${single ? "Reads" : "R1"}</th>${single ? "" : "<th>R2</th>"}` : ""}</tr></thead><tbody>
    ${(preview.input_checks || preview.samples || []).map((sample) => `<tr><td>${escapeHtml(sample.sample_id)}</td><td>${escapeHtml(sample.condition)}</td>${fileDetails ? `<td>${escapeHtml(sample.read1 || "Missing")}</td>${single ? "" : `<td>${escapeHtml(sample.read2 || "Missing")}</td>`}` : ""}</tr>`).join("")}
    </tbody></table></div>${preview.truncated ? "<small>Showing first 20 samples.</small>" : ""}`;
}

function renderReferences() {
  const discovered = new Map((state.snapshot.references || []).map((reference) => [reference.id, reference]));
  const references = [...referenceLabels].map(([id, label]) => ({ id, label, record: discovered.get(id) }));
  const readyReferences = references.filter((reference) => reference.record?.ready);
  if (!state.projectName && !readyReferences.some((reference) => reference.id === state.referenceId)) {
    state.referenceId = readyReferences[0]?.id || "";
  }
  const optionHtml = references.map((reference) => `<option value="${escapeHtml(reference.id)}"${reference.record?.ready ? "" : " disabled"}>${escapeHtml(reference.label)}${reference.record?.ready ? "" : " · unavailable"}</option>`).join("");
  elements.new_project_reference.innerHTML = readyReferences.length ? optionHtml : '<option value="">No ready references</option>' + optionHtml;
  elements.new_project_reference.value = readyReferences.some((reference) => reference.id === state.referenceId)
    ? state.referenceId : readyReferences[0]?.id || "";
  const unavailable = references.filter((reference) => !reference.record?.ready).map((reference) => {
    const reason = reference.record?.errors?.[0] || "not listed by Discovery";
    return `${reference.record?.label || reference.id}: ${reason}`;
  });
  elements.reference_availability.hidden = unavailable.length === 0;
  elements.reference_availability.textContent = unavailable.length
    ? `Unavailable references cannot be selected. ${unavailable.join("; ")}. Refresh or ask the lab maintainer to check the shared reference files and permissions.` : "";
  updateLoadDataButton();
  const trinityCard = elements.run_trinity.closest(".analysis-card");
  elements.run_trinity.disabled = !state.snapshot.trinity_ready;
  trinityCard.classList.toggle("disabled", !state.snapshot.trinity_ready);
  trinityCard.title = state.snapshot.trinity_ready ? "" : "Trinity runtime installation is pending on Discovery.";
  toggleCards();
}

async function selectProject(name) {
  if (name !== state.projectName) state.intakePath = "";
  elements.new_project_name.value = name;
  renderDataPaths();
  elements.metadata_preview.hidden = true;
  elements.project_history.hidden = true;
  state.projectName = name;
  const summary = state.snapshot.projects.find((project) => project.name === name);
  if (summary && !summary.ready) showToast(summary.errors?.join("; ") || "This project needs attention.", "error");
  renderProjects();
  await loadProject(name);
}

async function loadProject(name) {
  setValidation("Loading staged sample metadata…");
  try {
    state.project = await api(`/api/projects/${encodeURIComponent(name)}`);
    const configuredReference = state.project.config.reference_id;
    if (configuredReference) state.referenceId = configuredReference;
    renderReferences();
    renderProjectDetails();
    renderMetadataPreview(elements.metadata_preview, state.project);
    elements.validate_button.disabled = !state.project.sample_count || Boolean(state.project.errors?.length) || Boolean(state.project.input_checks?.some((sample) => sample.issues?.length));
    invalidateValidation(state.project.errors?.length
      ? `Folder needs attention: ${state.project.errors.join("; ")}`
      : "Data loaded. Review the sample check, then validate the selected analysis before submission.");
  } catch (error) {
    state.project = null;
    elements.project_history.hidden = true;
    elements.validate_button.disabled = true;
    elements.metadata_preview.hidden = false;
    elements.metadata_preview.textContent = error.message;
    setValidation(error.message, "error");
  }
}

function renderProjectDetails() {
  const project = state.project;
  if (!project) return;
  elements.project_history.hidden = false;
  elements.results_path.textContent = project.results_root || "Created with this project";
  elements.reference_condition.innerHTML = project.conditions.map((condition) => `<option value="${escapeHtml(condition)}">${escapeHtml(condition)}</option>`).join("");
  const preferred = project.config.reference_condition;
  if (project.conditions.includes(preferred)) elements.reference_condition.value = preferred;
  elements.cpu_threads.value = Math.min(32, Number(project.config.threads) || 16);
  elements.memory_gb.value = Math.min(256, Number.parseInt(project.config.memory, 10) || 64);
  const configuredHours = configuredWalltimeHours(project.config.time_limit);
  elements.walltime_days.value = Math.floor(configuredHours / 24);
  elements.walltime_hours.value = configuredHours % 24;
  const configuredModule = [
    [elements.run_de, project.config.run_differential_expression && project.conditions.length >= 2],
    [elements.run_rna_variants, project.config.run_rna_variants],
    [elements.run_ase, project.config.run_ase && biologicalPloidy() >= 2],
    [elements.run_trinity, project.config.run_trinity && state.snapshot.trinity_ready],
  ].find((entry) => entry[1] && !entry[0].disabled);
  (configuredModule?.[0] || elements.run_rna_variants).checked = true;
  elements.trinity_min_contig_length.value = project.config.trinity_min_contig_length || 200;
  elements.trinity_normalize_reads.checked = project.config.trinity_normalize_reads !== false;
  elements.de_padj_cutoff.value = project.config.padj_cutoff ?? 0.05;
  elements.de_log2fc_cutoff.value = project.config.log2fc_cutoff ?? 2;
  elements.snv_min_depth.value = project.config.variant_min_depth ?? 10;
  elements.snv_min_quality.value = project.config.variant_min_quality ?? 20;
  elements.ase_min_depth.value = project.config.ase_min_depth ?? 20;
  elements.ase_min_allele_count.value = project.config.ase_min_allele_count ?? 3;
  elements.trimming_mode.value = project.config.trimming_mode || "auto";
  elements.library_type.value = project.config.library_type || "custom_bulk";
  elements.library_prep.value = project.config.library_prep || "";
  elements.adapter_handling.value = project.config.adapter_handling || "detect";
  elements.adapter_read1.value = project.config.adapter_read1 || "";
  elements.adapter_read2.value = project.config.adapter_read2 || "";
  elements.trim_quality_tails.checked = project.config.trim_quality_tails !== false;
  elements.trim_quality_threshold.value = project.config.trim_quality_threshold || 15;
  elements.trim_minimum_length.value = project.config.trim_minimum_length || 30;
  elements.trim_front_read1.value = project.config.trim_front_read1 || 0;
  elements.trim_front_read2.value = project.config.trim_front_read2 || 0;
  elements.trim_tail_read1.value = project.config.trim_tail_read1 || 0;
  elements.trim_tail_read2.value = project.config.trim_tail_read2 || 0;
  elements.umi_status.value = project.config.umi_status || "unknown";
  elements.selection_method.value = project.config.selection_method || "unknown";
  elements.library_strandedness.value = "auto";
  elements.strandedness_reviewed.checked = false;
  renderPreprocessingOptions();
  toggleCards();
  renderReview();
  showResourceError();
}

function selectedOutputs() {
  if (elements.run_de.checked) return ["STAR gene counts", "DESeq2"];
  if (elements.run_rna_variants.checked) return ["RNA variant report"];
  if (elements.run_ase.checked) return ["Genotype-informed site-level ASE"];
  return ["Trinity transcriptome"];
}

function renderReview() {
  if (!state.project) {
    elements.review_card.innerHTML = "<p>Select a ready project to load samples and conditions.</p>";
    return;
  }
  const reference = state.snapshot.references.find((item) => item.id === state.referenceId);
  const trimmingLabels = { auto: "Automatic conservative fastp", none: "QC only · no trimming", custom: `Custom · ${elements.library_prep.value || "preparation required"}` };
  elements.review_card.innerHTML = `<div class="review-list">
    <div class="review-item"><span>Project</span><strong>${escapeHtml(state.project.project)}</strong></div>
    <div class="review-item"><span>Reference</span><strong>${escapeHtml(referenceLabels.get(reference?.id) || reference?.label || state.referenceId)}</strong></div>
    <div class="review-item"><span>Outputs</span><strong>${escapeHtml(selectedOutputs().join(", "))}</strong></div>
    ${elements.run_de.checked || elements.run_trinity.checked ? `<div class="review-item"><span>Strandedness</span><strong>${escapeHtml(elements.library_strandedness.value === "auto" ? "Small STAR check per sample" : `${elements.library_strandedness.value}${elements.strandedness_reviewed.checked ? " · manual review confirmed" : ""}`)}</strong></div>` : ""}
    <div class="review-item"><span>Read preprocessing</span><strong>${escapeHtml(trimmingLabels[elements.trimming_mode.value])}</strong></div>
    <div class="review-item"><span>Resources</span><strong>${escapeHtml(elements.cpu_threads.value)} CPUs · ${escapeHtml(elements.memory_gb.value)} GB RAM · ${escapeHtml(elements.walltime_days.value)} days ${escapeHtml(elements.walltime_hours.value)} hours</strong></div>
  </div>`;
}

function jobStatusClass(status) {
  return ["completed", "needs_review", "failed", "cancelled", "running", "queued", "submitted", "prepared", "submission_failed"].includes(status) ? status : "submitted";
}

function manualInstructions(job) {
  const netid = state.config?.hpc_user || "YOUR_NETID";
  const loginCommand = `ssh ${netid}@discovery.dartmouth.edu`;
  return `<p><strong>Slurm job created, not submitted.</strong> Script location: <code>${escapeHtml(job.slurm_script)}</code>.</p>
    <ol><li>In Terminal on your Mac, log in to Discovery as usual (enter your password in Terminal if prompted):<br><code>${escapeHtml(loginCommand)}</code></li>
    <li>On Discovery, run this command:<br><code>${escapeHtml(job.manual_submit_command)}</code></li></ol>
    <p>The RNA Atlas command submits the job to Slurm and prints its job ID; there is no additional submission command. After it confirms submission, you may exit Discovery. If a DartFS credential is missing, the command will explain how to restore it.</p>`;
}

function renderJobs() {
  const jobs = state.snapshot.jobs || [];
  const renderJob = (job) => {
    const strand = job.artifacts?.strandedness_check;
    const strandDetails = strand ? `<details class="strand-evidence"><summary>Strand-check evidence · ${escapeHtml(strand.project_inference)}</summary>
      <p>${escapeHtml(strand.interpretation)} Selected for this run: <strong>${escapeHtml(strand.resolved_strandedness || "none — review required")}</strong>.</p>
      <div class="sample-table-wrap"><table><thead><tr><th>Sample</th><th>${strand.read_layout === "single" ? "Reads checked" : "Pairs checked"}</th><th>Unstranded</th><th>Forward</th><th>Reverse</th><th>Forward %</th><th>Result</th></tr></thead><tbody>${(strand.samples || []).map((sample) => `<tr><td>${escapeHtml(sample.sample_id)}</td><td>${escapeHtml(sample.sampled_reads ?? sample.sampled_pairs)}</td><td>${escapeHtml(sample.unstranded_assigned)}</td><td>${escapeHtml(sample.forward_assigned)}</td><td>${escapeHtml(sample.reverse_assigned)}</td><td>${sample.forward_fraction === null ? "—" : escapeHtml((100 * sample.forward_fraction).toFixed(1))}</td><td>${escapeHtml(sample.verdict)}</td></tr>`).join("")}</tbody></table></div>
      <p>Full STAR logs, counts, and evidence are in <code>${escapeHtml(job.output_root || "the project result folder")}/00_qc/strandedness/</code>. If review is required, check your library protocol, select an explicit orientation above, confirm review, and create a new job.</p></details>` : "";
    const progress = Number(job.progress || (job.status === "completed" ? 100 : 0));
    const expiresAt = Date.parse(job.download_expires_at || "");
    const tooLarge = Number(job.artifacts?.deliverable_bytes || 0) > 2 * 1024 ** 3;
    const canDownload = ["completed", "needs_review"].includes(job.status) && job.artifacts?.deliverable && !tooLarge && Number.isFinite(expiresAt) && expiresAt > Date.now();
    const download = canDownload
      ? `<a class="download-button" href="/api/jobs/${encodeURIComponent(job.job_id)}/download" download>${job.status === "needs_review" ? "Download evidence ZIP" : "Download ZIP"}</a>`
      : ["completed", "needs_review"].includes(job.status) && job.artifacts?.deliverable ? `<span class="job-expired">${tooLarge ? "Large results" : "Download window ended"}; files remain on DartFS.</span>` : "";
    return `<article class="job-card"><span class="status-badge ${jobStatusClass(job.status)}">${escapeHtml((job.status || "unknown").replaceAll("_", " "))}</span>
      <div class="job-identity"><h3 title="${escapeHtml(job.project_name)}">${escapeHtml(job.project_name)}</h3><code>${escapeHtml(job.job_id)}</code></div>
      <p class="job-message">${escapeHtml(job.stage || "prepared")} · ${progress}% · ${escapeHtml(job.message || "Waiting for status update.")}</p>
      ${download ? `<div class="job-actions">${download}</div>` : ""}
      ${strandDetails}
      ${["prepared", "submission_failed"].includes(job.status) && job.manual_submit_command ? `<details class="prepared-instructions"><summary>How to submit</summary>${manualInstructions(job)}</details>` : ""}</article>`;
  };
  elements.jobs_grid.innerHTML = jobs.length
    ? `${jobs.slice(0, 5).map(renderJob).join("")}${jobs.length > 5 ? `<details class="older-jobs"><summary>Show ${jobs.length - 5} older jobs</summary>${jobs.slice(5).map(renderJob).join("")}</details>` : ""}`
    : "<p>No jobs are associated with this account yet.</p>";
}

async function renderAdmin() {
  const user = state.snapshot.user;
  elements.admin_section.hidden = !user?.is_admin;
  if (!user?.is_admin) return;
  try {
    const payload = await api("/api/admin/users");
    const pending = payload.users.filter((entry) => entry.status !== "approved");
    elements.admin_users.innerHTML = pending.length ? pending.map((entry) => `<div class="user-row"><div><strong>${escapeHtml(entry.display_name || entry.email)}</strong><br><small>${escapeHtml(entry.email)}</small></div><button class="secondary-button approve-user" data-user-id="${escapeHtml(entry.user_id)}" type="button">Approve</button></div>`).join("") : "<p>No users are waiting for approval.</p>";
    document.querySelectorAll(".approve-user").forEach((button) => button.addEventListener("click", async () => {
      await api("/api/admin/approve", { method: "POST", body: JSON.stringify({ user_id: button.dataset.userId }) });
      showToast("User approved.");
      await renderAdmin();
    }));
  } catch (error) { elements.admin_users.innerHTML = `<p>${escapeHtml(error.message)}</p>`; }
}

async function refreshSnapshot({ reloadProject = false } = {}) {
  state.config = await api("/api/config");
  renderService();
  if (state.config.submission_enabled && (!state.config.connected || !state.config.ssh_ready)) {
    elements.submit_button.disabled = true;
    return;
  }
  state.snapshot = await api("/api/snapshot");
  renderAccess();
  if (state.snapshot.user?.status === "approved") {
    renderProjects();
    renderReferences();
    renderJobs();
    await renderAdmin();
    if (reloadProject && state.projectName && state.snapshot.projects.some((project) => project.name === state.projectName)) await loadProject(state.projectName);
  }
}

elements.registration_form.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    await api("/api/register", { method: "POST", body: JSON.stringify({ display_name: elements.display_name.value }) });
    showToast("Registration saved.");
    await refreshSnapshot();
  } catch (error) { showToast(error.message, "error"); }
});

async function openFolderDialog() {
  if (!elements.folder_dialog.open) elements.folder_dialog.showModal();
  elements.folder_list.textContent = "Connecting to Discovery and checking accessible folders…";
  try {
    if (state.config?.submission_enabled && (!state.config.connected || !state.config.ssh_ready)) {
      await api("/api/connect", { method: "POST" });
      state.config = await api("/api/config");
      await refreshSnapshot();
    } else {
      state.config = await api("/api/config");
    }
    renderService();
    if (!state.config.ssh_ready && state.config.submission_enabled) {
      elements.folder_list.textContent = "Discovery is not connected. Double-click mac/connect_discovery.command in your downloaded RNA Atlas folder, enter your own password in Terminal, then click Retry connection. Never enter a password into this page.";
      return;
    }
    const payload = await api("/api/project-folders");
    const folders = payload.folders || [];
    elements.folder_dialog_message.textContent = `Connected as ${state.config.hpc_user}. Choose a prepared project folder.`;
    elements.folder_list.innerHTML = folders.length ? folders.map((folder) => `<button class="folder-choice" type="button" data-folder="${escapeHtml(folder.name)}"><strong>${escapeHtml(folder.name)}</strong><small>${escapeHtml(folder.path)}</small></button>`).join("") : "No accessible project folders found. Create a project folder and its datasets/ inputs on Discovery first, then retry.";
  } catch (error) {
    state.config = { ...state.config, ssh_ready: false };
    renderService();
    elements.folder_list.textContent = error.message;
  }
}

elements.disconnect_discovery.addEventListener("click", async () => {
  try {
    await api("/api/disconnect", { method: "POST" });
    state.config = await api("/api/config");
    state.snapshot = null;
    state.project = null;
    state.projectName = "";
    state.validated = false;
    elements.workspace.hidden = false;
    elements.jobs_section.hidden = true;
    elements.admin_section.hidden = true;
    elements.registration_card.hidden = true;
    elements.new_project_name.value = "";
    elements.new_project_reference.innerHTML = '<option value="">Connect to Discovery to see references</option>';
    elements.create_project_button.disabled = true;
    elements.validate_button.disabled = true;
    elements.submit_button.disabled = true;
    elements.metadata_preview.hidden = true;
    renderDataPaths();
    renderService();
    showToast("Discovery disconnected. Submitted Slurm jobs remain scheduled; their DartFS access still needs valid credentials.");
  } catch (error) { showToast(error.message, "error"); }
});

elements.reconnect_discovery.addEventListener("click", openFolderDialog);
elements.open_project_folder.addEventListener("click", openFolderDialog);
elements.retry_discovery.addEventListener("click", openFolderDialog);
elements.close_folder_dialog.addEventListener("click", () => elements.folder_dialog.close());
elements.folder_list.addEventListener("click", (event) => {
  const choice = event.target.closest("[data-folder]");
  if (!choice) return;
  elements.new_project_name.value = choice.dataset.folder;
  renderDataPaths();
  updateLoadDataButton();
  elements.folder_dialog.close();
  elements.create_project_message.textContent = `Selected ${choice.dataset.folder}. Click Load data to check its sample sheet and FASTQs.`;
});

elements.create_project_form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const name = elements.new_project_name.value.trim();
  const personal = state.config?.portal_mode === "personal";
  const existing = state.snapshot.projects?.find((project) => project.name === name);
  elements.create_project_message.textContent = "Opening project folder and checking sample files…";
  elements.create_project_button.disabled = true;
  try {
    if (name !== state.projectName) {
      state.project = null;
      state.projectName = "";
      state.validated = false;
      elements.validate_button.disabled = true;
      elements.submit_button.disabled = true;
      elements.project_history.hidden = true;
      renderReview();
    }
    if (personal && !existing) {
      const preview = await api(`/api/projects/${encodeURIComponent(name)}/preview`);
      renderMetadataPreview(elements.metadata_preview, preview);
      if (preview.errors?.length || preview.input_checks?.some((sample) => sample.issues?.length)) {
        elements.create_project_message.textContent = "Fix the listed sample sheet or FASTQ problems, then load this folder again.";
        return;
      }
    }
    if (!existing) {
      await api("/api/projects", { method: "POST", body: JSON.stringify({
        name, reference_id: elements.new_project_reference.value,
      }) });
    }
    await refreshSnapshot();
    await selectProject(name);
    elements.create_project_message.textContent = state.project?.errors?.length
      ? "Fix the listed metadata or FASTQ problems, then load this folder again."
      : `Loaded ${name}. Initial data checks passed; previous module results remain in this folder.`;
  } catch (error) {
    elements.create_project_message.textContent = error.message;
    elements.metadata_preview.hidden = false;
    elements.metadata_preview.textContent = error.message;
  }
  finally { updateLoadDataButton(); }
});

elements.new_project_reference.addEventListener("change", () => {
  if (!state.projectName) {
    state.referenceId = elements.new_project_reference.value;
    toggleCards();
  }
});
elements.new_project_name.addEventListener("input", renderDataPaths);

elements.prepare_intake_button.addEventListener("click", async () => {
  elements.intake_message.textContent = "Preparing a private folder on DartFS…";
  try {
    const payload = await api("/api/intake/prepare", { method: "POST", body: JSON.stringify({ project: state.projectName }) });
    state.intakePath = payload.directory;
    elements.intake_message.textContent = `${payload.message} Folder: ${payload.directory}`;
    showToast("Intake folder prepared.");
  } catch (error) { elements.intake_message.textContent = error.message; }
});

elements.read_intake_metadata_button.addEventListener("click", async () => {
  if (!state.projectName) return;
  elements.intake_metadata_preview.textContent = "Reading staged sample metadata…";
  try {
    const preview = await api(`/api/intake/${encodeURIComponent(state.projectName)}/preview`);
    renderMetadataPreview(elements.intake_metadata_preview, preview);
  } catch (error) { elements.intake_metadata_preview.textContent = error.message; }
});

elements.attach_intake_button.addEventListener("click", async () => {
  elements.intake_message.textContent = "Validating staged sample sheet and FASTQs…";
  try {
    const payload = await api("/api/intake/attach", { method: "POST", body: JSON.stringify({ project: state.projectName }) });
    elements.intake_message.textContent = `Imported ${payload.sample_count} validated samples into this project.`;
    showToast("Staged data imported into this project.");
    await refreshSnapshot({ reloadProject: true });
  } catch (error) { elements.intake_message.textContent = error.message; }
});

document.querySelectorAll("[data-toggle-card] input").forEach((input) => input.addEventListener("change", () => { toggleCards(); invalidateValidation(); }));
[elements.cpu_threads, elements.memory_gb, elements.walltime_days, elements.walltime_hours].forEach((element) => element.addEventListener("input", () => { invalidateValidation(); showResourceError(); }));
[elements.reference_condition, elements.verify_md5, elements.validate_fastq,
  elements.trinity_min_contig_length, elements.trinity_normalize_reads, elements.library_strandedness, elements.strandedness_reviewed,
  elements.de_padj_cutoff, elements.de_log2fc_cutoff, elements.snv_min_depth, elements.snv_min_quality,
  elements.ase_min_depth, elements.ase_min_allele_count].forEach((element) => element.addEventListener("change", () => { toggleCards(); invalidateValidation(); }));
[
  elements.trimming_mode, elements.library_type, elements.library_prep, elements.selection_method, elements.umi_status,
  elements.adapter_handling, elements.adapter_read1, elements.adapter_read2,
  elements.trim_quality_tails, elements.trim_quality_threshold, elements.trim_minimum_length,
  elements.trim_front_read1, elements.trim_front_read2, elements.trim_tail_read1, elements.trim_tail_read2,
].forEach((element) => element.addEventListener("change", () => { renderPreprocessingOptions(); invalidateValidation(); }));

elements.validate_button.addEventListener("click", async () => {
  if (!state.projectName) return;
  elements.validate_button.disabled = true;
  setValidation("Checking staged metadata, FASTQs, reference package, and selected analysis…");
  try {
    state.project = await api(`/api/projects/${encodeURIComponent(state.projectName)}`);
    if (state.project.errors.length) throw new Error(state.project.errors.join("; "));
    if (document.querySelectorAll('input[name="analysis-module"]:checked').length !== 1) throw new Error("Choose exactly one analysis module.");
    if (elements.run_de.checked && !state.project.reference_has_annotation) throw new Error("Differential expression requires an annotated reference.");
    if (elements.run_de.checked && state.project.conditions.length < 2) throw new Error("Differential expression requires at least two groups.");
    if (biologicalPloidy() === null) throw new Error("The selected reference has no valid biological ploidy recommendation.");
    if (elements.run_ase.checked && biologicalPloidy() < 2) throw new Error("Allele-specific expression requires a diploid or polyploid sample; this species defaults to haploid.");
    if (elements.run_ase.checked && !state.project.ase_genotypes?.ready) throw new Error(state.project.ase_genotypes?.error || "Add a validated genotype VCF under genotype_VCF/ before running ASE.");
    if (elements.run_trinity.checked && !state.snapshot.trinity_ready) throw new Error("Trinity runtime is not installed on Discovery.");
    if (!state.snapshot.qc_ready) throw new Error("The pinned fastp/FastQC/MultiQC runtime is not installed on Discovery.");
    validatePreprocessing();
    validateDiscoverySettings();
    state.validated = true;
    elements.submit_button.disabled = !state.config.submission_enabled || !state.config.ssh_ready;
    const warnings = state.project.warnings.length ? ` Warnings: ${state.project.warnings.join(" ")}` : "";
    setValidation(`Validation passed for ${state.project.sample_count} samples and ${state.project.conditions.length} groups.${warnings}`, warnings ? "warning" : "success");
    if (!state.config.submission_enabled) showToast("Preview validation passed. Start with Slurm mode to submit.");
  } catch (error) {
    state.validated = false;
    elements.submit_button.disabled = true;
    setValidation(error.message, "error");
  } finally { elements.validate_button.disabled = false; }
});

elements.submit_button.addEventListener("click", async () => {
  if (!state.validated) return;
  elements.submit_button.disabled = true;
  const manual = state.config.portal_mode === "personal";
  elements.manual_handoff.hidden = true;
  setValidation(manual ? "Preparing your Slurm script; no job will be submitted yet…" : "Preparing a guarded result directory and submitting one Slurm job…");
  try {
    const walltimeHours = validateDiscoverySettings();
    const payload = await api("/api/jobs", { method: "POST", body: JSON.stringify({
      project: state.projectName,
      reference_id: state.referenceId,
      threads: Number(elements.cpu_threads.value),
      memory_gb: Number(elements.memory_gb.value),
      walltime_hours: walltimeHours,
      ploidy: biologicalPloidy(),
      run_differential_expression: elements.run_de.checked,
      reference_condition: elements.reference_condition.value,
      padj_cutoff: Number(elements.de_padj_cutoff.value),
      log2fc_cutoff: Number(elements.de_log2fc_cutoff.value),
      run_rna_variants: elements.run_rna_variants.checked,
      variant_min_depth: Number(elements.snv_min_depth.value),
      variant_min_quality: Number(elements.snv_min_quality.value),
      run_ase: elements.run_ase.checked,
      ase_min_depth: Number(elements.ase_min_depth.value),
      ase_min_allele_count: Number(elements.ase_min_allele_count.value),
      ase_source: "external_dna_vcf",
      run_trinity: elements.run_trinity.checked,
      trinity_min_contig_length: Number(elements.trinity_min_contig_length.value),
      trinity_normalize_reads: elements.trinity_normalize_reads.checked,
      run_unmapped_rna: false,
      verify_md5: elements.verify_md5.checked,
      validate_fastq_structure: elements.validate_fastq.checked,
      ...preprocessingPayload(),
    }) });
    if (manual) {
      if (!payload.manual_submit_command || !payload.slurm_script || payload.status !== "prepared") {
        throw new Error("The prepared job did not include a safe Terminal submission command.");
      }
      elements.manual_handoff.innerHTML = manualInstructions(payload);
      elements.manual_handoff.hidden = false;
      showToast(`Prepared RNA Atlas job ${payload.job_id}. Submit it from Discovery Terminal.`);
    } else {
      showToast(`Submitted Slurm job ${payload.slurm_job_id || payload.job_id}.`);
    }
    state.validated = false;
    await refreshSnapshot();
    setValidation(manual ? "Script ready. Follow the Terminal commands below to submit the job." : "Job submitted. Live status appears below.", "success");
  } catch (error) {
    state.validated = false;
    elements.submit_button.disabled = true;
    setValidation(error.message, "error");
  }
});

elements.refresh_service.addEventListener("click", () => state.config?.connected
  ? refreshSnapshot({ reloadProject: true }) : openFolderDialog());
elements.refresh_jobs.addEventListener("click", () => refreshSnapshot());
async function initialize() {
  try {
    renderPreprocessingOptions();
    state.config = await api("/api/config");
    renderService();
    if (state.config.submission_enabled && !state.config.connected) {
      elements.workspace.hidden = false;
      elements.create_project_button.disabled = true;
      elements.new_project_reference.innerHTML = '<option value="">Connect to Discovery to see references</option>';
      renderDataPaths();
      toggleCards();
    } else {
      await refreshSnapshot();
    }
    state.polling = window.setInterval(async () => {
      if (!state.config?.connected || state.pollingInProgress) return;
      state.pollingInProgress = true;
      try {
        await refreshSnapshot();
      } catch (error) {
        state.config = { ...state.config, ssh_ready: false };
        renderService();
        elements.submit_button.disabled = true;
      } finally {
        state.pollingInProgress = false;
      }
    }, 15000);
  } catch (error) {
    elements.cluster_dot.className = "status-dot error";
    elements.cluster_label.textContent = "Service unavailable";
    showToast(error.message, "error");
  }
}

initialize();
