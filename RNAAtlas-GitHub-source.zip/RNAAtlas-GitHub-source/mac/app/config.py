from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


LOCAL_ROOT = Path(__file__).resolve().parents[1]
APP_TOKEN = os.environ.get("RNASEQ_PORTAL_TOKEN", "")
COOKIE_NAME = "rnaseq_portal_session"


@dataclass(frozen=True)
class PortalSettings:
    execution_backend: str
    email: str
    ssh_host: str
    remote_root: str
    mount_root: Path
    kerberos_cache: str | None
    ssh_control_path: str | None
    ssh_known_hosts: str | None = None
    timeout_seconds: int = 60
    trust_email_header: bool = False
    email_header: str = "X-Forwarded-Email"
    secure_cookie: bool = False
    proxy_secret: str = ""
    portal_mode: str = "service"
    shared_root: str = ""

    @classmethod
    def from_environment(cls) -> "PortalSettings":
        backend = os.environ.get("RNASEQ_EXECUTION_BACKEND", "mounted").strip().lower()
        if backend not in {"mounted", "slurm"}:
            raise ValueError("RNASEQ_EXECUTION_BACKEND must be mounted or slurm.")
        portal_mode = os.environ.get("RNASEQ_PORTAL_MODE", "service").strip().lower()
        if portal_mode not in {"service", "personal"}:
            raise ValueError("RNASEQ_PORTAL_MODE must be service or personal.")
        return cls(
            execution_backend=backend,
            email=os.environ.get("RNASEQ_PORTAL_EMAIL", "f007qkp@dartmouth.edu").strip().lower(),
            ssh_host=os.environ.get("RNASEQ_SSH_HOST", "f008qv8@slurm-fe01-prd.dartmouth.edu"),
            remote_root=os.environ.get(
                "RNASEQ_REMOTE_ROOT", "/dartfs/rc/lab/L/LiaoC/Service_Account/RNAseq_atlas",
            ).rstrip("/"),
            mount_root=Path(
                os.environ.get("RNASEQ_MOUNT_ROOT", "/Volumes/LiaoC/Service_Account/RNAseq_atlas")
            ).expanduser(),
            kerberos_cache=os.environ.get("RNASEQ_KRB5_CACHE") or None,
            ssh_control_path=os.environ.get("RNASEQ_SSH_CONTROL_PATH") or None,
            ssh_known_hosts=os.environ.get("RNASEQ_SSH_KNOWN_HOSTS") or None,
            trust_email_header=os.environ.get("RNASEQ_TRUST_EMAIL_HEADER", "0") == "1",
            email_header=os.environ.get("RNASEQ_EMAIL_HEADER", "X-Forwarded-Email").strip(),
            secure_cookie=os.environ.get("RNASEQ_COOKIE_SECURE", "0") == "1",
            proxy_secret=os.environ.get("RNASEQ_PROXY_SECRET", ""),
            portal_mode=portal_mode,
            shared_root=os.environ.get(
                "RNASEQ_SHARED_ROOT", "/dartfs/rc/lab/L/LiaoC/Service_Account/RNAseq_atlas",
            ).rstrip("/"),
        )
