from __future__ import annotations

import hmac
import re
import secrets
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response
from starlette.background import BackgroundTask
from starlette.concurrency import run_in_threadpool
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

from app.config import APP_TOKEN, COOKIE_NAME, PortalSettings
from app.hpc import HpcServiceClient, HpcServiceError, HpcValidationError


STATIC_DIR = Path(__file__).resolve().parent / "static"
TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"
SETTINGS = PortalSettings.from_environment()
HPC = HpcServiceClient(SETTINGS)
MAX_GENOTYPE_UPLOAD_BYTES = 5 * 1024 * 1024 * 1024
CONNECTION_COOKIE_NAME = "rnaseq_discovery_connection"
CONNECTION_TOKEN = secrets.token_urlsafe(32)


class RegistrationRequest(BaseModel):
    display_name: str = Field(min_length=1, max_length=100)


class ProjectRequest(BaseModel):
    name: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")
    organism: str = Field(default="", max_length=120)
    description: str = Field(default="", max_length=1000)
    reference_id: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,119}$")


class JobRequest(BaseModel):
    project: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")
    reference_id: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,119}$")
    threads: int = Field(default=16, ge=1, le=32, strict=True)
    memory_gb: int = Field(default=64, ge=8, le=256, strict=True)
    walltime_hours: int = Field(default=48, ge=1, le=720, strict=True)
    ploidy: int = Field(default=2, ge=1, le=16, strict=True)
    run_differential_expression: bool = True
    reference_condition: str = Field(default="", max_length=120)
    padj_cutoff: float = Field(default=0.05, gt=0.0, le=1.0, allow_inf_nan=False)
    log2fc_cutoff: float = Field(default=2.0, ge=0.0, le=20.0, allow_inf_nan=False)
    run_rna_variants: bool = False
    variant_min_depth: int = Field(default=10, ge=1, le=10000, strict=True)
    variant_min_quality: float = Field(default=20.0, ge=0.0, le=1000.0, allow_inf_nan=False)
    run_ase: bool = False
    ase_min_depth: int = Field(default=20, ge=1, le=10000, strict=True)
    ase_min_allele_count: int = Field(default=3, ge=0, le=1000, strict=True)
    ase_source: str = Field(default="external_dna_vcf", pattern=r"^external_dna_vcf$")
    run_trinity: bool = False
    trinity_min_contig_length: int = Field(default=200, ge=100, le=10000)
    trinity_normalize_reads: bool = True
    run_unmapped_rna: bool = False
    unmapped_rna_mode: str = Field(default="rna_virus", pattern=r"^(transcripts|rna_virus)$")
    unmapped_rna_min_pairs: int = Field(default=1000, ge=1, le=1000000000)
    unmapped_rna_min_contig_length: int = Field(default=200, ge=100, le=10000)
    unmapped_rna_host_min_identity: float = Field(default=90.0, ge=50.0, le=100.0)
    unmapped_rna_host_min_query_coverage: float = Field(default=80.0, ge=10.0, le=100.0)
    unmapped_rna_blast_evalue: float = Field(default=1e-10, gt=0.0, le=1.0)
    candidate_cross_min_identity: float = Field(default=95.0, ge=50.0, le=100.0)
    candidate_cross_min_shorter_coverage: float = Field(default=80.0, ge=10.0, le=100.0)
    verify_md5: bool = True
    validate_fastq_structure: bool = True
    trimming_mode: str = Field(default="auto", pattern=r"^(auto|none|custom)$")
    library_type: str = Field(
        default="standard_bulk",
        pattern=r"^(standard_bulk|custom_bulk|small_rna|three_prime|five_prime|single_cell)$",
    )
    library_prep: str = Field(default="", max_length=240)
    adapter_handling: str = Field(default="detect", pattern=r"^(detect|provided|none)$")
    adapter_read1: str = Field(default="", pattern=r"^(|[ACGTNacgtn]{6,200})$")
    adapter_read2: str = Field(default="", pattern=r"^(|[ACGTNacgtn]{6,200})$")
    trim_quality_tails: bool = True
    trim_quality_threshold: int = Field(default=15, ge=5, le=30)
    trim_minimum_length: int = Field(default=30, ge=15, le=500)
    trim_front_read1: int = Field(default=0, ge=0, le=100)
    trim_front_read2: int = Field(default=0, ge=0, le=100)
    trim_tail_read1: int = Field(default=0, ge=0, le=100)
    trim_tail_read2: int = Field(default=0, ge=0, le=100)
    umi_status: str = Field(default="unknown", pattern=r"^(none|unknown|present)$")
    selection_method: str = Field(default="unknown", pattern=r"^(unknown|poly_a|rrna_depletion|none|other)$")
    strandedness: str = Field(default="project_default", pattern=r"^(project_default|unstranded|forward|reverse)$")
    prior_processing: str = Field(default="", max_length=500)


class ReferenceRequest(BaseModel):
    reference_id: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,119}$")
    label: str = Field(default="", max_length=160)
    organism: str = Field(default="", max_length=160)
    assembly: str = Field(default="", max_length=160)
    recommended_ploidy: int = Field(default=2, ge=1, le=16)
    max_read_length: int = Field(default=150, ge=25, le=1000)
    annotation_mode: str = Field(default="provided", pattern=r"^(provided|prokka|none)$")
    prokka_kingdom: str = Field(default="Bacteria", pattern=r"^Bacteria$")
    confirm_bacterial_genome: bool = False


class ApprovalRequest(BaseModel):
    user_id: str = Field(min_length=8, max_length=128)


class IntakeRequest(BaseModel):
    project: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")


class DatasetRequest(IntakeRequest):
    dataset: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")


def is_authorized(request: Request) -> bool:
    if SETTINGS.trust_email_header:
        candidate = request.headers.get("x-rnaseq-proxy-secret", "")
        email = request.headers.get(SETTINGS.email_header, "").strip().lower()
        return bool(
            SETTINGS.proxy_secret and candidate
            and hmac.compare_digest(candidate, SETTINGS.proxy_secret)
            and re.fullmatch(r"[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@dartmouth\.edu", email)
        )
    if not APP_TOKEN:
        return False
    candidate = (
        request.headers.get("x-rnaseq-token")
        or request.cookies.get(COOKIE_NAME)
        or request.query_params.get("token")
    )
    return bool(candidate and hmac.compare_digest(candidate, APP_TOKEN))


def require_authorization(request: Request) -> None:
    if not is_authorized(request):
        raise HTTPException(status_code=401, detail="An authenticated portal session is required.")


def discovery_connected(request: Request) -> bool:
    if not HPC.submission_enabled:
        return True
    value = request.cookies.get(CONNECTION_COOKIE_NAME, "")
    return bool(value and hmac.compare_digest(value, CONNECTION_TOKEN))


def trusted_email(request: Request) -> str:
    if SETTINGS.trust_email_header:
        email = request.headers.get(SETTINGS.email_header, "").strip().lower()
    else:
        email = SETTINGS.email
    if not email:
        raise HTTPException(status_code=401, detail="An authenticated Dartmouth email is required.")
    return email


app = FastAPI(
    title="RNA Atlas HPC",
    description="Reference-guided and de novo RNA-seq analysis on Dartmouth Discovery",
    version="0.2.0",
)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
templates = Jinja2Templates(directory=TEMPLATE_DIR)


@app.middleware("http")
async def require_discovery_connection(request: Request, call_next):
    if (request.url.path.startswith("/api/")
            and request.url.path not in {"/api/config", "/api/connect", "/api/disconnect"}
            and is_authorized(request) and not discovery_connected(request)):
        return JSONResponse(status_code=409, content={"detail": "Discovery is disconnected. Click Open project folder to connect."})
    return await call_next(request)


@app.exception_handler(HpcServiceError)
async def hpc_error_handler(_: Request, error: HpcServiceError) -> JSONResponse:
    return JSONResponse(status_code=503, content={"detail": str(error)})


@app.exception_handler(HpcValidationError)
async def hpc_validation_error_handler(_: Request, error: HpcValidationError) -> JSONResponse:
    return JSONResponse(status_code=400, content={"detail": str(error)})


@app.exception_handler(ValueError)
async def value_error_handler(_: Request, error: ValueError) -> JSONResponse:
    return JSONResponse(status_code=400, content={"detail": str(error)})


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    if not is_authorized(request):
        return HTMLResponse(
            "<h1>RNA Atlas</h1><p>Sign in through the lab portal or open the private link provided by the Mac host.</p>", status_code=401,
        )
    if not SETTINGS.trust_email_header and APP_TOKEN and request.query_params.get("token") == APP_TOKEN:
        response = RedirectResponse(url="/", status_code=303)
        response.set_cookie(
            COOKIE_NAME,
            APP_TOKEN,
            httponly=True,
            secure=SETTINGS.secure_cookie,
            samesite="strict",
            max_age=24 * 60 * 60,
        )
        return response
    return templates.TemplateResponse(request=request, name="index.html", context={})


@app.get("/healthz")
async def healthz() -> dict:
    mount_ready = SETTINGS.mount_root.is_dir() if SETTINGS.execution_backend == "mounted" else False
    return {"status": "ok", "mount_ready": mount_ready}


@app.get("/favicon.ico", include_in_schema=False)
async def favicon() -> Response:
    return Response(status_code=204)


@app.get("/api/config", dependencies=[Depends(require_authorization)])
async def application_config(request: Request) -> dict:
    connected = discovery_connected(request)
    return {
        "email": trusted_email(request),
        "execution_backend": SETTINGS.execution_backend,
        "submission_enabled": HPC.submission_enabled,
        "ssh_ready": await run_in_threadpool(HPC.ssh_connection_ready) if connected else False,
        "connected": connected,
        "hpc_user": SETTINGS.ssh_host.split("@", 1)[0],
        "remote_root": SETTINGS.remote_root,
        "mount_root": str(SETTINGS.mount_root),
        "portal_mode": SETTINGS.portal_mode,
    }


@app.post("/api/connect", dependencies=[Depends(require_authorization)])
async def connect_discovery() -> Response:
    if not HPC.submission_enabled:
        raise HTTPException(status_code=400, detail="Mounted preview does not use a Discovery SSH connection.")
    if not await run_in_threadpool(HPC.connect):
        raise HTTPException(status_code=503, detail="Discovery authentication is unavailable. Sign in using your own launcher or Terminal, then retry. This page does not accept passwords.")
    response = JSONResponse({"connected": True})
    response.set_cookie(
        CONNECTION_COOKIE_NAME, CONNECTION_TOKEN, httponly=True,
        secure=SETTINGS.secure_cookie, samesite="strict", max_age=24 * 60 * 60,
    )
    return response


@app.post("/api/disconnect", dependencies=[Depends(require_authorization)])
async def disconnect_discovery() -> Response:
    response = JSONResponse({"connected": False})
    response.delete_cookie(CONNECTION_COOKIE_NAME, secure=SETTINGS.secure_cookie, samesite="strict")
    return response


@app.get("/api/snapshot", dependencies=[Depends(require_authorization)])
async def snapshot(request: Request) -> dict:
    return HPC.snapshot(trusted_email(request))


@app.post("/api/register", dependencies=[Depends(require_authorization)])
async def register(request: Request, payload: RegistrationRequest) -> dict:
    return HPC.register(trusted_email(request), payload.display_name)


@app.get("/api/projects/{project_name}", dependencies=[Depends(require_authorization)])
async def project(project_name: str, request: Request, reference_id: str = "") -> dict:
    return HPC.project(trusted_email(request), project_name, reference_id)


@app.post("/api/projects", status_code=201, dependencies=[Depends(require_authorization)])
async def create_project(request: Request, payload: ProjectRequest) -> dict:
    return HPC.create_project({"email": trusted_email(request), **payload.model_dump()})


@app.post("/api/intake/prepare", status_code=201, dependencies=[Depends(require_authorization)])
async def prepare_intake(request: Request, payload: IntakeRequest) -> dict:
    return HPC.prepare_intake({"email": trusted_email(request), **payload.model_dump()})


@app.post("/api/intake/attach", dependencies=[Depends(require_authorization)])
async def attach_intake(request: Request, payload: IntakeRequest) -> dict:
    return await run_in_threadpool(HPC.attach_intake, {"email": trusted_email(request), **payload.model_dump()})


@app.get("/api/datasets", dependencies=[Depends(require_authorization)])
async def datasets(request: Request) -> dict:
    return HPC.datasets(trusted_email(request))


@app.get("/api/project-folders", dependencies=[Depends(require_authorization)])
async def project_folders(request: Request) -> dict:
    return HPC.project_folders(trusted_email(request))


@app.get("/api/projects/{project_name}/preview", dependencies=[Depends(require_authorization)])
async def prepared_project_preview(request: Request, project_name: str) -> dict:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", project_name):
        raise HTTPException(status_code=422, detail="Invalid project name.")
    return HPC.prepared_project_preview(trusted_email(request), project_name)


@app.get("/api/datasets/{dataset_name}/preview", dependencies=[Depends(require_authorization)])
async def dataset_preview(request: Request, dataset_name: str) -> dict:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", dataset_name):
        raise HTTPException(status_code=422, detail="Invalid dataset name.")
    return HPC.dataset_preview(trusted_email(request), dataset_name)


@app.get("/api/intake/{project_name}/preview", dependencies=[Depends(require_authorization)])
async def intake_preview(request: Request, project_name: str) -> dict:
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", project_name):
        raise HTTPException(status_code=422, detail="Invalid project name.")
    return HPC.intake_preview(trusted_email(request), project_name)


@app.post("/api/intake/from-dataset", dependencies=[Depends(require_authorization)])
async def attach_dataset(request: Request, payload: DatasetRequest) -> dict:
    return await run_in_threadpool(HPC.attach_dataset, {"email": trusted_email(request), **payload.model_dump()})


@app.post("/api/projects/{project_name}/ase-genotypes", status_code=201, dependencies=[Depends(require_authorization)])
async def upload_ase_genotypes(
    project_name: str,
    request: Request,
    reference_id: str = Form(...),
    vcf_file: UploadFile = File(...),
    sample_map_file: Optional[UploadFile] = File(default=None),
) -> dict:
    vcf_filename = Path(vcf_file.filename or "").name
    lowered_filename = vcf_filename.lower()
    if not (lowered_filename.endswith(".vcf") or lowered_filename.endswith(".vcf.gz")):
        raise HTTPException(status_code=400, detail="Upload a pre-called genotype file ending in .vcf or .vcf.gz.")
    if not vcf_file.size:
        raise HTTPException(status_code=400, detail="The uploaded genotype VCF is empty.")
    if vcf_file.size > MAX_GENOTYPE_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="The genotype VCF exceeds the 5 GiB portal upload limit.")
    if sample_map_file:
        map_filename = Path(sample_map_file.filename or "").name
        if not map_filename.lower().endswith(".tsv"):
            raise HTTPException(status_code=400, detail="The optional ASE sample map must be a TSV file.")
        if not sample_map_file.size:
            raise HTTPException(status_code=400, detail="The uploaded ASE sample map is empty.")
    return HPC.upload_ase_genotypes(
        trusted_email(request),
        project_name,
        reference_id,
        vcf_file.file,
        vcf_filename,
        sample_map_file.file if sample_map_file else None,
    )


@app.post("/api/references/stage", status_code=201, dependencies=[Depends(require_authorization)])
async def stage_reference(request: Request, payload: ReferenceRequest) -> dict:
    return HPC.stage_reference({"email": trusted_email(request), **payload.model_dump()})


@app.post("/api/references/build", status_code=201, dependencies=[Depends(require_authorization)])
async def build_reference(request: Request, payload: ReferenceRequest) -> dict:
    return HPC.build_reference({"email": trusted_email(request), **payload.model_dump()})


@app.post("/api/jobs", status_code=201, dependencies=[Depends(require_authorization)])
async def create_job(request: Request, payload: JobRequest) -> dict:
    if sum((payload.run_differential_expression, payload.run_rna_variants, payload.run_ase, payload.run_trinity)) != 1:
        raise HTTPException(status_code=400, detail="Choose exactly one analysis module per job.")
    current_snapshot = HPC.snapshot(trusted_email(request))
    if not current_snapshot.get("qc_ready"):
        raise HTTPException(status_code=409, detail="The pinned fastp/FastQC/MultiQC runtime is not installed on Discovery yet.")
    if payload.run_trinity and not current_snapshot.get("trinity_ready"):
        raise HTTPException(status_code=409, detail="Trinity is not installed on Discovery yet.")
    return HPC.submit({"email": trusted_email(request), **payload.model_dump()})


@app.get("/api/jobs/{job_id}", dependencies=[Depends(require_authorization)])
async def job(job_id: str, request: Request) -> dict:
    return HPC.job(trusted_email(request), job_id)


@app.get("/api/admin/users", dependencies=[Depends(require_authorization)])
async def users(request: Request) -> dict:
    return HPC.users(trusted_email(request))


@app.post("/api/admin/approve", dependencies=[Depends(require_authorization)])
async def approve(request: Request, payload: ApprovalRequest) -> dict:
    return HPC.approve(trusted_email(request), payload.user_id)


@app.get("/api/jobs/{job_id}/download", dependencies=[Depends(require_authorization)])
async def download(job_id: str, request: Request):
    payload = HPC.download(trusted_email(request), job_id)
    path = Path(payload["local_path"])
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Result bundle is not available.")
    background = BackgroundTask(path.unlink, missing_ok=True) if payload.get("temporary") else None
    return FileResponse(
        path,
        filename=Path(payload["filename"]).name,
        media_type="application/zip",
        background=background,
    )
