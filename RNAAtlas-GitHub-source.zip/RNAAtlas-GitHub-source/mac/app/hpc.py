from __future__ import annotations

import json
import os
import re
import secrets
import shlex
import subprocess
import sys
import tempfile
from pathlib import Path
from pathlib import PurePosixPath
from typing import BinaryIO

from app.config import PortalSettings


APPROVED_SSH_HOST = "f008qv8@slurm-fe01-prd.dartmouth.edu"
APPROVED_REMOTE_ROOT = "/dartfs/rc/lab/L/LiaoC/Service_Account/RNAseq_atlas"
APPROVED_LAB_ROOT = "/dartfs/rc/lab/L/LiaoC"
DISCOVERY_HOST = "discovery.dartmouth.edu"
PROJECT_NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")


class HpcServiceError(RuntimeError):
    pass


class HpcValidationError(HpcServiceError):
    pass


class HpcServiceClient:
    def __init__(self, settings: PortalSettings | None = None) -> None:
        self.settings = settings or PortalSettings.from_environment()
        if self.settings.portal_mode == "personal":
            identity = self.settings.ssh_host.split("@")
            if (len(identity) != 2 or identity[1] != DISCOVERY_HOST
                    or not re.fullmatch(r"[a-z][a-z0-9]{2,31}", identity[0])
                    or self.settings.email != identity[0] + "@dartmouth.edu"):
                raise HpcServiceError("Personal mode requires the member's own Discovery NetID and matching email.")
            root = PurePosixPath(self.settings.remote_root)
            lab = PurePosixPath(APPROVED_LAB_ROOT)
            service = PurePosixPath(APPROVED_LAB_ROOT) / "Service_Account"
            if (self.settings.execution_backend != "slurm" or lab not in root.parents
                    or root == service or service in root.parents
                    or ".." in root.parts or self.settings.shared_root != APPROVED_REMOTE_ROOT
                    or self.settings.trust_email_header):
                raise HpcServiceError("Personal mode requires a private lab workspace outside the service-account tree.")
        elif self.settings.ssh_host != APPROVED_SSH_HOST or self.settings.remote_root != APPROVED_REMOTE_ROOT:
            raise HpcServiceError("Refusing an unapproved service-account Discovery destination.")
        if self.settings.execution_backend == "slurm":
            if self.settings.ssh_known_hosts and not Path(self.settings.ssh_known_hosts).is_file():
                raise HpcServiceError("The configured Discovery SSH host key file is unavailable.")
            if self.settings.portal_mode != "personal" and not self.settings.ssh_known_hosts:
                raise HpcServiceError("The pinned Discovery SSH host key file is unavailable.")

    @property
    def submission_enabled(self) -> bool:
        return self.settings.execution_backend == "slurm"

    def snapshot(self, email: str) -> dict:
        return self._read(["snapshot", "--email", email])

    def register(self, email: str, display_name: str) -> dict:
        return self._write(["register", "--email", email, "--display-name", display_name])

    def project(self, email: str, name: str, reference_id: str = "") -> dict:
        arguments = ["project", "--email", email, "--name", name]
        if reference_id:
            arguments.extend(["--reference-id", reference_id])
        return self._read(arguments)

    def create_project(self, request: dict) -> dict:
        return self._write(["create-project", "--request-json", json.dumps(request, separators=(",", ":"))])

    def prepare_intake(self, request: dict) -> dict:
        return self._write(["prepare-intake", "--request-json", json.dumps(request, separators=(",", ":"))])

    def attach_intake(self, request: dict) -> dict:
        return self._write(
            ["attach-intake", "--request-json", json.dumps(request, separators=(",", ":"))],
            timeout_seconds=300,
        )

    def datasets(self, email: str) -> dict:
        if self.settings.portal_mode != "personal":
            raise HpcServiceError("Dataset browsing requires personal mode.")
        return self._read(["datasets", "--email", email])

    def project_folders(self, email: str) -> dict:
        return self._read(["project-folders", "--email", email])

    def prepared_project_preview(self, email: str, name: str) -> dict:
        if self.settings.portal_mode != "personal":
            raise HpcServiceError("Prepared project preview requires personal mode.")
        return self._read(["prepared-project-preview", "--email", email, "--name", name])

    def dataset_preview(self, email: str, dataset: str) -> dict:
        if self.settings.portal_mode != "personal":
            raise HpcServiceError("Dataset preview requires personal mode.")
        return self._read(["dataset-preview", "--email", email, "--dataset", dataset])

    def intake_preview(self, email: str, project: str) -> dict:
        return self._read(["intake-preview", "--email", email, "--project", project])

    def attach_dataset(self, request: dict) -> dict:
        if self.settings.portal_mode != "personal":
            raise HpcServiceError("Dataset selection requires personal mode.")
        return self._write(
            ["attach-dataset", "--request-json", json.dumps(request, separators=(",", ":"))],
            timeout_seconds=300,
        )

    def stage_reference(self, request: dict) -> dict:
        if self.settings.portal_mode == "personal":
            raise HpcServiceError("Personal mode uses preinstalled read-only lab references.")
        return self._write(["stage-reference", "--request-json", json.dumps(request, separators=(",", ":"))])

    def build_reference(self, request: dict) -> dict:
        if self.settings.portal_mode == "personal":
            raise HpcServiceError("Personal mode uses preinstalled read-only lab references.")
        if not self.submission_enabled:
            raise HpcServiceError("Reference builds require the Discovery Slurm backend.")
        return self._write(["build-reference", "--request-json", json.dumps(request, separators=(",", ":"))])

    def upload_ase_genotypes(
        self,
        email: str,
        project_name: str,
        reference_id: str,
        vcf_stream: BinaryIO,
        vcf_filename: str,
        sample_map_stream: BinaryIO | None = None,
    ) -> dict:
        if not self.submission_enabled:
            raise HpcServiceError("Genotype VCF uploads require the Discovery backend.")
        if not PROJECT_NAME_PATTERN.fullmatch(project_name):
            raise HpcServiceError("Invalid project name.")
        lowered_filename = vcf_filename.lower()
        if not (lowered_filename.endswith(".vcf") or lowered_filename.endswith(".vcf.gz")):
            raise HpcServiceError("The genotype file must end in .vcf or .vcf.gz.")
        self.project(email, project_name, reference_id)
        upload_token = secrets.token_hex(12)
        input_subdirectory = "/datasets" if self.settings.portal_mode == "personal" else ""
        project_prefix = "" if self.settings.portal_mode == "personal" else "/projects"
        metadata_root = "{}{}/{}{}/meta_data".format(self.settings.remote_root, project_prefix, project_name, input_subdirectory)
        vcf_suffix = ".vcf.gz" if lowered_filename.endswith(".vcf.gz") else ".vcf"
        vcf_upload_path = "{}/.dna_genotypes.upload.{}{}".format(metadata_root, upload_token, vcf_suffix)
        map_upload_path = "{}/.ase_genotype_map.upload.{}.tsv".format(metadata_root, upload_token) if sample_map_stream else ""
        uploaded_paths = []
        try:
            self._upload_remote_stream(vcf_stream, vcf_upload_path)
            uploaded_paths.append(vcf_upload_path)
            if sample_map_stream and map_upload_path:
                self._upload_remote_stream(sample_map_stream, map_upload_path)
                uploaded_paths.append(map_upload_path)
            request = {
                "email": email,
                "project": project_name,
                "reference_id": reference_id,
                "vcf_upload_path": vcf_upload_path,
                "sample_map_upload_path": map_upload_path,
            }
            return self._write([
                "install-ase-genotypes", "--request-json", json.dumps(request, separators=(",", ":")),
            ])
        finally:
            self._remove_remote_uploads(uploaded_paths)

    def submit(self, request: dict) -> dict:
        if not self.submission_enabled:
            raise HpcServiceError("Slurm submission is disabled while the portal runs in mounted preview mode.")
        arguments = ["submit", "--request-json", json.dumps(request, separators=(",", ":"))]
        if self.settings.portal_mode == "personal":
            arguments.append("--prepare-only")
        return self._write(arguments)

    def job(self, email: str, job_id: str) -> dict:
        if self.settings.portal_mode != "personal" and self.settings.mount_root.is_dir():
            snapshot = self.snapshot(email)
            for job in snapshot.get("jobs", []):
                if job.get("job_id") == job_id:
                    return job
            raise HpcServiceError("Job not found for this account.")
        return self._read(["job", "--email", email, "--job-id", job_id])

    def users(self, admin_email: str) -> dict:
        return self._read(["users", "--admin-email", admin_email])

    def approve(self, admin_email: str, user_id: str) -> dict:
        return self._write(["approve", "--admin-email", admin_email, "--user-id", user_id])

    def download(self, email: str, job_id: str) -> dict:
        payload = self._read(["download", "--email", email, "--job-id", job_id])
        if self.settings.portal_mode != "personal" and self.settings.mount_root.is_dir():
            payload["local_path"] = str(self.resolve_mounted_path(payload["path"]))
            payload["temporary"] = False
            return payload
        if self.settings.execution_backend != "slurm":
            raise HpcServiceError("The mounted DartFS result bundle is unavailable.")
        payload["local_path"] = str(self._download_remote_file(payload["path"], payload.get("size")))
        payload["temporary"] = True
        return payload

    def resolve_remote_path(self, remote_path: str) -> str:
        candidate = PurePosixPath(str(remote_path))
        root = PurePosixPath(self.settings.remote_root)
        if candidate != root and root not in candidate.parents:
            raise HpcServiceError("Refusing to download a path outside the RNA-seq service root.")
        return str(candidate)

    def resolve_mounted_path(self, remote_or_mounted_path: str) -> Path:
        value = str(remote_or_mounted_path)
        if value == self.settings.remote_root or value.startswith(self.settings.remote_root + "/"):
            value = str(self.settings.mount_root) + value[len(self.settings.remote_root):]
        candidate = Path(value).resolve(strict=False)
        mount_root = self.settings.mount_root.resolve(strict=False)
        if candidate != mount_root and mount_root not in candidate.parents:
            raise HpcServiceError("Refusing an output path outside the mounted RNA-seq root.")
        return candidate

    def _download_remote_file(self, remote_path: str, expected_size: int | None = None) -> Path:
        approved_path = self.resolve_remote_path(remote_path)
        descriptor, temporary_name = tempfile.mkstemp(prefix="rnaseq-atlas-", suffix=".zip")
        os.close(descriptor)
        destination = Path(temporary_name)
        remote_command = "cat -- {}".format(shlex.quote(approved_path))
        try:
            with destination.open("wb") as output:
                completed = subprocess.run(
                    [*self._ssh_command(), remote_command],
                    check=False,
                    stdout=output,
                    stderr=subprocess.PIPE,
                    timeout=3600,
                    env=self._ssh_environment(),
                )
            if completed.returncode != 0:
                detail = completed.stderr.decode(errors="replace").strip()
                raise HpcServiceError(detail or "Discovery could not transfer the result bundle.")
            if expected_size is not None and destination.stat().st_size != int(expected_size):
                raise HpcServiceError("The transferred result bundle is incomplete.")
            return destination
        except HpcServiceError:
            destination.unlink(missing_ok=True)
            raise
        except (OSError, subprocess.TimeoutExpired, ValueError) as error:
            destination.unlink(missing_ok=True)
            raise HpcServiceError("Could not download the result bundle from Discovery: {}".format(error)) from error

    def ssh_connection_ready(self) -> bool:
        if not self.submission_enabled:
            return False
        if self.settings.portal_mode == "personal":
            if not self.settings.ssh_control_path:
                return False
            command = [
                "ssh", "-O", "check", "-S", self.settings.ssh_control_path,
                "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
                self.settings.ssh_host,
            ]
        elif self.settings.ssh_control_path:
            command = [
                "ssh", "-O", "check", "-o", "ControlPath={}".format(self.settings.ssh_control_path),
                self.settings.ssh_host,
            ]
        else:
            return False
        try:
            completed = subprocess.run(
                command,
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=10,
                env=self._ssh_environment(),
            )
        except (OSError, subprocess.TimeoutExpired):
            return False
        if completed.returncode != 0:
            return False
        if self.settings.portal_mode == "personal":
            try:
                completed = subprocess.run(
                    [*self._ssh_command(), "test \"$(id -un)\" = {} && klist -s".format(
                        shlex.quote(self.settings.ssh_host.split("@", 1)[0]),
                    )],
                    check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    timeout=10, env=self._ssh_environment(),
                )
            except (OSError, subprocess.TimeoutExpired):
                return False
            return completed.returncode == 0
        return True

    def connect(self) -> bool:
        if not self.submission_enabled:
            return False
        if self.ssh_connection_ready():
            return True
        if self.settings.portal_mode == "personal" or not self.settings.ssh_control_path:
            return False
        command = [
            "ssh", "-MNf", "-o", "BatchMode=yes", "-o", "GSSAPIAuthentication=yes",
            "-o", "GSSAPIDelegateCredentials=yes", "-o", "StrictHostKeyChecking=yes",
            "-o", "UserKnownHostsFile={}".format(self.settings.ssh_known_hosts),
            "-o", "ControlMaster=yes", "-o", "ControlPersist=86400",
            "-o", "ControlPath={}".format(self.settings.ssh_control_path),
            self.settings.ssh_host,
        ]
        try:
            completed = subprocess.run(
                command, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                timeout=20, env=self._ssh_environment(),
            )
        except (OSError, subprocess.TimeoutExpired):
            return False
        return completed.returncode == 0 and self.ssh_connection_ready()

    def _read(self, arguments: list[str]) -> dict:
        if self.settings.execution_backend == "mounted":
            return self._mounted(arguments)
        return self._remote(arguments)

    def _write(self, arguments: list[str], timeout_seconds: int | None = None) -> dict:
        if self.submission_enabled:
            return self._remote(arguments, timeout_seconds=timeout_seconds)
        return self._mounted(arguments, timeout_seconds=timeout_seconds)

    def _mounted(self, arguments: list[str], timeout_seconds: int | None = None) -> dict:
        script = self.settings.mount_root / "scripts" / "service_api.py"
        if not script.is_file():
            raise HpcServiceError("The mounted HPC service API is unavailable: {}".format(script))
        environment = os.environ.copy()
        environment["LIAO_RNASEQ_ROOT"] = str(self.settings.mount_root)
        environment["PYTHONPATH"] = str(self.settings.mount_root / "app")
        return self._run([sys.executable, str(script), *arguments], environment=environment, timeout_seconds=timeout_seconds)

    def _remote(self, arguments: list[str], timeout_seconds: int | None = None) -> dict:
        code_root = self.settings.remote_root
        remote_script = code_root + "/scripts/service_api.py"
        environment_values = [
            "LIAO_RNASEQ_ROOT={}".format(shlex.quote(self.settings.remote_root)),
            "PYTHONPATH={}".format(shlex.quote(code_root + "/app")),
        ]
        if self.settings.portal_mode == "personal":
            environment_values.extend([
                "LIAO_RNASEQ_SHARED_ROOT={}".format(shlex.quote(self.settings.shared_root)),
                "LIAO_RNASEQ_PERSONAL_MODE=1",
                "LIAO_RNASEQ_MEMBER_NETID={}".format(shlex.quote(self.settings.ssh_host.split("@")[0])),
                "LIAO_RNASEQ_ADMIN_EMAILS={}".format(shlex.quote(self.settings.email)),
                "LIAO_RNASEQ_AUTO_APPROVE_USERS=1",
            ])
        remote_command = " ".join(
            [
                "export",
                *environment_values,
                "&&", "python3", shlex.quote(remote_script),
            ]
            + [shlex.quote(value) for value in arguments]
        )
        return self._run([*self._ssh_command(), remote_command], environment=self._ssh_environment(), timeout_seconds=timeout_seconds)

    def _ssh_command(self) -> list[str]:
        if self.settings.portal_mode == "personal":
            if not self.settings.ssh_control_path:
                raise HpcServiceError("Personal Discovery connection is not configured.")
            return [
                "ssh", "-S", self.settings.ssh_control_path, "-o", "BatchMode=yes",
                "-o", "ControlMaster=no", "-o", "GSSAPIAuthentication=no",
                "-o", "PubkeyAuthentication=no", "-o", "PasswordAuthentication=no",
                "-o", "KbdInteractiveAuthentication=no", "-o", "StrictHostKeyChecking=yes",
                "-o", "ServerAliveInterval=60", "-o", "ServerAliveCountMax=10",
                self.settings.ssh_host,
            ]
        command = [
            "ssh", "-o", "BatchMode=yes", "-o", "GSSAPIAuthentication=yes",
            "-o", "GSSAPIDelegateCredentials=yes", "-o", "ServerAliveInterval=60",
            "-o", "ServerAliveCountMax=10", "-o", "StrictHostKeyChecking=yes",
        ]
        if self.settings.ssh_known_hosts:
            command.extend([
                "-o", 'UserKnownHostsFile="{}"'.format(self.settings.ssh_known_hosts),
            ])
        if self.settings.ssh_control_path:
            command.extend(["-o", "ControlPath={}".format(self.settings.ssh_control_path)])
        command.append(self.settings.ssh_host)
        return command

    def _ssh_environment(self) -> dict:
        environment = os.environ.copy()
        if self.settings.kerberos_cache:
            environment["KRB5CCNAME"] = "FILE:{}".format(self.settings.kerberos_cache)
        return environment

    def _upload_remote_stream(self, stream: BinaryIO, destination: str) -> None:
        stream.seek(0)
        remote_command = "umask 077 && cat > {}".format(shlex.quote(destination))
        try:
            completed = subprocess.run(
                [*self._ssh_command(), remote_command],
                stdin=stream,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=3600,
                env=self._ssh_environment(),
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            raise HpcServiceError("Could not upload the genotype input to Discovery: {}".format(error)) from error
        if completed.returncode != 0:
            raise HpcServiceError(completed.stderr.strip() or "The genotype upload to Discovery failed.")

    def _remove_remote_uploads(self, paths: list[str]) -> None:
        if not paths:
            return
        remote_command = "rm -f -- {}".format(" ".join(shlex.quote(path) for path in paths))
        try:
            subprocess.run(
                [*self._ssh_command(), remote_command],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=30,
                env=self._ssh_environment(),
            )
        except (OSError, subprocess.TimeoutExpired):
            pass

    def _run(self, command: list[str], environment: dict | None = None, timeout_seconds: int | None = None) -> dict:
        try:
            completed = subprocess.run(
                command,
                check=False,
                capture_output=True,
                text=True,
                timeout=timeout_seconds or self.settings.timeout_seconds,
                env=environment,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            raise HpcServiceError("Could not reach the RNA-seq service: {}".format(error)) from error
        payload = self._parse_json(completed.stdout)
        if completed.returncode != 0 or payload.get("error"):
            detail = payload.get("error") or completed.stderr.strip() or "The HPC command failed."
            if payload.get("error_type") == "ValueError":
                raise HpcValidationError(detail)
            raise HpcServiceError(detail)
        return payload

    @staticmethod
    def _parse_json(output: str) -> dict:
        start = output.find("{")
        if start < 0:
            raise HpcServiceError("The HPC service returned an unreadable response.")
        try:
            payload = json.loads(output[start:])
        except json.JSONDecodeError as error:
            raise HpcServiceError("The HPC service returned invalid JSON.") from error
        if not isinstance(payload, dict):
            raise HpcServiceError("The HPC service returned an invalid payload.")
        return payload
