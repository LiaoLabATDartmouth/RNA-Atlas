#!/usr/bin/env python3
"""Start one member's loopback-only RNA Atlas and install its private HPC code."""

import argparse
import io
import json
import os
import re
import secrets
import shlex
import socket
import subprocess
import sys
import tarfile
import threading
import time
import webbrowser
from pathlib import Path, PurePosixPath


LAB_ROOT = PurePosixPath("/dartfs/rc/lab/L/LiaoC")
SERVICE_ROOT = LAB_ROOT / "Service_Account" / "RNAseq_atlas"
DISCOVERY_HOST = "discovery.dartmouth.edu"
NETID_PATTERN = re.compile(r"[a-z][a-z0-9]{2,31}")
SOURCE_ROOT = Path(__file__).resolve().parents[1] / "discovery"
CONFIG_ROOT = Path.home() / ".rnaseq-atlas"
CONFIG_PATH = CONFIG_ROOT / "personal.json"
TOKEN_PATH = CONFIG_ROOT / "portal.token"
GENERIC_MODULES = (
    "__init__.py", "candidate_catalog.py", "counts.py", "email_delivery.py",
    "env_config.py", "fastq_validation.py", "genotypes.py", "microbiome.py",
    "parallel.py", "paths.py", "pipeline.py", "preprocessing.py", "project.py", "quality_summary.py",
    "reference_staging.py", "references.py", "registry.py", "slurm.py",
    "trinity.py", "unmapped_rna.py", "utils.py", "variants.py", "xlsx_reader.py",
)
REMOTE_SCRIPTS = ("service_api.py", "run_pipeline.py", "notify_job.py", "submit_prepared.py")


def remote_source_files():
    modules = SOURCE_ROOT / "app" / "rnaseq_service"
    return [modules / name for name in GENERIC_MODULES] + [
        SOURCE_ROOT / "scripts" / name for name in REMOTE_SCRIPTS
    ]


def validate_config(config):
    netid = str(config.get("netid", "")).strip().lower()
    if not NETID_PATTERN.fullmatch(netid):
        raise ValueError("Enter your Dartmouth NetID (letters and digits only).")
    workspace = PurePosixPath(str(config.get("workspace", "")))
    if (not workspace.is_absolute() or LAB_ROOT not in workspace.parents
            or SERVICE_ROOT.parent == workspace or SERVICE_ROOT.parent in workspace.parents
            or ".." in workspace.parts):
        raise ValueError("Workspace must be inside the LiaoC lab volume and outside Service_Account.")
    return {"netid": netid, "workspace": str(workspace)}


def ssh_base(netid):
    return [
        "ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=10",
        "-o", "StrictHostKeyChecking=yes", "-o", "GSSAPIAuthentication=yes",
        "-o", "GSSAPIDelegateCredentials=yes", "-o", "PubkeyAuthentication=no",
        "{}@{}".format(netid, DISCOVERY_HOST),
    ]


def ssh_run(netid, command, input_bytes=None):
    completed = subprocess.run(
        [*ssh_base(netid), command], input=input_bytes, capture_output=True, timeout=120,
    )
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr.decode(errors="replace").strip() or "Discovery rejected the request.")
    return completed.stdout.decode(errors="replace").strip()


def configure():
    print("Personal RNA Atlas setup (no password is requested or saved).")
    netid = input("Your Dartmouth NetID: ").strip().lower()
    workspace = input("Your private DartFS workspace (e.g. /dartfs/rc/lab/L/LiaoC/<your-folder>/RNAseq_atlas): ").strip()
    config = validate_config({"netid": netid, "workspace": workspace})
    CONFIG_ROOT.mkdir(mode=0o700, parents=True, exist_ok=True)
    CONFIG_ROOT.chmod(0o700)
    CONFIG_PATH.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    CONFIG_PATH.chmod(0o600)
    return config


def load_config():
    if not CONFIG_PATH.is_file():
        return configure()
    return validate_config(json.loads(CONFIG_PATH.read_text(encoding="utf-8")))


def install_remote_code(config):
    netid = config["netid"]
    workspace = config["workspace"]
    quoted_workspace = shlex.quote(workspace)
    identity = ssh_run(netid, "id -un")
    if identity != netid:
        raise RuntimeError("SSH connected as {}, not {}.".format(identity, netid))
    try:
        ssh_run(netid, "klist -s")
    except RuntimeError as error:
        raise RuntimeError("Discovery did not receive a valid Kerberos ticket.") from error
    canonical_workspace = ssh_run(netid, "realpath -m -- {}".format(quoted_workspace))
    if canonical_workspace != workspace:
        raise RuntimeError("Use the canonical DartFS workspace path; symbolic links are not allowed.")
    validate_config({"netid": netid, "workspace": canonical_workspace})
    ssh_run(netid, "mkdir -m 700 -- {} 2>/dev/null || test -d {}".format(quoted_workspace, quoted_workspace))
    ownership = ssh_run(netid, "test ! -L {0} && test -O {0} && test -w {0} && "
                        "test ! -L {0}/app && test ! -L {0}/app/rnaseq_service && "
                        "test ! -L {0}/scripts && "
                        "test ! -L {0}/scripts/service_api.py && "
                        "test ! -L {0}/scripts/run_pipeline.py && "
                        "test ! -L {0}/scripts/notify_job.py && "
                        "test -x {1}/shared/runtime_v2/bin/python && "
                        "test -r {1}/r/run_deseq2.R && "
                        "test -r {1}/shared/references && test -x {1}/shared/references && printf ready".format(
                            quoted_workspace, shlex.quote(str(SERVICE_ROOT)),
                        ))
    if ownership != "ready":
        raise RuntimeError("Personal workspace or shared RNA Atlas assets are not accessible.")
    archive_bytes = io.BytesIO()
    with tarfile.open(fileobj=archive_bytes, mode="w:gz") as archive:
        for source in remote_source_files():
            archive.add(source, arcname=str(source.relative_to(SOURCE_ROOT)), recursive=False)
    ssh_run(netid, "umask 077 && tar -xzf - -C {}".format(quoted_workspace), archive_bytes.getvalue())


def local_token():
    CONFIG_ROOT.mkdir(mode=0o700, parents=True, exist_ok=True)
    CONFIG_ROOT.chmod(0o700)
    if not TOKEN_PATH.is_file():
        TOKEN_PATH.write_text(secrets.token_urlsafe(32), encoding="utf-8")
        TOKEN_PATH.chmod(0o600)
    return TOKEN_PATH.read_text(encoding="utf-8").strip()


def open_when_ready(port, url):
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=1):
                webbrowser.open(url)
                return
        except OSError:
            time.sleep(0.2)


def run(config, check_only=False):
    install_remote_code(config)
    os.environ.update({
        "RNASEQ_PORTAL_MODE": "personal",
        "RNASEQ_EXECUTION_BACKEND": "slurm",
        "RNASEQ_PORTAL_EMAIL": config["netid"] + "@dartmouth.edu",
        "RNASEQ_SSH_HOST": config["netid"] + "@" + DISCOVERY_HOST,
        "RNASEQ_REMOTE_ROOT": config["workspace"],
        "RNASEQ_SHARED_ROOT": str(SERVICE_ROOT),
        "RNASEQ_PORTAL_TOKEN": local_token(),
        "RNASEQ_TRUST_EMAIL_HEADER": "0",
    })
    for inherited_setting in ("RNASEQ_KRB5_CACHE", "RNASEQ_SSH_CONTROL_PATH", "RNASEQ_SSH_KNOWN_HOSTS"):
        os.environ.pop(inherited_setting, None)
    from app.config import PortalSettings
    from app.hpc import HpcServiceClient

    client = HpcServiceClient(PortalSettings.from_environment())
    client.register(config["netid"] + "@dartmouth.edu", config["netid"])
    snapshot = client.snapshot(config["netid"] + "@dartmouth.edu")
    if snapshot.get("user", {}).get("status") != "approved":
        raise RuntimeError("The personal Discovery workspace did not approve this account.")
    if check_only:
        print("Discovery identity, private workspace, shared assets, and personal service are ready.")
        print("QC runtime: {}".format("ready" if snapshot.get("qc_ready") else "unavailable"))
        return
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    url = "http://127.0.0.1:{}/?token={}".format(port, os.environ["RNASEQ_PORTAL_TOKEN"])
    print("Opening RNA Atlas on this computer only. Close this window to stop it.")
    threading.Thread(target=open_when_ready, args=(port, url), daemon=True).start()
    import uvicorn

    uvicorn.run("app.main:app", host="127.0.0.1", port=port, log_level="warning", access_log=False)


def main():
    parser = argparse.ArgumentParser(description="Run a private, per-member RNA Atlas browser app.")
    parser.add_argument("--configure", action="store_true", help="Set your NetID and private DartFS workspace.")
    parser.add_argument("--check", action="store_true", help="Check access without opening the browser.")
    args = parser.parse_args()
    try:
        config = configure() if args.configure else load_config()
        run(config, check_only=args.check)
    except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as error:
        print("RNA Atlas could not start: {}".format(error), file=sys.stderr)
        print("Use Dartmouth VPN, obtain your own Kerberos ticket, and verify your own Discovery SSH login.", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
