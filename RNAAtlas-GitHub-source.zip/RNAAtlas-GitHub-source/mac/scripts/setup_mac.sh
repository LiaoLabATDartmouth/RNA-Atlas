#!/bin/bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

PYTHON_BIN="${RNASEQ_PYTHON:-python3}"
REQUIREMENTS_FILE="${RNASEQ_REQUIREMENTS_FILE:-requirements-web.lock.txt}"
if [[ ! -x .venv-web/bin/python ]]; then
  "$PYTHON_BIN" -m venv .venv-web
fi
if [[ ! -f "$REQUIREMENTS_FILE" ]]; then
  echo "Missing requirements file: $REQUIREMENTS_FILE" >&2
  exit 1
fi
mkdir -p logs runtime/mac runtime/pip-cache
export PIP_CACHE_DIR="$PROJECT_ROOT/runtime/pip-cache"
if [[ "$(.venv-web/bin/python -m pip --version | awk '{print $2}')" != "26.0.1" ]]; then
  .venv-web/bin/python -m pip install --upgrade "pip==26.0.1"
fi
.venv-web/bin/python -m pip install -r "$REQUIREMENTS_FILE"
echo "Mac web environment is ready."
