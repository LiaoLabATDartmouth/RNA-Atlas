#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -x .venv-web/bin/python ]]; then
  scripts/setup_mac.sh
fi
.venv-web/bin/python personal_launcher.py
