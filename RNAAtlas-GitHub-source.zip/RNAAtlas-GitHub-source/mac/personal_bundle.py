#!/usr/bin/env python3
"""Package only non-secret files needed by a personal RNA Atlas installation."""

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from personal_launcher import remote_source_files


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "mac" / "dist" / "RNAAtlas-personal.zip"
MAC_FILES = (
    "mac/personal_launcher.py",
    "mac/start_personal.command",
    "mac/requirements-web.lock.txt",
    "mac/requirements-web.txt",
    "mac/PERSONAL.md",
    "mac/scripts/setup_mac.sh",
)


def bundle_paths():
    files = [ROOT / name for name in MAC_FILES]
    files.append(ROOT / "mac" / "personal_bundle.py")
    files.extend((ROOT / "mac" / "app").rglob("*.py"))
    files.extend((ROOT / "mac" / "app" / "static").glob("*.css"))
    files.extend((ROOT / "mac" / "app" / "static").glob("*.js"))
    files.extend((ROOT / "mac" / "app" / "static").glob("*.tsv"))
    files.extend((ROOT / "mac" / "app" / "templates").glob("*.html"))
    files.extend(remote_source_files())
    return sorted(set(files))


def main():
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(OUTPUT, "w", ZIP_DEFLATED) as archive:
        for path in bundle_paths():
            archive.write(path, arcname="RNAAtlas-personal/{}".format(path.relative_to(ROOT)))
    print(OUTPUT)


if __name__ == "__main__":
    main()
