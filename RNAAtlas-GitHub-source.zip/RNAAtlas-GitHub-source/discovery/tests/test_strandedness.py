import tempfile
import unittest
from pathlib import Path

from rnaseq_service.strandedness import classify_project, classify_sample, input_reads_from_star_log, read_gene_counts


class StrandednessTests(unittest.TestCase):
    def test_star_counts_and_log_are_parsed(self):
        with tempfile.TemporaryDirectory() as temporary:
            counts = Path(temporary) / "ReadsPerGene.out.tab"
            counts.write_text(
                "N_unmapped\t2\t2\t2\nGeneA\t200\t180\t10\nGeneB\t100\t100\t10\n",
                encoding="utf-8",
            )
            log = Path(temporary) / "Log.final.out"
            log.write_text("Number of input reads | 1234\n", encoding="utf-8")
            self.assertEqual(read_gene_counts(counts), {
                "unstranded_assigned": 300, "forward_assigned": 280, "reverse_assigned": 20,
            })
            self.assertEqual(input_reads_from_star_log(log), 1234)

    def test_conflicting_and_balanced_samples_require_review(self):
        forward = classify_sample({"unstranded_assigned": 320, "forward_assigned": 280, "reverse_assigned": 20})
        reverse = classify_sample({"unstranded_assigned": 320, "forward_assigned": 20, "reverse_assigned": 280})
        balanced = classify_sample({"unstranded_assigned": 320, "forward_assigned": 150, "reverse_assigned": 150})
        weak = classify_sample({"unstranded_assigned": 100, "forward_assigned": 80, "reverse_assigned": 5})
        self.assertEqual([forward["verdict"], reverse["verdict"], balanced["verdict"], weak["verdict"]],
                         ["forward", "reverse", "balanced_review", "unclear_low_counts"])
        self.assertEqual(classify_project([forward, forward]), "forward")
        self.assertEqual(classify_project([forward, reverse]), "needs_review")
        self.assertEqual(classify_project([balanced, balanced]), "needs_review")
        boundary = classify_sample({"unstranded_assigned": 200, "forward_assigned": 180, "reverse_assigned": 20})
        self.assertEqual(boundary["verdict"], "forward")

    def test_invalid_gene_counts_fail_closed(self):
        with tempfile.TemporaryDirectory() as temporary:
            counts = Path(temporary) / "ReadsPerGene.out.tab"
            counts.write_text("GeneA\t2\t-1\t1\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "negative"):
                read_gene_counts(counts)


if __name__ == "__main__":
    unittest.main()
