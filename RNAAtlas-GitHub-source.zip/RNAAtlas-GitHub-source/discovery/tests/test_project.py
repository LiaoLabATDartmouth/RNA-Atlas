import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from rnaseq_service.paths import enforce_rnaseq_boundary
from rnaseq_service.project import create_project, load_project_config, validate_project
from rnaseq_service.references import list_references, load_reference
from rnaseq_service.slurm import prepare_job


class ProjectTests(unittest.TestCase):
    def make_reference(self, root, reference_id="candida_test", has_annotation=True):
        directory = root / "shared" / "references" / reference_id
        index = directory / "star_index"
        index.mkdir(parents=True)
        (directory / "reference.fa").write_text(">chr1\nATGC\n", encoding="utf-8")
        (directory / "reference.fa.fai").write_text("chr1\t4\t6\t4\t5\n", encoding="utf-8")
        (directory / "reference.dict").write_text("@HD\tVN:1.6\n@SQ\tSN:chr1\tLN:4\n", encoding="utf-8")
        if has_annotation:
            (directory / "annotation.gtf").write_text(
                'chr1\ttest\texon\t1\t4\t.\t+\t.\tgene_id "G1"; transcript_id "T1";\n', encoding="utf-8"
            )
        for marker in ("Genome", "SA", "SAindex"):
            (index / marker).write_bytes(b"index")
        (index / "genomeParameters.txt").write_text("genomeSAindexNbases\t1\n", encoding="utf-8")
        fasta_sha256 = hashlib.sha256((directory / "reference.fa").read_bytes()).hexdigest()
        annotation_sha256 = hashlib.sha256((directory / "annotation.gtf").read_bytes()).hexdigest() if has_annotation else ""
        (directory / "reference.json").write_text(
            json.dumps(
                {
                    "id": reference_id, "label": "Candida test reference", "organism": "Candida albicans",
                    "assembly": "TEST1", "recommended_ploidy": 2, "genome_bases": 4,
                    "star_sa_index_nbases": 1, "star_sjdb_overhang": 1,
                    "fasta": "reference.fa", "annotation": "annotation.gtf" if has_annotation else "",
                    "has_annotation": has_annotation,
                    "star_index": "star_index", "fasta_sha256": fasta_sha256,
                    "annotation_sha256": annotation_sha256,
                }
            ),
            encoding="utf-8",
        )
        return directory

    def make_project(self, root):
        (root / "projects").mkdir(parents=True)
        self.make_reference(root)
        project = create_project("Example", "Candida albicans", reference_id="candida_test", root=root)
        (project / "meta_data" / "sample_sheet.tsv").write_text(
	            "sample_id\tcondition\nS1\tWT\nS2\tMut\n", encoding="utf-8"
        )
        for sample in ("S1", "S2"):
            directory = project / "raw_data" / sample
            directory.mkdir()
            (directory / "{}_1.fq.gz".format(sample)).write_bytes(b"read1")
            (directory / "{}_2.fq.gz".format(sample)).write_bytes(b"read2")
        config_path = project / "project_config.json"
        config = json.loads(config_path.read_text(encoding="utf-8"))
        config["reference_condition"] = "WT"
        config_path.write_text(json.dumps(config), encoding="utf-8")
        return project

    def test_validates_isolated_project(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            self.make_project(root)
            validation = validate_project("Example", root=root)
            self.assertEqual(validation["errors"], [])
            self.assertEqual(len(validation["samples"]), 2)
            self.assertEqual(validation["conditions"], ["Mut", "WT"])
            self.assertEqual(validation["reference_id"], "candida_test")
            self.assertEqual(validation["reference_source"], "preinstalled")
            self.assertEqual(load_reference("candida_test", root=root)["genome_bases"], 4)
            self.assertEqual([record["id"] for record in list_references(root=root)], ["candida_test"])

    def test_project_has_module_folders_and_reports_missing_pair(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            project = self.make_project(root)
            for module in ("differential_expression", "rna_snv", "ase", "trinity"):
                self.assertTrue((project / "results" / module).is_dir())
            self.assertTrue((project / "genotype_VCF").is_dir())
            (project / "raw_data" / "S2" / "S2_2.fq.gz").unlink()
            validation = validate_project("Example", root=root)
            self.assertEqual(len(validation["input_checks"]), 2)
            self.assertEqual(validation["input_checks"][1]["read2"], "")
            self.assertIn("R2 missing", validation["errors"][0])

    def test_project_rejects_unlisted_sample_folders(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            project = self.make_project(root)
            (project / "raw_data" / "S3").mkdir()
            validation = validate_project("Example", root=root)
            self.assertIn("S3", validation["errors"][0])

    def test_single_module_job_uses_module_output_folder(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            project = self.make_project(root)
            (root / "shared" / "service_registry").mkdir(parents=True)
            job = prepare_job("Example", "user@dartmouth.edu", requested_options={
                "run_differential_expression": True, "run_rna_variants": False, "run_ase": False,
                "run_trinity": False, "reference_condition": "WT",
            }, root=root)
            self.assertEqual(job["module"], "differential_expression")
            self.assertEqual(Path(job["output_root"]).parent, project / "results" / "differential_expression")

    @patch.dict("os.environ", {"LIAO_RNASEQ_PERSONAL_MODE": "1"})
    def test_nested_project_keeps_inputs_and_multiple_job_outputs_together(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            self.make_reference(root)
            project = root / "Example"
            metadata = project / "datasets" / "meta_data"
            metadata.mkdir(parents=True)
            (metadata / "sample_sheet.tsv").write_text(
                "sample_id\tcondition\nS1\tcontrol\nS2\ttreated\n", encoding="utf-8",
            )
            for sample in ("S1", "S2"):
                reads = project / "datasets" / "raw_data" / sample
                reads.mkdir(parents=True)
                for mate in (1, 2):
                    (reads / "{}_{}.fq.gz".format(sample, mate)).write_bytes(b"reads")
            create_project(
                "Example", reference_id="candida_test", root=root,
                prepared_existing=True, input_subdirectory="datasets",
            )
            validation = validate_project("Example", root=root)
            self.assertEqual(validation["errors"], [])
            self.assertEqual(Path(validation["metadata_file"]), metadata / "sample_sheet.tsv")
            self.assertTrue(all("/datasets/raw_data/" in sample["read1"] for sample in validation["samples"]))
            (root / "shared" / "service_registry").mkdir(parents=True)
            package = root / "app" / "rnaseq_service"
            package.mkdir(parents=True)
            (package / "__init__.py").write_text("\n", encoding="utf-8")
            scripts = root / "scripts"
            scripts.mkdir()
            for name in ("run_pipeline.py", "notify_job.py"):
                (scripts / name).write_text("pass\n", encoding="utf-8")
            expression = prepare_job("Example", "user@dartmouth.edu", requested_options={
                "run_differential_expression": True, "run_rna_variants": False, "run_ase": False,
                "run_trinity": False, "reference_condition": "control",
            }, root=root)
            variants = prepare_job("Example", "user@dartmouth.edu", requested_options={
                "run_differential_expression": False, "run_rna_variants": True, "run_ase": False,
                "run_trinity": False,
            }, root=root)
            self.assertEqual(Path(expression["output_root"]).parent, project / "results" / "differential_expression")
            self.assertEqual(Path(variants["output_root"]).parent, project / "results" / "rna_snv")
            self.assertTrue(Path(expression["job_config_path"]).is_file())
            self.assertTrue(Path(variants["job_config_path"]).is_file())
            self.assertNotEqual(expression["code_root"], variants["code_root"])
            self.assertEqual(Path(expression["code_root"]).parent, Path(expression["output_root"]))

    def test_missing_reference_does_not_create_project_scaffold(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            (root / "projects").mkdir(parents=True)
            with self.assertRaisesRegex(ValueError, "Reference missing_reference"):
                create_project("Incomplete", reference_id="missing_reference", root=root)
            self.assertFalse((root / "projects" / "Incomplete").exists())

    def test_new_project_inherits_selected_reference_organism_and_ploidy(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            reference = self.make_reference(root, "af293")
            manifest_path = reference / "reference.json"
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            manifest["organism"] = "Aspergillus fumigatus"
            manifest["recommended_ploidy"] = 1
            manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
            create_project("Af293_test", "mismatched label", reference_id="af293", root=root)
            config = load_project_config("Af293_test", root=root)
            self.assertEqual(config["organism"], "Aspergillus fumigatus")
            self.assertEqual(config["ploidy"], 1)

    def test_single_haplotype_reference_keeps_diploid_species_ploidy(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            self.make_project(root)
            (root / "shared" / "service_registry").mkdir(parents=True)
            job = prepare_job("Example", "user@dartmouth.edu", requested_options={
                "run_differential_expression": False, "run_rna_variants": True,
                "run_ase": False, "run_trinity": False,
            }, root=root)
            self.assertEqual(job["options"]["ploidy"], 2)

    def test_rejects_legacy_variant_and_ase_config_keys(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            project = self.make_project(root)
            config_path = project / "project_config.json"
            config = json.loads(config_path.read_text(encoding="utf-8"))
            config["run_variants"] = False
            config["ase_enabled"] = False
            config["ase_source"] = "rna_discovery"
            config_path.write_text(json.dumps(config), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "ase_enabled, run_variants"):
                load_project_config("Example", root=root)

    def test_rejects_path_escape(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            root.mkdir()
            with self.assertRaises(ValueError):
                enforce_rnaseq_boundary(root / ".." / "outside", root=root)

    def test_job_uses_selected_differential_expression_reference(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            self.make_project(root)
            (root / "shared" / "service_registry").mkdir(parents=True)
            with self.assertRaisesRegex(ValueError, "reference group"):
                prepare_job(
                    "Example", "user@dartmouth.edu",
                    requested_options={"run_differential_expression": True, "reference_condition": "Missing"},
                    root=root,
                )
            job = prepare_job(
                "Example", "user@dartmouth.edu",
                requested_options={"run_differential_expression": True, "reference_condition": "Mut"},
                root=root,
            )
            self.assertTrue(job["options"]["run_differential_expression"])
            self.assertEqual(job["options"]["reference_condition"], "Mut")
            self.assertEqual(job["options"]["reference_id"], "candida_test")

    def test_job_persists_module_threshold_overrides_and_rejects_invalid_values(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            self.make_project(root)
            (root / "shared" / "service_registry").mkdir(parents=True)
            settings = {
                "reference_condition": "WT", "strandedness": "unstranded",
                "padj_cutoff": 0.01, "log2fc_cutoff": 1.0,
                "variant_min_depth": 15, "variant_min_quality": 25.5,
                "ase_min_depth": 30, "ase_min_allele_count": 0,
            }
            job = prepare_job("Example", "user@dartmouth.edu", requested_options=settings, root=root)
            for key, value in settings.items():
                self.assertEqual(job["options"][key], value)
            for invalid in ({"padj_cutoff": float("nan")}, {"log2fc_cutoff": -1},
                            {"variant_min_depth": 1.5}, {"variant_min_quality": float("inf")},
                            {"ase_min_depth": 0}, {"ase_min_allele_count": -1}):
                with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                    prepare_job("Example", "user@dartmouth.edu", requested_options={**settings, **invalid}, root=root)

    def test_job_can_select_another_preinstalled_reference(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            self.make_project(root)
            self.make_reference(root, "candida_alternate")
            (root / "shared" / "service_registry").mkdir(parents=True)
            job = prepare_job(
                "Example", "user@dartmouth.edu",
                requested_options={
                    "reference_id": "candida_alternate", "run_differential_expression": False,
                    "run_trinity": True,
                },
                root=root,
            )
            self.assertEqual(job["options"]["reference_id"], "candida_alternate")
            self.assertTrue(job["options"]["run_trinity"])

    def test_fasta_only_reference_disables_differential_expression(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            self.make_project(root)
            self.make_reference(root, "fasta_only", has_annotation=False)
            (root / "shared" / "service_registry").mkdir(parents=True)
            validation = validate_project("Example", root=root, reference_id="fasta_only")
            self.assertFalse(validation["reference_has_annotation"])
            self.assertIn("FASTA-only", "; ".join(validation["warnings"]))
            with self.assertRaisesRegex(ValueError, "requires an expression-ready reference"):
                prepare_job(
                    "Example", "user@dartmouth.edu",
                    requested_options={
                        "reference_id": "fasta_only", "run_differential_expression": True,
                        "reference_condition": "WT",
                    },
                    root=root,
                )
            job = prepare_job(
                "Example", "user@dartmouth.edu",
                requested_options={"reference_id": "fasta_only", "run_differential_expression": False},
                root=root,
            )
            self.assertFalse(job["options"]["run_differential_expression"])

    def test_job_records_unmapped_rna_mode(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            self.make_project(root)
            (root / "shared" / "service_registry").mkdir(parents=True)
            job = prepare_job(
                "Example", "user@dartmouth.edu",
                requested_options={
                    "run_differential_expression": False,
                    "run_trinity": True,
                    "run_unmapped_rna": True,
                    "run_unmapped_trinity": True,
                    "unmapped_rna_mode": "rna_virus",
                    "trinity_min_contig_length": 250,
                    "trinity_normalize_reads": False,
                    "unmapped_rna_min_pairs": 5000,
                    "unmapped_rna_min_contig_length": 300,
                    "unmapped_rna_host_min_identity": 92.5,
                    "unmapped_rna_host_min_query_coverage": 85.0,
                    "unmapped_rna_blast_evalue": 1e-20,
                    "candidate_cross_min_identity": 97.0,
                    "candidate_cross_min_shorter_coverage": 88.0,
                },
                root=root,
            )
            self.assertTrue(job["options"]["run_unmapped_rna"])
            self.assertTrue(job["options"]["run_unmapped_trinity"])
            self.assertEqual(job["options"]["unmapped_rna_mode"], "rna_virus")
            self.assertEqual(job["options"]["trinity_min_contig_length"], 250)
            self.assertFalse(job["options"]["trinity_normalize_reads"])
            self.assertEqual(job["options"]["unmapped_rna_min_pairs"], 5000)
            self.assertEqual(job["options"]["unmapped_rna_host_min_identity"], 92.5)
            self.assertEqual(job["options"]["candidate_cross_min_identity"], 97.0)

    def test_job_rejects_out_of_range_discovery_parameters(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            self.make_project(root)
            (root / "shared" / "service_registry").mkdir(parents=True)
            with self.assertRaisesRegex(ValueError, "candidate_cross_min_identity"):
                prepare_job(
                    "Example", "user@dartmouth.edu",
                    requested_options={
                        "run_differential_expression": False,
                        "candidate_cross_min_identity": 101,
                    },
                    root=root,
                )

    def test_job_accepts_precalled_genotypes_for_ase_without_rna_variant_calling(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            project = self.make_project(root)
            (root / "shared" / "service_registry").mkdir(parents=True)
            (project / "meta_data" / "dna_genotypes.vcf").write_text(
                "##fileformat=VCFv4.2\n"
                "##contig=<ID=chr1,length=4>\n"
                '##FORMAT=<ID=GT,Number=1,Type=String,Description="Genotype">\n'
                "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tDNA1\n"
                "chr1\t2\t.\tT\tC\t60\tPASS\t.\tGT\t0/1\n",
                encoding="utf-8",
            )
            (project / "meta_data" / "ase_genotype_map.tsv").write_text(
                "sample_id\tvcf_sample_id\nS1\tDNA1\nS2\tDNA1\n", encoding="utf-8"
            )
            job = prepare_job(
                "Example", "user@dartmouth.edu",
                requested_options={
                    "run_differential_expression": False,
                    "run_rna_variants": False,
                    "run_ase": True,
                    "ase_source": "external_dna_vcf",
                },
                root=root,
            )
            self.assertFalse(job["options"]["run_rna_variants"])
            self.assertTrue(job["options"]["run_ase"])
            self.assertEqual(job["options"]["ase_genotype_sample_map"]["S2"], "DNA1")

    def test_rna_discovered_ase_requires_rna_variant_discovery(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            self.make_project(root)
            (root / "shared" / "service_registry").mkdir(parents=True)
            with self.assertRaisesRegex(ValueError, "requires RNA variant discovery"):
                prepare_job(
                    "Example", "user@dartmouth.edu",
                    requested_options={
                        "run_differential_expression": False,
                        "run_rna_variants": False,
                        "run_ase": True,
                        "ase_source": "rna_discovered",
                    },
                    root=root,
                )

    def test_uploaded_invalid_vcf_makes_project_validation_fail(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "rnaseq"
            project = self.make_project(root)
            (project / "meta_data" / "dna_genotypes.vcf").write_text(
                "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n",
                encoding="utf-8",
            )
            validation = validate_project("Example", root=root)
            self.assertTrue(validation["errors"])
            combined = "; ".join(validation["errors"])
            self.assertIn("missing ##fileformat", combined)
            self.assertIn("missing ##contig", combined)
            self.assertIn("missing ##FORMAT=<ID=GT", combined)


if __name__ == "__main__":
    unittest.main()
