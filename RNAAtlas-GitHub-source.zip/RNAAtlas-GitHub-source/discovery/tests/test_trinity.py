import json
import tempfile
import unittest
from os import environ
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from rnaseq_service.parallel import GIBIBYTE
from rnaseq_service.pipeline import PipelineRunner
from rnaseq_service.trinity import (
    choose_trinity_memory_gb,
    parse_bowtie2_representation,
    summarize_trinity_fasta,
    trinity_strand_code,
    validate_salmon_version,
)


class TrinityTests(unittest.TestCase):
    def test_single_end_trinity_uses_single_reads_and_strand_code(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            runner = object.__new__(PipelineRunner)
            runner.options = {"threads": 2, "memory": "16G", "strandedness": "reverse",
                              "trinity_normalize_reads": False}
            runner.validation = {"config": {"trinity_memory_gb": 0, "trinity_min_contig_length": 200,
                                             "trinity_normalize_reads": False, "strandedness": "reverse"}}
            runner.service_root = root
            runner.tool = lambda name: name
            commands = []

            def fake_trinity(command, label, environment=None):
                commands.append(command)
                output = Path(command[command.index("--output") + 1])
                output.mkdir()
                Path("{}.Trinity.fasta".format(output)).write_text(">t1\nACGT\n", encoding="utf-8")

            runner.run_command = fake_trinity
            runner._run_trinity_assembly(["S1.fq.gz"], [], root / "work", "single-end Trinity")
            self.assertIn("--single", commands[0])
            self.assertNotIn("--left", commands[0])
            self.assertNotIn("--right", commands[0])
            self.assertEqual(commands[0][commands[0].index("--SS_lib_type") + 1], "R")

    def test_parses_paired_read_representation(self):
        self.assertEqual(parse_bowtie2_representation(
            "1,234 reads; of these:\n  987 (80.00%) aligned concordantly exactly 1 time\n85.50% overall alignment rate\n"
        ), (1234, 85.5))
        with self.assertRaisesRegex(ValueError, "did not report"):
            parse_bowtie2_representation("unrelated output")

    def test_memory_and_strand_planning(self):
        self.assertEqual(choose_trinity_memory_gb(64 * GIBIBYTE), 56)
        self.assertEqual(choose_trinity_memory_gb("32G", requested=40), 24)
        self.assertEqual(trinity_strand_code("reverse"), "RF")
        self.assertEqual(trinity_strand_code("forward"), "FR")
        self.assertEqual(trinity_strand_code("unstranded"), "")
        self.assertEqual(trinity_strand_code("reverse", paired=False), "R")
        self.assertEqual(trinity_strand_code("forward", paired=False), "F")

    def test_summarizes_assembly_lengths(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            fasta = directory / "Trinity.fasta"
            fasta.write_text(">a\nAAAAAA\n>b\nAAAA\n>c\nAA\n", encoding="utf-8")
            result = summarize_trinity_fasta(fasta, directory / "stats.tsv")
            self.assertEqual(result["summary"]["transcripts"], 3)
            self.assertEqual(result["summary"]["total_bases"], 12)
            self.assertEqual(result["summary"]["n50"], 6)

    def test_requires_trinity_compatible_salmon(self):
        self.assertEqual(validate_salmon_version("salmon 1.10.3"), (1, 10, 3))
        with self.assertRaisesRegex(ValueError, "requires Salmon 1.10.3"):
            validate_salmon_version("salmon 2.5.1")
        with self.assertRaisesRegex(ValueError, "Unable to determine"):
            validate_salmon_version("unknown")

    def test_pipeline_uses_all_project_read_pairs(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            runner = object.__new__(PipelineRunner)
            runner.options = {
                "run_trinity": True, "threads": 8, "memory": "32G",
                "trinity_min_contig_length": 250, "trinity_normalize_reads": False,
            }
            runner.validation = {
                "config": {
                    "trinity_memory_gb": 0, "trinity_min_contig_length": 200,
                    "trinity_normalize_reads": True, "strandedness": "reverse",
                },
                "fastq_bytes": 100,
                "samples": [
                    {"sample_id": "S1", "read1": "/reads/S1_1.fq.gz", "read2": "/reads/S1_2.fq.gz"},
                    {"sample_id": "S2", "read1": "/reads/S2_1.fq.gz", "read2": "/reads/S2_2.fq.gz"},
                ],
            }
            runner.analysis_samples = runner.validation["samples"]
            runner.output_root = directory / "results"
            runner.output_root.mkdir()
            runner.service_root = directory / "RNAseq_atlas"
            runner.service_root.mkdir()
            runner.tmp_directory = directory / "dartfs_tmp"
            runner.tmp_directory.mkdir()
            runner.job = {"job_id": "J1"}
            runner.artifacts = {}
            runner.update_status = lambda *args, **kwargs: None
            runner.tool = lambda name: "/runtime/bin/Trinity"
            observed = {}

            def fake_run(command, label, environment=None):
                observed["command"] = [str(value) for value in command]
                observed["environment"] = environment
                output = Path(command[command.index("--output") + 1])
                output.mkdir()
                Path("{}.Trinity.fasta".format(output)).write_text(">TRINITY_1\nAAAA\n", encoding="utf-8")
                Path("{}.Trinity.fasta.gene_trans_map".format(output)).write_text(
                    "G1\tTRINITY_1\n", encoding="utf-8"
                )

            runner.run_command = fake_run
            runner._trinity_read_representation = lambda *args: str(directory / "read_representation.tsv")
            node_tmp = directory / "node_tmp"
            node_tmp.mkdir()
            runner.node_local_work_parent = lambda: node_tmp
            with patch.dict(environ, {"TMPDIR": str(node_tmp)}), patch(
                "rnaseq_service.pipeline.shutil.disk_usage", return_value=SimpleNamespace(free=100 * GIBIBYTE)
            ):
                runner.trinity()
            command = observed["command"]
            self.assertEqual(command[command.index("--left") + 1], "/reads/S1_1.fq.gz,/reads/S2_1.fq.gz")
            self.assertEqual(command[command.index("--right") + 1], "/reads/S1_2.fq.gz,/reads/S2_2.fq.gz")
            self.assertNotIn("--normalize_reads", command)
            self.assertEqual(command[command.index("--min_contig_length") + 1], "250")
            self.assertEqual(command[command.index("--SS_lib_type") + 1], "RF")
            self.assertIn("trinity_runtime/bin", observed["environment"]["PATH"])
            self.assertTrue((runner.output_root / "25_denovo_transcriptome" / "Trinity.fasta").is_file())

    def test_read_representation_writes_each_sample_and_cleans_work(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            runner = object.__new__(PipelineRunner)
            runner.job = {"job_id": "J1"}
            runner.options = {"threads": 4}
            runner.log_path = directory / "pipeline.log"
            runner.tool = lambda name: name
            runner.log = lambda message: None
            observed = []

            def fake_build(command, label):
                observed.append((list(map(str, command)), label))

            def fake_align(command, **kwargs):
                observed.append((list(map(str, command)), kwargs))
                return SimpleNamespace(returncode=0, stderr=(
                    "100 reads; of these:\n  95 (95.00%) aligned concordantly exactly 1 time\n"
                    "95.00% overall alignment rate\n"
                ))

            runner.run_command = fake_build
            samples = [{"sample_id": "S1", "read1": "S1_1.fq.gz", "read2": "S1_2.fq.gz"},
                       {"sample_id": "S2", "read1": "S2_1.fq.gz", "read2": "S2_2.fq.gz"}]
            with patch("rnaseq_service.pipeline.subprocess.run", side_effect=fake_align):
                output = runner._trinity_read_representation(
                    directory / "Trinity.fasta", samples, directory, directory,
                )
            self.assertEqual(Path(output).read_text(encoding="utf-8").splitlines(), [
                "sample_id\tinput_read_pairs\toverall_alignment_percent",
                "S1\t100\t95.0", "S2\t100\t95.0",
            ])
            self.assertEqual(observed[0][0][0], "bowtie2-build")
            self.assertEqual([call[0][0] for call in observed[1:]], ["bowtie2", "bowtie2"])
            self.assertFalse((directory / "trinity_representation_J1").exists())

    def test_read_representation_fails_closed_and_cleans_work(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            runner = object.__new__(PipelineRunner)
            runner.job = {"job_id": "J1"}
            runner.options = {"threads": 4}
            runner.log_path = directory / "pipeline.log"
            runner.tool = lambda name: name
            runner.log = lambda message: None
            runner.run_command = lambda *args, **kwargs: None
            with patch("rnaseq_service.pipeline.subprocess.run", return_value=SimpleNamespace(
                returncode=1, stderr="Bowtie2 failed\n",
            )):
                with self.assertRaisesRegex(Exception, "exit code 1"):
                    runner._trinity_read_representation(
                        directory / "Trinity.fasta",
                        [{"sample_id": "S1", "read1": "S1_1.fq.gz", "read2": "S1_2.fq.gz"}],
                        directory, directory,
                    )
            self.assertFalse((directory / "trinity_representation_J1").exists())
            self.assertFalse((directory / "read_representation.tsv").exists())

    def test_pipeline_builds_mapping_first_trinity_from_unmapped_pairs(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            runner = object.__new__(PipelineRunner)
            runner.options = {
                "run_unmapped_trinity": True,
                "threads": 8,
                "memory": "64G",
                "unmapped_rna_min_pairs": 1000,
            }
            runner.validation = {
                "config": {
                    "unmapped_rna_min_pairs": 1000,
                    "unmapped_rna_host_min_identity": 95.0,
                    "unmapped_rna_host_min_query_coverage": 80.0,
                    "unmapped_rna_blast_evalue": "1e-10",
                }
            }
            runner.output_root = directory / "results"
            runner.output_root.mkdir()
            runner.artifacts = {}
            runner.update_status = lambda *args, **kwargs: None
            runner.tool = lambda name: "/runtime/bin/{}".format(name)
            work_root = directory / "work"
            work_root.mkdir()
            assembled = directory / "assembled.Trinity.fasta"
            assembled.write_text(">TRINITY_UNMAPPED_1\n" + "A" * 250 + "\n", encoding="utf-8")
            runner._run_trinity_assembly = lambda *args, **kwargs: {
                "fasta": assembled,
                "gene_map": None,
                "in_silico_normalization": True,
                "strand_code": "RF",
                "minimum_contig_length": 200,
                "cpu_threads": 8,
                "maximum_memory_gb": 56,
            }

            def fake_run(command, label, environment=None):
                output = Path(command[command.index("-out") + 1])
                output.write_text("", encoding="utf-8")

            runner.run_command = fake_run
            runner._genome_unmapped_trinity(
                directory / "reference.fasta",
                [
                    {
                        "sample_id": "XL_2",
                        "pair_count": 1500,
                        "read1": directory / "fully_unmapped_1.fastq.gz",
                        "read2": directory / "fully_unmapped_2.fastq.gz",
                    }
                ],
                1500,
                work_root,
                None,
            )
            output_root = runner.output_root / "55_unmapped_trinity"
            with (output_root / "assembly_manifest.json").open("r", encoding="utf-8") as handle:
                manifest = json.load(handle)
            self.assertEqual(manifest["strategy"], "mapping_first_then_trinity")
            self.assertEqual(manifest["total_fully_unmapped_read_pairs"], 1500)
            self.assertEqual(manifest["status"], "assembled")
            self.assertTrue((output_root / "non_reference_candidates.fasta").is_file())
            self.assertEqual(
                runner.artifacts["unmapped_trinity_non_reference_candidates"],
                str(output_root / "non_reference_candidates.fasta"),
            )


if __name__ == "__main__":
    unittest.main()
