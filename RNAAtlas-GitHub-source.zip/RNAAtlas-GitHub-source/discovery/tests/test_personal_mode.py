import gzip
import os
import pwd
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from scripts import service_api
from rnaseq_service.project import create_project, load_project_config, validate_project
from rnaseq_service.genotypes import locate_genotype_vcf
from rnaseq_service import paths
from rnaseq_service.pipeline import PipelineRunner
from rnaseq_service.references import list_references
from rnaseq_service.registry import register_user
from rnaseq_service.slurm import render_slurm_script


class PersonalModeTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name) / "member"
        self.root.mkdir()
        self.projects = self.root / "projects"
        self.projects.mkdir()
        self.email = "{}@dartmouth.edu".format(pwd.getpwuid(os.geteuid()).pw_name)
        self.root_patch = patch.object(service_api, "service_root", return_value=self.root)
        self.root_patch.start()
        self.mode_patch = patch.dict(os.environ, {"LIAO_RNASEQ_PERSONAL_MODE": "1"})
        self.mode_patch.start()
        register_user(self.email, root=self.root, admin_emails={self.email})
        create_project("project1", root=self.root, owner_email=self.email)

    def tearDown(self):
        self.mode_patch.stop()
        self.root_patch.stop()
        self.temporary.cleanup()

    def make_prepared_project(self, name="experiment1"):
        project = self.projects / name
        reads = project / "datasets" / "raw_data" / "S1"
        reads.mkdir(parents=True)
        metadata = project / "datasets" / "meta_data"
        metadata.mkdir()
        (metadata / "sample_sheet.tsv").write_text("sample_id\tcondition\nS1\tcontrol\n", encoding="utf-8")
        with gzip.open(str(reads / "S1_1.fq.gz"), "wt", encoding="ascii") as handle:
            handle.write("@read/1\nACGT\n+\nIIII\n")
        with gzip.open(str(reads / "S1_2.fq.gz"), "wt", encoding="ascii") as handle:
            handle.write("@read/2\nTGCA\n+\nIIII\n")
        return project

    def test_prepared_project_keeps_nested_inputs_and_module_results(self):
        project = self.make_prepared_project()
        previous_result = project / "results" / "trinity" / "previous_run" / "result.txt"
        previous_result.parent.mkdir(parents=True)
        previous_result.write_text("previous", encoding="utf-8")
        with patch.object(service_api, "allowed_email", return_value=self.email):
            folders = service_api.browse_project_folders(self.email)["folders"]
            self.assertIn({"name": "experiment1", "path": str(project), "kind": "prepared"}, folders)
            self.assertNotIn("shared", [folder["name"] for folder in folders])
            preview = service_api.preview_prepared_project(self.email, "experiment1")
            self.assertEqual(preview["errors"], [])
            self.assertEqual(preview["fastq_profile"]["samples"]["S1"]["sampled_read_pairs"], 1)
            created = service_api.create_project_for_user({"email": self.email, "name": "experiment1"})
            self.assertEqual(created["path"], str(project))
            self.assertEqual(previous_result.read_text(encoding="utf-8"), "previous")
            self.assertEqual(load_project_config("experiment1", root=self.root)["input_subdirectory"], "datasets")
            validation = validate_project("experiment1", root=self.root)
            self.assertEqual(validation["metadata_file"], str(project / "datasets" / "meta_data" / "sample_sheet.tsv"))
            self.assertEqual(validation["samples"][0]["read1"], str(project / "datasets" / "raw_data" / "S1" / "S1_1.fq.gz"))
            vcf = project / "datasets" / "meta_data" / "dna_genotypes.vcf"
            vcf.write_text("##fileformat=VCFv4.2\n", encoding="utf-8")
            self.assertEqual(locate_genotype_vcf(project), vcf)
            result = project / "results" / "trinity" / "run1"
            result.mkdir()
            (result / "result.txt").write_text("done", encoding="utf-8")
            self.assertIn("experiment1", [item["name"] for item in service_api.browse_project_folders(self.email)["folders"]])
            self.assertEqual((result / "result.txt").read_text(encoding="utf-8"), "done")

    def test_single_end_prepared_project_loads_without_a_mate(self):
        project = self.make_prepared_project()
        reads = project / "datasets" / "raw_data" / "S1"
        (reads / "S1_1.fq.gz").rename(reads / "S1.fq.gz")
        (reads / "S1_2.fq.gz").unlink()
        with patch.object(service_api, "allowed_email", return_value=self.email):
            preview = service_api.preview_prepared_project(self.email, "experiment1")
            self.assertEqual(preview["errors"], [])
            self.assertEqual(preview["fastq_profile"]["samples"]["S1"]["sampled_reads"], 1)
            service_api.create_project_for_user({"email": self.email, "name": "experiment1"})
            validation = validate_project("experiment1", root=self.root)
            self.assertEqual(validation["read_layout"], "single")
            self.assertEqual(validation["samples"][0]["read2"], "")

    def test_explicit_single_layout_accepts_sra_style_read_filename(self):
        project = self.make_prepared_project()
        reads = project / "datasets" / "raw_data" / "S1"
        (reads / "S1_1.fq.gz").rename(reads / "S1_1.fastq.gz")
        (reads / "S1_2.fq.gz").unlink()
        (project / "datasets" / "meta_data" / "sample_sheet.tsv").write_text(
            "sample_id\tcondition\tlayout\nS1\tcontrol\tsingle\n", encoding="utf-8",
        )
        with patch.object(service_api, "allowed_email", return_value=self.email):
            preview = service_api.preview_prepared_project(self.email, "experiment1")
            self.assertEqual(preview["errors"], [])
            self.assertEqual(preview["read_layout"], "single")
            service_api.create_project_for_user({"email": self.email, "name": "experiment1"})
        validation = validate_project("experiment1", root=self.root)
        self.assertFalse(any("Sample S1" in error for error in validation["errors"]))
        self.assertEqual(validation["read_layout"], "single")
        self.assertTrue(validation["samples"][0]["read1"].endswith("S1_1.fastq.gz"))

    def test_invalid_prepared_project_is_not_registered(self):
        project = self.make_prepared_project()
        (project / "datasets" / "raw_data" / "S1" / "S1_2.fq.gz").unlink()
        with patch.object(service_api, "allowed_email", return_value=self.email):
            preview = service_api.preview_prepared_project(self.email, "experiment1")
            self.assertTrue(preview["errors"])
            with self.assertRaisesRegex(ValueError, "Fix prepared project data"):
                service_api.create_project_for_user({"email": self.email, "name": "experiment1"})
        self.assertFalse((project / "project_config.json").exists())

    def test_symlinked_prepared_inputs_are_rejected(self):
        project = self.make_prepared_project()
        reads = project / "datasets" / "raw_data" / "S1" / "S1_2.fq.gz"
        reads.unlink()
        reads.symlink_to(project / "datasets" / "raw_data" / "S1" / "S1_1.fq.gz")
        with patch.object(service_api, "allowed_email", return_value=self.email):
            with self.assertRaisesRegex(ValueError, "symbolic links"):
                service_api.preview_prepared_project(self.email, "experiment1")
        self.assertFalse((project / "project_config.json").exists())

    def test_bounded_dataset_listing_and_rollback(self):
        base = self.root / "datasets"
        dataset = base / "experiment1"
        (dataset / "meta_data").mkdir(parents=True)
        (dataset / "raw_data").mkdir()
        with patch.object(service_api, "allowed_email", return_value=self.email):
            listed = service_api.list_datasets(self.email)
            self.assertEqual([item["name"] for item in listed["datasets"]], ["experiment1"])
            with patch.object(service_api, "_attach_intake_locked", side_effect=ValueError("invalid reads")):
                with self.assertRaisesRegex(ValueError, "invalid reads"):
                    service_api.attach_dataset({"email": self.email, "project": "project1", "dataset": "experiment1"})
        self.assertTrue(dataset.is_dir())
        self.assertFalse((self.root / "user_data").joinpath("experiment1").exists())

    def test_metadata_preview_is_private_and_does_not_move_reads(self):
        dataset = self.root / "datasets" / "experiment1"
        metadata = dataset / "meta_data"
        metadata.mkdir(parents=True)
        (dataset / "raw_data").mkdir()
        (metadata / "sample_sheet.tsv").write_text(
            "sample_id\tcondition\nS1\tcontrol\nS2\ttreated\n", encoding="utf-8",
        )
        with patch.object(service_api, "allowed_email", return_value=self.email):
            preview = service_api.preview_dataset(self.email, "experiment1")
            self.assertEqual(preview["sample_count"], 2)
            self.assertEqual(preview["valid_sample_count"], 0)
            self.assertEqual(len(preview["input_checks"]), 2)
            self.assertIn("raw_data/S1 folder", preview["errors"][0])
            self.assertEqual(preview["conditions"], ["control", "treated"])
            self.assertEqual(preview["samples"][0], {"sample_id": "S1", "condition": "control"})
            self.assertTrue(dataset.is_dir())
            with self.assertRaises(ValueError):
                service_api.preview_dataset(self.email, "../experiment1")

    def test_dataset_preview_reports_mismatched_fastq_names(self):
        dataset = self.root / "datasets" / "experiment1"
        (dataset / "meta_data").mkdir(parents=True)
        (dataset / "raw_data" / "S1").mkdir(parents=True)
        (dataset / "meta_data" / "sample_sheet.tsv").write_text(
            "sample_id\tcondition\nS1\tcontrol\nS2\ttreated\n", encoding="utf-8",
        )
        (dataset / "raw_data" / "S1" / "S1_1.fq.gz").write_bytes(b"R1")
        (dataset / "raw_data" / "S1" / "wrong_2.fq.gz").write_bytes(b"R2")
        with patch.object(service_api, "allowed_email", return_value=self.email):
            preview = service_api.preview_dataset(self.email, "experiment1")
        self.assertEqual(preview["input_checks"][0]["read1"], "S1_1.fq.gz")
        self.assertEqual(preview["input_checks"][0]["read2"], "")
        self.assertIn("wrong_2.fq.gz", preview["errors"][0])
        self.assertIn("S2", preview["errors"][1])

    def test_dataset_preview_checks_sampled_read_pairs(self):
        dataset = self.root / "datasets" / "experiment1"
        (dataset / "meta_data").mkdir(parents=True)
        reads = dataset / "raw_data" / "S1"
        reads.mkdir(parents=True)
        (dataset / "meta_data" / "sample_sheet.tsv").write_text(
            "sample_id\tcondition\nS1\tcontrol\n", encoding="utf-8",
        )
        with gzip.open(str(reads / "S1_1.fq.gz"), "wt", encoding="ascii") as handle:
            handle.write("@read/1\nACGT\n+\nIIII\n")
        with gzip.open(str(reads / "S1_2.fq.gz"), "wt", encoding="ascii") as handle:
            handle.write("@read/2\nTGCA\n+\nIIII\n")
        with patch.object(service_api, "allowed_email", return_value=self.email):
            preview = service_api.preview_dataset(self.email, "experiment1")
            self.assertEqual(preview["errors"], [])
            self.assertEqual(preview["fastq_profile"]["samples"]["S1"]["sampled_read_pairs"], 1)
            with gzip.open(str(reads / "S1_2.fq.gz"), "wt", encoding="ascii") as handle:
                handle.write("@wrong/2\nTGCA\n+\nIIII\n")
            invalid = service_api.preview_dataset(self.email, "experiment1")
        self.assertIn("Paired FASTQ names differ", invalid["errors"][0])
        self.assertEqual(invalid["fastq_profile"], {})

    def test_dataset_preview_rejects_sample_sheet_row_without_id(self):
        dataset = self.root / "datasets" / "experiment1"
        (dataset / "meta_data").mkdir(parents=True)
        (dataset / "raw_data").mkdir()
        (dataset / "meta_data" / "sample_sheet.tsv").write_text(
            "sample_id\tcondition\n\tcontrol\n", encoding="utf-8",
        )
        with patch.object(service_api, "allowed_email", return_value=self.email):
            with self.assertRaisesRegex(ValueError, "row without sample_id"):
                service_api.preview_dataset(self.email, "experiment1")

    def test_dataset_preview_rejects_sample_sheet_row_without_condition(self):
        dataset = self.root / "datasets" / "experiment1"
        (dataset / "meta_data").mkdir(parents=True)
        (dataset / "raw_data").mkdir()
        (dataset / "meta_data" / "sample_sheet.tsv").write_text(
            "sample_id\tcondition\nS1\n", encoding="utf-8",
        )
        with patch.object(service_api, "allowed_email", return_value=self.email):
            with self.assertRaisesRegex(ValueError, "S1 has no condition"):
                service_api.preview_dataset(self.email, "experiment1")

    def test_new_project_has_private_results_folder(self):
        results = self.projects / "project1" / "results"
        self.assertTrue(results.is_dir())
        self.assertEqual(results.stat().st_mode & 0o777, 0o700)

    def test_personal_projects_are_inside_projects_folder(self):
        self.assertEqual(paths.project_root("project1", root=self.root), self.projects / "project1")
        for reserved in ("app", "scripts", "shared", "datasets", "projects"):
            with self.subTest(reserved=reserved), self.assertRaisesRegex(ValueError, "reserved"):
                paths.project_root(reserved, root=self.root)
        with patch.dict(os.environ, {"LIAO_RNASEQ_PERSONAL_MODE": "0"}):
            self.assertEqual(paths.project_root("project1", root=self.root), self.root / "projects" / "project1")

    def test_personal_slurm_script_never_uses_service_keytab(self):
        job = {
            "project_name": "project1", "project_root": str(self.projects / "project1"),
            "service_root": str(self.root), "code_root": str(self.root),
            "shared_root": "/dartfs/rc/lab/L/LiaoC/Service_Account/RNAseq_atlas",
            "runtime_root": "/dartfs/rc/lab/L/LiaoC/Service_Account/RNAseq_atlas/shared/runtime",
            "output_root": str(self.projects / "project1" / "results" / "jobs" / "one"),
            "job_config_path": str(self.root / "job.json"),
            "options": {"partition": "standard", "threads": 1, "memory": "4G", "time_limit": "01:00:00"},
            "personal_mode": True,
        }
        script = render_slurm_script(job)
        self.assertIn("LIAO_RNASEQ_PERSONAL_MODE=1", script)
        self.assertIn("No delegated Kerberos ticket", script)
        self.assertNotIn("SERVICE_KEYTAB", script)
        self.assertIn('PROJECT_BASE="${SERVICE_ROOT}/projects"', script)
        self.assertIn('"${PROJECT_ROOT}" != "${PROJECT_BASE}/${PROJECT_NAME}"', script)
        self.assertIn('python3 "${CODE_ROOT}/scripts/run_pipeline.py"', script)

    def test_shared_reference_catalog_stays_outside_private_workspace(self):
        shared = Path(self.temporary.name) / "read_only_assets"
        (shared / "shared" / "references" / "reference1").mkdir(parents=True)
        (shared / "shared" / "runtime").mkdir()
        with patch.object(paths, "DISCOVERY_ROOT", shared), patch.dict(os.environ, {
            "LIAO_RNASEQ_SHARED_ROOT": str(shared),
        }):
            self.assertEqual(paths.runtime_root(self.root), (shared / "shared" / "runtime").resolve())
            references = list_references(root=self.root, ready_only=False)
        self.assertEqual([item["id"] for item in references], ["reference1"])
        self.assertTrue(references[0]["manifest"].startswith(str(shared.resolve())))

    def test_deseq2_uses_shared_read_only_script(self):
        runner = PipelineRunner.__new__(PipelineRunner)
        runner.service_root = self.root
        runner.output_root = self.root
        runner.runtime = self.root / "runtime"
        runner.validation = {
            "reference_has_annotation": True,
            "config": {"strandedness": "reverse"},
        }
        runner.options = {"run_differential_expression": True, "reference_condition": "control"}
        runner.artifacts = {"sample_sheet": str(self.root / "samples.tsv")}
        runner.update_status = lambda *args: None
        runner.tool = lambda name: name
        commands = []
        runner.run_command = lambda command, label, environment=None: commands.append(command)
        shared = Path(self.temporary.name) / "read_only_assets"
        with patch("rnaseq_service.pipeline.combine_star_counts", return_value={
            "counts": str(self.root / "counts.tsv"), "qc": str(self.root / "qc.tsv"),
        }), patch("rnaseq_service.pipeline.shared_assets_root", return_value=shared):
            runner.expression({})
        self.assertEqual(commands[0][1], str(shared / "r" / "run_deseq2.R"))


if __name__ == "__main__":
    unittest.main()
