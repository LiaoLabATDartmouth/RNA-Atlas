import tempfile
import unittest
import zipfile
from pathlib import Path

from rnaseq_service.pipeline import PipelineRunner


class ReportingTests(unittest.TestCase):
    def test_report_renders_css_and_builds_deliverable(self):
        with tempfile.TemporaryDirectory() as temporary:
            output_root = Path(temporary)
            artifact = output_root / "artifact.tsv"
            artifact.write_text("value\n", encoding="utf-8")
            snapshot = output_root / "_code" / "scripts"
            snapshot.mkdir(parents=True)
            (snapshot / "run_pipeline.py").write_text("pass\n", encoding="utf-8")

            runner = object.__new__(PipelineRunner)
            runner.output_root = output_root
            runner.job = {"job_id": "20260814-example", "project_name": "Example"}
            runner.validation = {"samples": [{"sample_id": "S1"}], "conditions": ["test"], "warnings": []}
            runner.options = {"run_ase": False}
            runner.artifacts = {"example": str(artifact)}
            runner.update_status = lambda *args, **kwargs: None

            runner.report()

            report = output_root / "91_reports" / "index.html"
            deliverable = output_root / "Example_20260814_results.zip"
            self.assertIn("body{font:16px system-ui", report.read_text(encoding="utf-8"))
            self.assertTrue(deliverable.is_file())
            with zipfile.ZipFile(deliverable) as archive:
                self.assertIn("artifact.tsv", archive.namelist())
                self.assertIn("91_reports/index.html", archive.namelist())
                self.assertNotIn("_code/scripts/run_pipeline.py", archive.namelist())


if __name__ == "__main__":
    unittest.main()
