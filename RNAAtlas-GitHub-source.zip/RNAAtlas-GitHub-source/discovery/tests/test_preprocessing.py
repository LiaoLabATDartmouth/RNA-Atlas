import unittest

from rnaseq_service.preprocessing import fastp_command, normalize_preprocessing_options


class PreprocessingTests(unittest.TestCase):
    def test_single_end_fastp_uses_only_one_read(self):
        options = normalize_preprocessing_options({"trimming_mode": "auto"}, layout="single-end")
        command = fastp_command("fastp", {"read1": "S1.fq.gz", "read2": ""}, "clean.fq.gz", "",
                                "report.json", "report.html", options, 4)
        for flag in ("--in2", "--out2", "--detect_adapter_for_pe", "--trim_front2", "--adapter_sequence_r2"):
            self.assertNotIn(flag, command)
        self.assertIn("--in1", command)
        with self.assertRaisesRegex(ValueError, "R2 adapter"):
            normalize_preprocessing_options({"trimming_mode": "custom", "library_prep": "test",
                                             "trim_front_read2": 3}, layout="single-end")

    def test_single_end_custom_adapter_and_no_trim(self):
        custom = normalize_preprocessing_options({
            "trimming_mode": "custom", "library_prep": "known kit", "adapter_handling": "provided",
            "adapter_read1": "ACGTACGT", "trim_front_read1": 2,
        }, layout="single-end")
        command = fastp_command("fastp", {"read1": "S1.fq.gz", "read2": ""}, "clean.fq.gz", "",
                                "report.json", "report.html", custom, 2)
        self.assertEqual(command[command.index("--adapter_sequence") + 1], "ACGTACGT")
        self.assertNotIn("--adapter_sequence_r2", command)
        self.assertNotIn("--trim_front2", command)
        untrimmed = normalize_preprocessing_options({"trimming_mode": "none"}, layout="single-end")
        self.assertEqual(untrimmed["trimming_mode"], "none")

    def test_auto_mode_uses_conservative_noncorrecting_fastp_options(self):
        options = normalize_preprocessing_options({"trimming_mode": "auto", "library_type": "standard_bulk"})
        command = fastp_command(
            "fastp", {"read1": "R1.fastq.gz", "read2": "R2.fastq.gz"},
            "clean_R1.fastq.gz", "clean_R2.fastq.gz", "fastp.json", "fastp.html", options, 8,
        )
        self.assertIn("--detect_adapter_for_pe", command)
        self.assertIn("--disable_trim_poly_g", command)
        self.assertNotIn("--correction", command)
        self.assertNotIn("--dedup", command)
        self.assertNotIn("--trim_poly_x", command)

    def test_custom_mode_requires_prep_and_both_declared_adapters(self):
        with self.assertRaisesRegex(ValueError, "library kit"):
            normalize_preprocessing_options({"trimming_mode": "custom", "library_type": "custom_bulk"})
        with self.assertRaisesRegex(ValueError, "both R1 and R2"):
            normalize_preprocessing_options(
                {
                    "trimming_mode": "custom", "library_type": "custom_bulk", "library_prep": "Custom kit",
                    "adapter_handling": "provided", "adapter_read1": "ACGTACGT",
                }
            )

    def test_umi_and_specialized_libraries_fail_closed(self):
        with self.assertRaisesRegex(ValueError, "UMI-aware"):
            normalize_preprocessing_options(
                {"trimming_mode": "custom", "library_type": "custom_bulk", "library_prep": "UMI kit", "umi_status": "present"}
            )
        with self.assertRaisesRegex(ValueError, "dedicated library-specific workflow"):
            normalize_preprocessing_options({"trimming_mode": "none", "library_type": "single_cell"})

    def test_custom_mode_accepts_exact_fixed_trims(self):
        options = normalize_preprocessing_options(
            {
                "trimming_mode": "custom", "library_type": "custom_bulk", "library_prep": "Lab protocol v2",
                "adapter_handling": "none", "trim_front_read1": 8, "trim_front_read2": 4,
                "trim_quality_tails": False, "strandedness": "reverse", "umi_status": "none",
            }
        )
        command = fastp_command(
            "fastp", {"read1": "R1", "read2": "R2"}, "O1", "O2", "report.json", "report.html", options, 2,
        )
        self.assertIn("--disable_adapter_trimming", command)
        self.assertIn("--trim_front1", command)
        self.assertEqual(command[command.index("--trim_front2") + 1], "4")
        self.assertNotIn("--cut_right", command)

    def test_custom_zero_read2_trim_does_not_inherit_read1(self):
        options = normalize_preprocessing_options({
            "trimming_mode": "custom", "library_type": "custom_bulk", "library_prep": "QA kit",
            "trim_front_read1": 2, "trim_front_read2": 0, "trim_tail_read1": 0, "trim_tail_read2": 3,
        })
        command = fastp_command("fastp", {"read1": "R1", "read2": "R2"}, "O1", "O2", "r.json", "r.html", options, 1)
        self.assertEqual(command[command.index("--trim_front2") + 1], "0")
        self.assertEqual(command[command.index("--trim_tail1") + 1], "0")
        self.assertEqual(command[command.index("--trim_tail2") + 1], "3")


if __name__ == "__main__":
    unittest.main()
