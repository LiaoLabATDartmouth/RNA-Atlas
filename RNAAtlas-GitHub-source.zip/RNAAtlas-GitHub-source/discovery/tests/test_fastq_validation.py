import gzip
import tempfile
import unittest
from pathlib import Path

from rnaseq_service.fastq_validation import (
    FastqFormatError,
    compression_format,
    parse_fastq_header,
    profile_fastq_pair,
    sample_fastq_read_lengths,
    validate_fastq_pair,
    validate_fastq_single,
)


class FastqValidationTests(unittest.TestCase):
    def write_fastq(self, path, text):
        with gzip.open(str(path), "wt", encoding="ascii") as handle:
            handle.write(text)

    def test_validates_names_and_lengths(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            first = root / "R1.fq.gz"
            second = root / "R2.fq.gz"
            self.write_fastq(first, "@read/1\nACGT\n+\nIIII\n")
            self.write_fastq(second, "@read/2\nTGCA\n+\nIIII\n")
            self.assertEqual(validate_fastq_pair(first, second), 1)
            self.assertEqual(
                sample_fastq_read_lengths(
                    [{"sample_id": "S1", "read1": str(first), "read2": str(second)}]
                ),
                {"S1": {"read1": 4, "read2": 4}},
            )

    def test_single_end_profile_and_complete_validation(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "S1.fq.gz"
            self.write_fastq(path, "@read1\nACGT\n+\nIIII\n@read2\nTGCA\n+\nHHHH\n")
            self.assertEqual(validate_fastq_single(path), 2)
            profile = profile_fastq_pair(path, maximum_records=10)
            self.assertEqual(profile["layout"], "single-end")
            self.assertEqual(profile["sampled_reads"], 2)
            self.assertNotIn("read2", profile["read_lengths"])
            self.assertEqual(sample_fastq_read_lengths([{"sample_id": "S1", "read1": str(path), "read2": ""}]),
                             {"S1": {"read1": 4}})
            self.write_fastq(path, "@read1\nACGT\n+\nIII\n")
            with self.assertRaisesRegex(FastqFormatError, "sequence length 4 but quality length 3"):
                validate_fastq_single(path)

    def test_single_end_sra_header_and_late_mate_error(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "SRR123.fastq.gz"
            self.write_fastq(path, "@SRR123.1 instrument metadata length=4\nACGT\n+\nIIII\n")
            profile = profile_fastq_pair(path)
            self.assertEqual(profile["sampled_reads"], 1)
            self.assertNotIn("mate", profile["headers"]["read1"])
            self.assertEqual(validate_fastq_single(path), 1)
            self.write_fastq(path, "@SRR123.1 instrument metadata length=4\nACGT\n+\nIIII\n"
                                   "@SRR123.2/2\nTGCA\n+\nIIII\n")
            with self.assertRaisesRegex(FastqFormatError, "unexpected read mate"):
                validate_fastq_single(path)

    def test_rejects_sequence_quality_length_mismatch(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            first = root / "R1.fq.gz"
            second = root / "R2.fq.gz"
            self.write_fastq(first, "@read/1\nACGT\n+\nIII\n")
            self.write_fastq(second, "@read/2\nTGCA\n+\nIIII\n")
            with self.assertRaisesRegex(FastqFormatError, "sequence length 4 but quality length 3"):
                validate_fastq_pair(first, second)

    def test_profiles_inferable_fastq_metadata_without_guessing_library_prep(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            first = root / "sample_1.fastq.gz"
            second = root / "sample_2.fastq.gz"
            self.write_fastq(
                first,
                "@VH01531:160:AAG5GW7M5:1:1101:1:1 1:N:0:AGTTCC\nACGTACGT\n+\nIIIIIIII\n",
            )
            self.write_fastq(
                second,
                "@VH01531:160:AAG5GW7M5:1:1101:1:1 2:N:0:AGTTCC\nTGCATGCA\n+\nHHHHHHHH\n",
            )
            profile = profile_fastq_pair(first, second, maximum_records=10)
            self.assertEqual(compression_format(first), "gzip")
            self.assertEqual(profile["layout"], "paired-end")
            self.assertEqual(profile["sampled_read_pairs"], 1)
            self.assertEqual(profile["read_lengths"]["read1"]["maximum"], 8)
            self.assertEqual(profile["headers"]["read1"]["instrument"], "VH01531")
            self.assertEqual(profile["headers"]["read2"]["mate"], "2")
            self.assertEqual(profile["headers"]["read1"]["sample_index"], "AGTTCC")

    def test_parses_unrecognized_header_without_claiming_illumina_metadata(self):
        parsed = parse_fastq_header("@custom_read/1")
        self.assertEqual(parsed["header_format"], "unrecognized")
        self.assertEqual(parsed["mate"], "1")

    def test_profile_rejects_invalid_header_and_reversed_mates(self):
        with tempfile.TemporaryDirectory() as temporary:
            first = Path(temporary) / "S1_1.fq.gz"
            second = Path(temporary) / "S1_2.fq.gz"
            self.write_fastq(first, "read/1\nACGT\n+\nIIII\n")
            self.write_fastq(second, "@read/2\nTGCA\n+\nIIII\n")
            with self.assertRaisesRegex(FastqFormatError, "invalid FASTQ header"):
                profile_fastq_pair(first, second)
            self.write_fastq(first, "@read/2\nACGT\n+\nIIII\n")
            with self.assertRaisesRegex(FastqFormatError, "unexpected read mate"):
                profile_fastq_pair(first, second)


if __name__ == "__main__":
    unittest.main()
