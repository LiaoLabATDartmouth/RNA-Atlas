import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from rnaseq_service.registry import create_job_record, update_job
from rnaseq_service import slurm
from scripts import service_api


class ManualSubmissionTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.job_id = "20261105-testjob"
        self.output = self.root / "test_project" / "results" / "differential_expression" / self.job_id
        self.output.mkdir(parents=True)
        module = self.root / "app" / "rnaseq_service" / "__init__.py"
        module.parent.mkdir(parents=True)
        module.write_text("\n", encoding="utf-8")
        scripts = self.root / "scripts"
        scripts.mkdir()
        for name in ("run_pipeline.py", "notify_job.py"):
            (scripts / name).write_text("pass\n", encoding="utf-8")
        code_root, code_manifest_sha256 = slurm.create_code_snapshot(self.root, self.output)
        self.script = self.output / "rnaseq.sbatch"
        self.script.write_text("#!/bin/bash\ntrue\n", encoding="utf-8")
        self.config = self.output / "job_config.json"
        self.config.write_text("{}\n", encoding="utf-8")
        self.email = "f123abc@dartmouth.edu"
        create_job_record({
            "job_id": self.job_id, "project_name": "test_project", "module": "differential_expression",
            "submitter_email": self.email, "personal_mode": True, "status": "prepared",
            "output_root": str(self.output), "slurm_script": str(self.script),
            "job_config_path": str(self.config), "status_path": str(self.output / "status.json"),
            "code_root": str(code_root), "code_manifest_sha256": code_manifest_sha256,
            "slurm_script_sha256": hashlib.sha256(self.script.read_bytes()).hexdigest(),
            "job_config_sha256": hashlib.sha256(self.config.read_bytes()).hexdigest(),
        }, root=self.root)
        self.environment = patch.dict(os.environ, {"LIAO_RNASEQ_PERSONAL_MODE": "1"})
        self.root_patch = patch.object(service_api, "service_root", return_value=self.root)
        self.user_patch = patch.object(service_api, "approved_user", side_effect=lambda email: {"email": email})
        self.project_patch = patch.object(service_api, "owned_project", return_value=({}, {}))
        for context in (self.environment, self.root_patch, self.user_patch, self.project_patch):
            context.start()

    def tearDown(self):
        for context in (self.project_patch, self.user_patch, self.root_patch, self.environment):
            context.stop()
        self.temporary.cleanup()

    def test_submits_unchanged_prepared_job_once(self):
        with patch.object(service_api, "submit_job", return_value={"status": "submitted", "slurm_job_id": "123"}) as submit:
            self.assertEqual(service_api.submit_prepared_job(self.email, self.job_id)["slurm_job_id"], "123")
            submit.assert_called_once()
        update_job(self.job_id, {"status": "submitted", "slurm_job_id": "123"}, root=self.root)
        with self.assertRaisesRegex(ValueError, "already submitted"):
            service_api.submit_prepared_job(self.email, self.job_id)

    def test_rejects_changed_script_and_wrong_identity(self):
        self.script.write_text("#!/bin/bash\necho changed\n", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "file changed"):
            service_api.submit_prepared_job(self.email, self.job_id)
        with self.assertRaisesRegex(ValueError, "not found for this Discovery account"):
            service_api.submit_prepared_job("other@dartmouth.edu", self.job_id)

    def test_rejects_changed_pipeline_snapshot(self):
        source = self.output / "_code" / "scripts" / "run_pipeline.py"
        source.chmod(0o644)
        source.write_text("changed\n", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "pipeline code changed"):
            service_api.submit_prepared_job(self.email, self.job_id)

    def test_preparation_records_script_command_and_integrity_hashes(self):
        validation = {
            "errors": [], "config": {}, "conditions": ["control", "treated"],
            "reference_has_annotation": True, "project_root": str(self.root / "test_project"),
            "samples": [{"sample_id": "S1"}, {"sample_id": "S2"}], "warnings": [],
        }
        with patch.object(slurm, "load_project_config", return_value={}), patch.object(
            slurm, "validate_project", return_value=validation,
        ), patch.object(slurm, "normalize_preprocessing_options", return_value={}), patch.object(
            slurm, "runtime_root", return_value=self.root,
        ), patch.object(slurm, "shared_assets_root", return_value=self.root):
            job = slurm.prepare_job("test_project", self.email, {
                "reference_condition": "control", "run_differential_expression": True,
                "run_rna_variants": False, "run_ase": False, "run_trinity": False,
            }, root=self.root)
        self.assertEqual(job["status"], "prepared")
        self.assertNotIn("slurm_job_id", job)
        self.assertIn("/scripts/submit_prepared.py", job["manual_submit_command"])
        self.assertTrue(job["manual_submit_command"].endswith(" " + job["job_id"]))
        self.assertEqual(job["slurm_script_sha256"], hashlib.sha256(Path(job["slurm_script"]).read_bytes()).hexdigest())
        self.assertEqual(job["job_config_sha256"], hashlib.sha256(Path(job["job_config_path"]).read_bytes()).hexdigest())
        self.assertEqual(Path(job["code_root"]).parent, Path(job["output_root"]))
        slurm.verify_code_snapshot(job, Path(job["output_root"]))
        script_text = Path(job["slurm_script"]).read_text(encoding="utf-8")
        self.assertIn("CODE_MANIFEST_SHA256=", script_text)
        subprocess.run(["bash", "-n", job["slurm_script"]], check=True)
        if sys.platform.startswith("linux") and shutil.which("sha256sum"):
            code_check = next(line for line in script_text.splitlines() if "Prepared pipeline code changed." in line)
            environment = {**os.environ, "CODE_ROOT": job["code_root"],
                           "CODE_MANIFEST_SHA256": job["code_manifest_sha256"]}
            subprocess.run(["bash", "-c", code_check], env=environment, check=True)
            snapshot_file = Path(job["code_root"]) / "scripts" / "run_pipeline.py"
            snapshot_file.chmod(0o644)
            snapshot_file.write_text("changed\n", encoding="utf-8")
            result = subprocess.run(["bash", "-c", code_check], env=environment,
                                    capture_output=True, check=False)
            self.assertEqual(result.returncode, 2)


if __name__ == "__main__":
    unittest.main()
