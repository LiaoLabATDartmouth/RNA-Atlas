import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from rnaseq_service.pipeline import PipelineError, PipelineRunner, recommended_star_sa_index_nbases, retain_star_outputs


class PipelineTests(unittest.TestCase):
    def test_small_alignment_requires_review_then_allows_explicit_override(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            runner = object.__new__(PipelineRunner)
            runner.output_root = root / "result"
            runner.output_root.mkdir()
            runner.tmp_directory = root / "scratch"
            runner.tmp_directory.mkdir()
            runner.job = {"project_name": "Example", "job_id": "job123456789"}
            runner.validation = {"reference_has_annotation": True, "reference_id": "test",
                                 "annotation_file": "genes.gtf", "config": {"strandedness": "reverse"}}
            runner.analysis_samples = [{"sample_id": "S1", "read1": "S1_1.fq.gz", "read2": "S1_2.fq.gz"},
                                       {"sample_id": "S2", "read1": "S2_1.fq.gz", "read2": "S2_2.fq.gz"}]
            runner.options = {"threads": 4, "run_differential_expression": True, "strandedness": "auto"}
            runner.artifacts = {}
            statuses = []
            runner.update_status = lambda *args: statuses.append(args)
            runner.log = lambda *args: None
            runner.tool = lambda name: name

            def write_star_output(command, label):
                work = root / "scratch" / "strand_check" / label.split()[-1]
                if work.name == "S1":
                    forward, reverse = 450, 10
                else:
                    forward, reverse = 10, 450
                (work / "ReadsPerGene.out.tab").write_text(
                    "GeneA\t460\t{}\t{}\n".format(forward, reverse), encoding="utf-8",
                )
                (work / "Log.final.out").write_text("Number of input reads | 50000\n", encoding="utf-8")
                self.assertIn("--readMapNumber", command)
                self.assertIn("--outSAMtype", command)
                self.assertEqual(command[command.index("--outSAMtype") + 1], "None")

            runner.run_command = write_star_output
            self.assertFalse(runner.check_strandedness("index"))
            evidence = runner.artifacts["strandedness_check"]
            self.assertEqual(evidence["project_inference"], "needs_review")
            self.assertEqual(evidence["status"], "needs_review")
            self.assertTrue(Path(runner.artifacts["deliverable"]).is_file())
            self.assertEqual(statuses[-1][0], "needs_review")
            runner.options.update({"strandedness": "reverse", "strandedness_reviewed": True})
            self.assertTrue(runner.check_strandedness("index"))
            self.assertEqual(runner.options["resolved_strandedness"], "reverse")

    def test_expression_uses_submitted_strandedness_and_reporting_cutoffs(self):
        with tempfile.TemporaryDirectory() as temporary:
            runner = object.__new__(PipelineRunner)
            runner.service_root = Path(temporary)
            runner.output_root = Path(temporary) / "result"
            runner.options = {
                "strandedness": "unstranded", "run_differential_expression": True,
                "reference_condition": "WT", "padj_cutoff": 0.01, "log2fc_cutoff": 1.0,
            }
            runner.validation = {"reference_has_annotation": True, "config": {"strandedness": "reverse"}}
            runner.artifacts = {"sample_sheet": "sample_sheet.tsv"}
            runner.update_status = lambda *args: None
            runner.r_script_command = lambda script, args: (args, {})
            commands = []
            runner.run_command = lambda command, label, environment=None: commands.append(command)
            with patch("rnaseq_service.pipeline.combine_star_counts", return_value={
                "counts": "counts.tsv", "qc": "star_count_qc.tsv",
            }) as combine:
                runner.expression({"S1": "alignment"})
            self.assertEqual(combine.call_args.args[1], "unstranded")
            self.assertEqual(commands[0][commands[0].index("--padj") + 1], "0.01")
            self.assertEqual(commands[0][commands[0].index("--log2fc") + 1], "1.0")

    def test_non_expression_module_uses_unstranded_counts_without_a_strand_check(self):
        with tempfile.TemporaryDirectory() as temporary:
            runner = object.__new__(PipelineRunner)
            runner.output_root = Path(temporary)
            runner.options = {"strandedness": "auto", "run_differential_expression": False}
            runner.validation = {"reference_has_annotation": True, "config": {"strandedness": "reverse"}}
            runner.artifacts = {}
            runner.update_status = lambda *args: None
            runner.log = lambda *args: None
            with patch("rnaseq_service.pipeline.combine_star_counts", return_value={
                "counts": "counts.tsv", "qc": "star_count_qc.tsv",
            }) as combine:
                runner.expression({"S1": "alignment"})
            self.assertEqual(combine.call_args.args[1], "unstranded")

    def test_r_execution_uses_relocatable_core_binary_when_present(self):
        with tempfile.TemporaryDirectory() as temporary:
            runner = object.__new__(PipelineRunner)
            runner.runtime = Path(temporary) / "runtime"
            runner.tool = lambda name: "/runtime/bin/{}".format(name)
            script = Path(temporary) / "run_deseq2.R"
            command, environment = runner.r_script_command(script, ["--counts", "table.tsv"])
            self.assertEqual(command, ["/runtime/bin/Rscript", str(script), "--counts", "table.tsv"])
            self.assertEqual(environment, {})
            core = runner.runtime / "lib/R/bin/exec/R"
            core.parent.mkdir(parents=True)
            core.write_bytes(b"R")
            core.chmod(0o700)
            command, environment = runner.r_script_command(script, ["--counts", "table.tsv"])
            self.assertEqual(command, [str(core), "--vanilla", "--slave", "--file={}".format(script),
                                       "--args", "--counts", "table.tsv"])
            self.assertEqual(environment, {"R_HOME": str(runner.runtime / "lib/R")})

    def test_star_index_size_scales_with_reference(self):
        self.assertEqual(recommended_star_sa_index_nbases(14282666), 10)
        self.assertEqual(recommended_star_sa_index_nbases(3200000000), 14)
        with self.assertRaises(ValueError):
            recommended_star_sa_index_nbases(0)

    def test_node_local_work_rejects_dartfs_and_non_scratch_tmpdir(self):
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            runner = object.__new__(PipelineRunner)
            runner.service_root = base / "RNAseq_atlas"
            runner.service_root.mkdir()
            dartfs_tmp = runner.service_root / "projects" / "Example" / "results" / "tmp"
            dartfs_tmp.mkdir(parents=True)
            runner.tmp_directory = dartfs_tmp
            with patch.dict(os.environ, {"TMPDIR": str(dartfs_tmp)}):
                with self.assertRaisesRegex(PipelineError, "DartFS"):
                    runner.node_local_work_parent()
            node_tmp = base / "node_tmp"
            node_tmp.mkdir()
            with patch.dict(os.environ, {"TMPDIR": str(node_tmp), "USER": "tester"}):
                with self.assertRaisesRegex(PipelineError, "user scratch"):
                    runner.node_local_work_parent()

    def test_retained_star_outputs_exclude_bam_and_unmapped_reads(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            work = root / "work"
            retained = root / "retained"
            work.mkdir()
            for filename in ("Log.final.out", "ReadsPerGene.out.tab", "Aligned.sortedByCoord.out.bam", "Unmapped.out.mate1"):
                (work / filename).write_text(filename, encoding="utf-8")
            copied = retain_star_outputs(work, retained)
            self.assertEqual(copied, ["Log.final.out", "ReadsPerGene.out.tab"])
            self.assertFalse((retained / "Aligned.sortedByCoord.out.bam").exists())
            self.assertFalse((retained / "Unmapped.out.mate1").exists())


if __name__ == "__main__":
    unittest.main()
