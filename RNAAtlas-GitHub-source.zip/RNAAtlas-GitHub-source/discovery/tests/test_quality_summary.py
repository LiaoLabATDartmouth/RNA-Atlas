import json
import tempfile
import unittest
from pathlib import Path

from rnaseq_service.quality_summary import write_quality_summary


class QualitySummaryTests(unittest.TestCase):
    def test_single_end_counts_are_labeled_as_reads(self):
        with tempfile.TemporaryDirectory() as temporary:
            samples = [{"sample_id": "S1", "condition": "control", "read1": "S1.fq.gz", "read2": ""}]
            _, summary = write_quality_summary(temporary, samples,
                                               {"fastq_record_counts": {"S1": 100}}, "rna_snv")
            self.assertEqual(summary["samples"]["S1"]["validated_input_reads"], 100)
            self.assertNotIn("validated_input_pairs", summary["samples"]["S1"])

    def test_de_correlation_uses_normalized_counts_without_exclusion(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            expression = root / "20_expression"
            expression.mkdir()
            (expression / "pca.pdf").write_bytes(b"%PDF")
            (expression / "normalized_gene_counts.tsv").write_text(
                "gene_id\tS1\tS2\tS3\n"
                "g1\t1\t1\t100\n"
                "g2\t10\t10\t10\n"
                "g3\t100\t100\t1\n", encoding="utf-8",
            )
            samples = [{"sample_id": sample_id, "condition": "control"}
                       for sample_id in ("S1", "S2", "S3")]
            _, summary = write_quality_summary(root, samples, {}, "differential_expression")
            correlations = summary["checks"]["median_log_count_correlation_per_sample"]
            self.assertAlmostEqual(correlations["S1"], 0.0, delta=0.02)
            self.assertAlmostEqual(correlations["S2"], 0.0, delta=0.02)
            self.assertLess(correlations["S3"], -0.95)
            self.assertTrue(summary["checks"]["pca_available"])
            self.assertEqual(summary["automatic_sample_exclusions"], 0)

    def test_per_sample_metrics_and_warnings_do_not_exclude_samples(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            star = root / "10_alignment" / "S1"
            star.mkdir(parents=True)
            (star / "Log.final.out").write_text(
                "Number of input reads | 1,000\nUniquely mapped reads % | 44.00%\n", encoding="utf-8",
            )
            fastp = root / "00_qc" / "fastp"
            fastp.mkdir(parents=True)
            (fastp / "S1.fastp.json").write_text(json.dumps({"summary": {
                "before_filtering": {"total_reads": 2000},
                "after_filtering": {"total_reads": 1200},
            }}), encoding="utf-8")
            path, summary = write_quality_summary(root, [
                {"sample_id": "S1", "condition": "control"},
                {"sample_id": "S2", "condition": "treated"},
            ], {"fastq_record_counts": {"S1": 1000, "S2": 1000}}, "differential_expression")
            self.assertEqual(summary["samples"]["S1"]["fastp_retained_percent"], 60.0)
            self.assertEqual(summary["samples"]["S1"]["unique_mapping_percent"], 44.0)
            self.assertEqual(summary["automatic_sample_exclusions"], 0)
            self.assertEqual(summary["checks"]["samples_per_condition"], {"control": 1, "treated": 1})
            self.assertTrue(any("fewer than 70%" in warning for warning in summary["warnings"]))
            self.assertEqual(json.loads(Path(path).read_text(encoding="utf-8")), summary)

    def test_module_specific_zero_cases_are_reported(self):
        samples = [{"sample_id": "S1", "condition": "control"}]
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            for module, metric in (("rna_snv", "pass_allele_rows_per_sample"),
                                   ("ase", "recounted_sites_per_sample")):
                _, summary = write_quality_summary(root, samples, {}, module)
                self.assertEqual(summary["checks"][metric], {"S1": 0})
            _, trinity = write_quality_summary(root, samples, {}, "trinity")
            self.assertFalse(trinity["checks"]["busco_completeness_assessed"])
            self.assertFalse(trinity["checks"]["read_representation_assessed"])
            assembly = root / "25_denovo_transcriptome"
            assembly.mkdir()
            (assembly / "read_representation.tsv").write_text(
                "sample_id\tinput_read_pairs\toverall_alignment_percent\nS1\t100\t76.5\n", encoding="utf-8",
            )
            _, represented = write_quality_summary(root, samples, {}, "trinity")
            self.assertTrue(represented["checks"]["read_representation_assessed"])
            self.assertTrue(any("fewer than 80%" in warning for warning in represented["warnings"]))


if __name__ == "__main__":
    unittest.main()
