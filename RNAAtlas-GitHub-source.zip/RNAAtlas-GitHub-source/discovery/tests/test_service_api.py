import gzip
import json
import os
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

from scripts import service_api
from rnaseq_service.project import create_project, load_project_config, save_project_config, validate_project
from rnaseq_service.registry import approve_user, create_job_record, register_user


class ServiceApiOwnershipTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name) / "rnaseq"
        (self.root / "projects").mkdir(parents=True)
        (self.root / "shared" / "service_registry").mkdir(parents=True)
        self.admin = register_user(
            "admin@dartmouth.edu", "Admin", root=self.root, admin_emails={"admin@dartmouth.edu"},
        )
        self.owner = register_user("owner@dartmouth.edu", "Owner", root=self.root)
        self.other = register_user("other@dartmouth.edu", "Other", root=self.root)
        approve_user(self.owner["user_id"], self.admin["email"], root=self.root)
        approve_user(self.other["user_id"], self.admin["email"], root=self.root)
        create_project("Owned", root=self.root, owner_email=self.owner["email"])
        create_project("Legacy", root=self.root)
        self.root_patch = patch.object(service_api, "service_root", return_value=self.root)
        self.root_patch.start()

    def tearDown(self):
        self.root_patch.stop()
        self.temporary.cleanup()

    def test_snapshot_filters_projects_and_legacy_is_admin_only(self):
        owner_projects = [item["name"] for item in service_api.snapshot(self.owner["email"])["projects"]]
        other_projects = [item["name"] for item in service_api.snapshot(self.other["email"])["projects"]]
        admin_projects = [item["name"] for item in service_api.snapshot(self.admin["email"])["projects"]]
        self.assertEqual(owner_projects, ["Owned"])
        self.assertEqual(other_projects, [])
        self.assertEqual(admin_projects, ["Legacy", "Owned"])

    def test_service_project_requires_prepared_inputs_and_admin(self):
        folder = self.root / "projects" / "Prepared"
        metadata = folder / "meta_data"
        reads = folder / "raw_data" / "S1"
        metadata.mkdir(parents=True)
        reads.mkdir(parents=True)
        (metadata / "sample_sheet.tsv").write_text("sample_id\tcondition\nS1\tcontrol\n", encoding="utf-8")
        for mate in (1, 2):
            with gzip.open(str(reads / "S1_{}.fq.gz".format(mate)), "wt", encoding="ascii") as handle:
                handle.write("@read/{}\nACGT\n+\nIIII\n".format(mate))
        listed = service_api.browse_project_folders(self.admin["email"])["folders"]
        self.assertIn("Prepared", [item["name"] for item in listed])
        self.assertNotIn("Prepared", [item["name"] for item in service_api.browse_project_folders(self.other["email"])["folders"]])
        with self.assertRaisesRegex(ValueError, "administrator"):
            service_api.create_project_for_user({"email": self.other["email"], "name": "Prepared"})
        with self.assertRaisesRegex(ValueError, "unavailable"):
            service_api.create_project_for_user({"email": self.admin["email"], "name": "Missing"})
        created = service_api.create_project_for_user({"email": self.admin["email"], "name": "Prepared"})
        self.assertEqual(created["created_by"], self.admin["email"])
        config = load_project_config("Prepared", root=self.root)
        self.assertEqual(config["owner_email"], self.admin["email"])
        self.assertTrue(config["intake_imported"])
        self.assertTrue((folder / "results" / "trinity").is_dir())
        self.assertTrue((reads / "S1_1.fq.gz").is_file())

    def test_completed_result_download_expires_after_three_days(self):
        output = self.root / "projects" / "Owned" / "results" / "jobs" / "job1"
        output.mkdir(parents=True)
        bundle = output / "results.zip"
        bundle.write_bytes(b"zip")
        status = output / "status.json"
        create_job_record({
            "job_id": "job1", "project_name": "Owned", "submitter_email": self.owner["email"],
            "status_path": str(status), "output_root": str(output), "status": "running",
        }, root=self.root)
        with patch.object(service_api, "allowed_email", side_effect=lambda email: email), patch.object(
            service_api.shutil, "which", return_value=None,
        ):
            for days_ago, available, status_name in ((0, True, "completed"), (4, False, "completed"),
                                                     (0, True, "needs_review")):
                status.write_text(json.dumps({
                    "status": status_name, "updated_at": (datetime.now(timezone.utc) - timedelta(days=days_ago)).isoformat(),
                    "artifacts": {"deliverable": str(bundle)},
                }), encoding="utf-8")
                if available:
                    self.assertEqual(service_api.download_path(self.owner["email"], "job1")["size"], 3)
                else:
                    with self.assertRaisesRegex(ValueError, "three-day download window"):
                        service_api.download_path(self.owner["email"], "job1")
            with self.assertRaisesRegex(ValueError, "not found for this account"):
                service_api.download_path(self.other["email"], "job1")

    def test_direct_service_commands_reject_cross_project_access(self):
        with self.assertRaisesRegex(ValueError, "not found for this account"):
            service_api.project_details(self.other["email"], "Owned")
        with self.assertRaisesRegex(ValueError, "not found for this account"):
            service_api.submit({"email": self.other["email"], "project": "Owned"}, prepare_only=True)
        with self.assertRaisesRegex(ValueError, "not found for this account"):
            service_api.install_ase_genotypes({"email": self.other["email"], "project": "Owned"})
        with self.assertRaisesRegex(ValueError, "not found for this account"):
            service_api.prepare_intake({"email": self.other["email"], "project": "Owned"})
        with self.assertRaisesRegex(ValueError, "Import this project's staged data"):
            service_api.submit({"email": self.owner["email"], "project": "Owned"}, prepare_only=True)

    def test_submit_rejects_resources_above_free_tier(self):
        config = load_project_config("Owned", root=self.root)
        config["intake_imported"] = True
        save_project_config("Owned", config, root=self.root)
        for resources, message in (({"threads": 33}, "CPUs"), ({"memory_gb": 257}, "RAM"),
                                   ({"walltime_hours": 721}, "Run time"),
                                   ({"walltime_hours": 0}, "Run time"),
                                   ({"threads": 2.5}, "CPUs"), ({"memory_gb": True}, "RAM"),
                                   ({"ploidy": 0}, "ploidy"), ({"ploidy": 17}, "ploidy")):
            with self.assertRaisesRegex(ValueError, message):
                service_api.submit({
                    "email": self.owner["email"], "project": "Owned", **resources,
                }, prepare_only=True)

        with patch.object(service_api, "prepare_job", return_value={"job_id": "prepared"}) as prepare:
            service_api.submit({
                "email": self.owner["email"], "project": "Owned", "threads": 24,
                "memory_gb": 192,
                "walltime_hours": 49,
                "ploidy": 1,
            }, prepare_only=True)
        self.assertEqual(prepare.call_args.kwargs["requested_options"]["threads"], 24)
        self.assertEqual(prepare.call_args.kwargs["requested_options"]["memory"], "192G")
        self.assertEqual(prepare.call_args.kwargs["requested_options"]["time_limit"], "2-01:00:00")
        self.assertEqual(prepare.call_args.kwargs["requested_options"]["ploidy"], 1)

    def test_submit_forwards_module_thresholds(self):
        config = load_project_config("Owned", root=self.root)
        config["intake_imported"] = True
        save_project_config("Owned", config, root=self.root)
        requested = {
            "padj_cutoff": 0.01, "log2fc_cutoff": 1.0,
            "variant_min_depth": 15, "variant_min_quality": 25.5,
            "ase_min_depth": 30, "ase_min_allele_count": 0,
            "strandedness": "unstranded",
        }
        with patch.object(service_api, "prepare_job", return_value={"job_id": "prepared"}) as prepare:
            service_api.submit({"email": self.owner["email"], "project": "Owned", **requested}, prepare_only=True)
        options = prepare.call_args.kwargs["requested_options"]
        for key, value in requested.items():
            self.assertEqual(options[key], value)

    def test_intake_preparation_is_private_and_failed_attach_does_not_mutate_project(self):
        prepared = service_api.prepare_intake({"email": self.owner["email"], "project": "Owned"})
        intake = Path(prepared["directory"])
        self.assertEqual(intake.parent.name, self.owner["user_id"])
        self.assertTrue((intake / "meta_data").is_dir())
        self.assertTrue((intake / "raw_data").is_dir())
        self.assertEqual(intake.stat().st_mode & 0o777, 0o700)
        os.chmod(str(intake / "meta_data"), 0o750)
        with self.assertRaisesRegex(ValueError, "Imported project validation failed"):
            service_api.attach_intake({"email": self.owner["email"], "project": "Owned"})
        self.assertFalse(load_project_config("Owned", root=self.root)["intake_imported"])
        self.assertTrue((intake / "meta_data").is_dir())
        self.assertEqual((intake / "meta_data").stat().st_mode & 0o777, 0o750)
        self.assertTrue((self.root / "projects" / "Owned" / "meta_data").is_dir())

    def test_intake_metadata_preview_precedes_fastq_import(self):
        intake = Path(service_api.prepare_intake({"email": self.owner["email"], "project": "Owned"})["directory"])
        (intake / "meta_data" / "sample_sheet.tsv").write_text(
            "sample_id\tcondition\nS1\tcontrol\nS2\ttreated\n", encoding="utf-8",
        )
        preview = service_api.preview_intake(self.owner["email"], "Owned")
        self.assertEqual(preview["sample_count"], 2)
        self.assertEqual(preview["conditions"], ["control", "treated"])
        with self.assertRaisesRegex(ValueError, "not found for this account"):
            service_api.preview_intake(self.other["email"], "Owned")

    def test_symlinked_intake_is_rejected_and_rolled_back(self):
        prepared = service_api.prepare_intake({"email": self.owner["email"], "project": "Owned"})
        intake = Path(prepared["directory"])
        (intake / "meta_data" / "sample_sheet.tsv").write_text("sample_id\tcondition\nS1\tWT\n")
        sample_directory = intake / "raw_data" / "S1"
        sample_directory.mkdir()
        (sample_directory / "S1_1.fq.gz").symlink_to(self.root / "shared" / "service_registry")
        with self.assertRaisesRegex(ValueError, "symbolic links"):
            service_api.attach_intake({"email": self.owner["email"], "project": "Owned"})
        self.assertTrue((sample_directory / "S1_1.fq.gz").is_symlink())
        self.assertEqual(list((self.root / "projects" / "Owned" / "raw_data").iterdir()), [])
        self.assertFalse(load_project_config("Owned", root=self.root)["intake_imported"])

    def test_validated_intake_moves_into_owned_project_once(self):
        prepared = service_api.prepare_intake({"email": self.owner["email"], "project": "Owned"})
        intake = Path(prepared["directory"])
        (intake / "meta_data" / "sample_sheet.tsv").write_text(
            "sample_id\tcondition\nS1\tWT\n", encoding="utf-8",
        )
        sample_directory = intake / "raw_data" / "S1"
        sample_directory.mkdir()
        for mate in (1, 2):
            with gzip.open(str(sample_directory / "S1_{}.fq.gz".format(mate)), "wb") as handle:
                handle.write("@read/{}\nACGT\n+\nIIII\n".format(mate).encode("ascii"))
        save_project_config("Owned", {"reference_id": "test_reference"}, root=self.root)
        fasta = self.root / "reference.fa"
        fasta.write_text(">chr1\nACGT\n", encoding="ascii")
        reference = {
            "fasta": str(fasta), "annotation": "", "label": "Test", "recommended_ploidy": 2,
            "has_annotation": False, "star_index": str(self.root), "genome_bases": 4,
            "star_sa_index_nbases": 1, "star_sjdb_overhang": 1,
        }
        with patch("rnaseq_service.project.load_reference", return_value=reference):
            result = service_api.attach_intake({"email": self.owner["email"], "project": "Owned"})
            validation = validate_project("Owned", root=self.root)
        self.assertEqual(result["sample_count"], 1)
        self.assertEqual(validation["errors"], [])
        self.assertTrue(load_project_config("Owned", root=self.root)["intake_imported"])
        self.assertFalse((sample_directory / "S1_1.fq.gz").exists())
        self.assertTrue((self.root / "projects" / "Owned" / "raw_data" / "S1" / "S1_1.fq.gz").is_file())
        with self.assertRaisesRegex(ValueError, "already has imported inputs"):
            service_api.attach_intake({"email": self.owner["email"], "project": "Owned"})


if __name__ == "__main__":
    unittest.main()
