suppressPackageStartupMessages(library("DESeq2"))
suppressPackageStartupMessages(library("ggplot2"))
suppressPackageStartupMessages(library("ggrepel"))

parse_args <- function(values) {
  result <- list()
  index <- 1
  while (index <= length(values)) {
    key <- sub("^--", "", values[[index]])
    if (index == length(values)) stop(paste("Missing value for", values[[index]]))
    result[[key]] <- values[[index + 1]]
    index <- index + 2
  }
  result
}

args <- parse_args(commandArgs(trailingOnly = TRUE))
required <- c("counts", "samples", "output", "reference", "log2fc", "padj")
missing <- required[!required %in% names(args)]
if (length(missing) > 0) stop(paste("Missing arguments:", paste(missing, collapse = ", ")))

dir.create(args$output, recursive = TRUE, showWarnings = FALSE)
counts <- read.delim(args$counts, header = TRUE, row.names = 1, check.names = FALSE)
samples <- read.delim(args$samples, header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
if (anyDuplicated(samples$sample_id)) stop("Duplicate sample IDs in metadata")
if (!all(samples$sample_id %in% colnames(counts))) stop("Sample metadata does not match count-matrix columns")
samples <- samples[match(colnames(counts), samples$sample_id), , drop = FALSE]
conditions <- factor(samples$condition)
if (!args$reference %in% levels(conditions)) stop("Reference condition is absent from metadata")
conditions <- relevel(conditions, ref = args$reference)

col_data <- data.frame(row.names = samples$sample_id, condition = conditions)
dds <- DESeqDataSetFromMatrix(countData = round(as.matrix(counts)), colData = col_data, design = ~ condition)
dds <- dds[rowSums(counts(dds)) >= 10, ]
dds <- DESeq(dds)
normalized <- counts(dds, normalized = TRUE)
write.table(
  data.frame(gene_id = rownames(normalized), normalized, check.names = FALSE),
  file = file.path(args$output, "normalized_gene_counts.tsv"), sep = "\t", quote = FALSE, row.names = FALSE
)

if (nrow(dds) > 1 && ncol(dds) > 2) {
  transformed <- varianceStabilizingTransformation(dds, blind = TRUE)
  pca_data <- plotPCA(transformed, intgroup = "condition", returnData = TRUE)
  percent_variance <- round(100 * attr(pca_data, "percentVar"))
  pca_plot <- ggplot(pca_data, aes(x = PC1, y = PC2, color = condition, label = name)) +
    geom_point(size = 3) +
    geom_text_repel(color = "#172033", size = 3, max.overlaps = Inf) +
    labs(
      title = "PCA by condition",
      x = paste0("PC1: ", percent_variance[[1]], "% variance"),
      y = paste0("PC2: ", percent_variance[[2]], "% variance")
    ) +
    theme_minimal(base_size = 12) + theme(legend.position = "bottom")
  ggsave(file.path(args$output, "pca.pdf"), pca_plot, width = 8, height = 7)
}

log2fc_cutoff <- as.numeric(args$log2fc)
padj_cutoff <- as.numeric(args$padj)
comparison_root <- file.path(args$output, "differential_expression")
dir.create(comparison_root, recursive = TRUE, showWarnings = FALSE)

for (condition_name in setdiff(levels(conditions), args$reference)) {
  result <- as.data.frame(results(dds, contrast = c("condition", condition_name, args$reference)))
  result$gene_id <- rownames(result)
  result <- result[order(result$log2FoldChange, decreasing = TRUE, na.last = TRUE), ]
  result$significant <- !is.na(result$padj) & result$padj < padj_cutoff & abs(result$log2FoldChange) >= log2fc_cutoff
  comparison <- paste0(condition_name, "_vs_", args$reference)
  comparison_directory <- file.path(comparison_root, comparison)
  dir.create(comparison_directory, recursive = TRUE, showWarnings = FALSE)
  write.table(
    result[, c("gene_id", "baseMean", "log2FoldChange", "lfcSE", "stat", "pvalue", "padj", "significant")],
    file = file.path(comparison_directory, "differential_expression.tsv"),
    sep = "\t", quote = FALSE, row.names = FALSE
  )

  plotted <- result[is.finite(result$log2FoldChange) & !is.na(result$padj), ]
  plotted$plot_padj <- pmax(plotted$padj, 1e-300)
  significant <- plotted[plotted$significant, ]
  top_up <- head(significant[order(significant$padj, -significant$log2FoldChange), ], 10)
  top_down <- head(significant[order(significant$padj, significant$log2FoldChange), ], 10)
  labels <- unique(rbind(top_up, top_down))
  volcano <- ggplot(plotted, aes(x = log2FoldChange, y = -log10(plot_padj), color = significant)) +
    geom_point(alpha = 0.75, size = 1.7) +
    geom_vline(xintercept = c(-log2fc_cutoff, log2fc_cutoff), linetype = "dashed", color = "#8a94a6") +
    geom_hline(yintercept = -log10(padj_cutoff), linetype = "dashed", color = "#8a94a6") +
    geom_text_repel(data = labels, aes(label = gene_id), color = "#172033", size = 3, max.overlaps = Inf) +
    scale_color_manual(values = c(`FALSE` = "#8a94a6", `TRUE` = "#d8573c")) +
    labs(title = comparison, x = "log2 fold change", y = "-log10 adjusted p-value", color = "Significant") +
    theme_minimal(base_size = 12) + theme(legend.position = "bottom")
  ggsave(file.path(comparison_directory, "volcano.pdf"), volcano, width = 8, height = 7)
}

writeLines(capture.output(sessionInfo()), file.path(args$output, "R_session_info.txt"))
