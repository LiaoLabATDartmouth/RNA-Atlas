#!/usr/bin/env python3
"""Send an idempotent job-completion email."""

import argparse
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))

from rnaseq_service.email_delivery import notify_job  # noqa: E402
from rnaseq_service.env_config import load_env_file  # noqa: E402


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--job-config", required=True)
    parser.add_argument("--exit-code", default=0, type=int)
    parser.add_argument("--env-file", default=str(ROOT / "shared" / "service_registry" / "service_production.env"))
    args = parser.parse_args(argv)
    load_env_file(args.env_file)
    result = notify_job(args.job_config, exit_code=args.exit_code)
    print(result)
    return 0 if result.get("status") in {"sent", "not_sent"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
