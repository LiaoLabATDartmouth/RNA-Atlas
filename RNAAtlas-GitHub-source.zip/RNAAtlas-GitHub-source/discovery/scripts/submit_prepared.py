#!/usr/bin/env python3
"""Submit a prepared personal RNA Atlas job from a member's Discovery login."""

import argparse
import os
import pwd
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
NETID = pwd.getpwuid(os.geteuid()).pw_name.lower()
os.environ.update({
    "LIAO_RNASEQ_ROOT": str(ROOT),
    "LIAO_RNASEQ_SHARED_ROOT": "/dartfs/rc/lab/L/LiaoC/Service_Account/RNAseq_atlas",
    "LIAO_RNASEQ_PERSONAL_MODE": "1",
    "LIAO_RNASEQ_MEMBER_NETID": NETID,
})

import service_api


def main(argv=None):
    parser = argparse.ArgumentParser(description="Submit one prepared RNA Atlas job under your Discovery account.")
    parser.add_argument("job_id")
    args = parser.parse_args(argv)
    if subprocess.run(["klist", "-s"], check=False).returncode != 0:
        parser.exit(2, "No valid Kerberos ticket on Discovery. Authenticate there before submitting.\n")
    try:
        service_api.validate_personal_environment()
        job = service_api.submit_prepared_job(NETID + "@dartmouth.edu", args.job_id)
    except (OSError, ValueError) as error:
        parser.exit(2, "RNA Atlas did not submit the job: {}\n".format(error))
    if job.get("status") != "submitted" or not job.get("slurm_job_id"):
        parser.exit(2, "Slurm did not accept the job: {}\n".format(job.get("message", "unknown error")))
    print("Submitted Slurm job {} for RNA Atlas job {}".format(job["slurm_job_id"], job["job_id"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
