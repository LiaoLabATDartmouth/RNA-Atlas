#!/usr/bin/env python3
"""Run one prepared RNA-seq job on a Slurm compute node."""

import argparse
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))

from rnaseq_service.pipeline import run_pipeline  # noqa: E402


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--job-config", required=True)
    args = parser.parse_args(argv)
    return run_pipeline(args.job_config)


if __name__ == "__main__":
    raise SystemExit(main())

