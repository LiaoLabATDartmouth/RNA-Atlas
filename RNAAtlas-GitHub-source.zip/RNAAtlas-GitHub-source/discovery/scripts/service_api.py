#!/usr/bin/env python3
"""Guarded JSON interface used by the Mac-hosted RNA-seq portal."""

import argparse
import fcntl
import hashlib
import json
import os
import pwd
import shutil
import stat
import subprocess
import sys
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from pathlib import PurePosixPath


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))

from rnaseq_service.paths import enforce_rnaseq_boundary, intake_project_root, project_root, projects_root, references_root, service_root, shared_assets_root, validate_project_name  # noqa: E402
from rnaseq_service.env_config import load_env_file  # noqa: E402
from rnaseq_service.fastq_validation import FastqFormatError, profile_fastq_samples  # noqa: E402
from rnaseq_service.preprocessing import normalize_preprocessing_options  # noqa: E402
from rnaseq_service.project import (  # noqa: E402
    create_project, list_projects, load_project_config, read_samples, save_project_config, validate_project,
)
from rnaseq_service.reference_staging import create_reference_input, inspect_reference_input, list_reference_inputs  # noqa: E402
from rnaseq_service.references import list_references  # noqa: E402
from rnaseq_service.registry import (  # noqa: E402
    approve_user,
    download_expiry,
    get_job,
    get_user,
    list_jobs,
    list_users,
    parse_timestamp,
    register_user,
)
from rnaseq_service.slurm import prepare_job, submit_job  # noqa: E402
from rnaseq_service.utils import normalize_email, stable_identifier  # noqa: E402


load_env_file(service_root() / "shared" / "service_registry" / "service_production.env")


def validate_personal_environment():
    if os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") != "1":
        return
    netid = pwd.getpwuid(os.geteuid()).pw_name.lower()
    if os.environ.get("LIAO_RNASEQ_MEMBER_NETID", "").lower() != netid:
        raise ValueError("The Discovery account does not match the personal launcher.")
    root = service_root().resolve(strict=True)
    lab_root = PurePosixPath("/dartfs/rc/lab/L/LiaoC")
    service_tree = PurePosixPath("/dartfs/rc/lab/L/LiaoC/Service_Account")
    if (lab_root not in PurePosixPath(root).parents or service_tree in PurePosixPath(root).parents
            or root.stat().st_uid != os.geteuid()):
        raise ValueError("Personal workspace must be owned by the signed-in member outside Service_Account.")
    shared_assets_root(root)


def write_json(payload):
    print(json.dumps(payload, indent=2, sort_keys=True))


def allowed_email(value):
    email = normalize_email(
        value,
        allowed_domain=os.environ.get("LIAO_RNASEQ_ALLOWED_EMAIL_DOMAIN", "dartmouth.edu"),
        allow_external=os.environ.get("LIAO_RNASEQ_ALLOW_EXTERNAL_EMAIL", "0") == "1",
    )
    if os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") == "1":
        if email != pwd.getpwuid(os.geteuid()).pw_name.lower() + "@dartmouth.edu":
            raise ValueError("Personal mode must use the signed-in Discovery account.")
    return email


def admin_emails():
    return {
        value.strip().lower()
        for value in os.environ.get("LIAO_RNASEQ_ADMIN_EMAILS", "").split(",")
        if value.strip()
    }


def approved_user(email):
    user = get_user(allowed_email(email), root=service_root())
    if not user:
        raise ValueError("Register this Dartmouth email before using the service.")
    if user.get("status") != "approved":
        raise ValueError("This account is registered but still awaiting administrator approval.")
    return user


def approved_admin(email):
    user = approved_user(email)
    if not user.get("is_admin"):
        raise ValueError("Administrator access is required.")
    return user


def owned_project(email, name, root=None):
    root_path = root or service_root()
    user = approved_user(email)
    config = load_project_config(name, root=root_path)
    if not project_root(name, root=root_path).is_dir():
        raise ValueError("Project not found for this account.")
    if not user.get("is_admin") and config.get("owner_email", "") != user["email"]:
        raise ValueError("Project not found for this account.")
    return user, config


@contextmanager
def project_input_lock(name, root):
    lock_path = project_root(name, root=root) / ".intake.lock"
    with lock_path.open("a") as handle:
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (BlockingIOError, OSError):
            raise ValueError("Project inputs are being changed or submitted; retry shortly.")
        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def reference_payload(reference):
    return {
        key: reference.get(key)
        for key in (
            "id", "label", "organism", "assembly", "recommended_ploidy", "genome_bases",
            "star_sa_index_nbases", "star_sjdb_overhang", "star_version", "has_annotation",
            "capabilities", "ready", "errors",
        )
    }


def validation_payload(validation):
    config = validation.get("config", {})
    public_config_keys = (
        "organism", "description", "reference_id", "strandedness", "ploidy", "threads", "memory",
        "time_limit", "reference_condition", "run_differential_expression", "run_rna_variants",
        "run_ase", "ase_source", "run_trinity", "trinity_min_contig_length", "trinity_normalize_reads",
        "run_unmapped_rna", "run_unmapped_trinity", "unmapped_rna_mode", "unmapped_rna_min_pairs",
        "unmapped_rna_min_contig_length",
        "unmapped_rna_host_min_identity", "unmapped_rna_host_min_query_coverage", "unmapped_rna_blast_evalue",
        "candidate_cross_min_identity", "candidate_cross_min_shorter_coverage", "verify_md5", "validate_fastq_structure",
        "trimming_mode", "library_type", "library_prep", "adapter_handling", "adapter_read1", "adapter_read2",
        "trim_quality_tails", "trim_quality_threshold", "trim_minimum_length", "trim_front_read1",
        "trim_front_read2", "trim_tail_read1", "trim_tail_read2", "umi_status", "selection_method",
        "prior_processing",
    )
    return {
        "project": validation.get("project"),
        "metadata_file": validation.get("metadata_file", ""),
        "results_root": str(Path(validation["project_root"]) / "results") if validation.get("project_root") else "",
        "ready": not validation.get("errors"),
        "errors": validation.get("errors", []),
        "warnings": validation.get("warnings", []),
        "conditions": validation.get("conditions", []),
        "sample_count": len(validation.get("samples", [])),
        "valid_sample_count": sum(not check.get("issues") for check in validation.get("input_checks", [])),
        "input_checks": validation.get("input_checks", []),
        "samples": [
            {
                "sample_id": sample["sample_id"],
                "condition": sample["condition"],
                "read1": Path(sample["read1"]).name,
                "read2": Path(sample["read2"]).name,
            }
            for sample in validation.get("samples", [])
        ],
        "fastq_bytes": validation.get("fastq_bytes", 0),
        "fastq_size": validation.get("fastq_size", "0 B"),
        "reference_id": validation.get("reference_id", ""),
        "reference_label": validation.get("reference_label", ""),
        "reference_genome_bases": validation.get("reference_genome_bases", 0),
        "reference_star_sjdb_overhang": validation.get("reference_star_sjdb_overhang", 0),
        "reference_has_annotation": validation.get("reference_has_annotation", False),
        "ase_genotypes": validation.get("ase_genotypes", {}),
        "fastq_profile": validation.get("fastq_profile", {}),
        "config": {key: config.get(key) for key in public_config_keys},
    }


def storage_payload(root):
    usage = shutil.disk_usage(root)
    return {
        "total_bytes": usage.total,
        "used_bytes": usage.used,
        "free_bytes": usage.free,
        "percent_used": round(100.0 * usage.used / max(1, usage.total), 1),
    }


def mounted_job_status(job, root):
    record = dict(job)
    status_path = str(record.get("status_path", ""))
    remote_prefix = "/dartfs/rc/lab/L/LiaoC/Service_Account/RNAseq_atlas"
    if status_path.startswith(remote_prefix + "/"):
        status_path = str(root) + status_path[len(remote_prefix):]
    status_file = Path(status_path)
    if status_file.is_file():
        try:
            status = json.loads(status_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            status = {}
        if status:
            record.update(
                {
                    "status": status.get("status", record.get("status")),
                    "stage": status.get("stage", record.get("stage", "")),
                    "message": status.get("message", record.get("message", "")),
                    "progress": status.get("progress", record.get("progress")),
                    "artifacts": status.get("artifacts", record.get("artifacts", {})),
                    "updated_at": status.get("updated_at", record.get("updated_at", "")),
                }
            )
            if status.get("status") == "completed":
                record["download_expires_at"] = download_expiry(status.get("updated_at"))
    if record.get("status") in {"submitted", "queued", "running"}:
        output_root = str(record.get("output_root", ""))
        if output_root.startswith(remote_prefix + "/"):
            output_root = str(root) + output_root[len(remote_prefix):]
        log_directory = Path(output_root) / "90_logs"
        for error_log in sorted(log_directory.glob("slurm_*.err"), reverse=True):
            try:
                log_tail = error_log.read_text(encoding="utf-8", errors="replace")[-65536:].lower()
            except OSError:
                continue
            terminal_status = ""
            if "cancelled" in log_tail:
                terminal_status = "cancelled"
            elif any(marker in log_tail for marker in ("out_of_memory", "oom-kill", "time limit", "node failure")):
                terminal_status = "failed"
            if terminal_status:
                record.update(
                    {
                        "status": terminal_status,
                        "stage": terminal_status,
                        "slurm_state": terminal_status,
                        "message": "Slurm terminated this job; review the scheduler error log.",
                    }
                )
                break
    return record


def snapshot(email):
    root = service_root().resolve(strict=True)
    user = get_user(allowed_email(email), root=root)
    include_jobs = bool(user and user.get("status") == "approved")
    jobs = list_jobs(
        root=root,
        user_email=user["email"] if include_jobs else "",
        include_all=bool(include_jobs and user.get("is_admin")),
        refresh=bool(shutil.which("squeue")),
    ) if include_jobs else []
    if include_jobs and not shutil.which("squeue"):
        jobs = [mounted_job_status(job, root) for job in jobs]
    assets = shared_assets_root(root)
    return {
        "service_root": str(root),
        "user": user,
        "projects": list_projects(
            root=root, owner_email=None if user.get("is_admin") else user["email"],
        ) if include_jobs else [],
        "references": [
            reference_payload(reference) for reference in list_references(root=root, ready_only=False)
        ] if include_jobs else [],
        "reference_inputs": list_reference_inputs(root=root) if include_jobs and user.get("is_admin") else [],
        "jobs": jobs,
        "storage": storage_payload(root),
        "trinity_ready": all(
            os.access(assets / "shared" / "trinity_runtime_v2" / "bin" / name, os.X_OK)
            for name in ("Trinity", "jellyfish", "bowtie2", "bowtie2-build", "salmon")
        ),
        "qc_ready": all(
            (assets / "shared" / "qc_runtime" / "bin" / name).is_file()
            for name in ("fastp", "fastqc", "multiqc")
        ),
        "slurm_ready": bool(shutil.which("sbatch")),
    }


def register(email, display_name):
    root = service_root().resolve(strict=True)
    normalized = allowed_email(email)
    return register_user(
        normalized, display_name, root=root, admin_emails=admin_emails(),
        auto_approve=os.environ.get("LIAO_RNASEQ_AUTO_APPROVE_USERS", "0") == "1",
    )


def project_details(email, name, reference_id=""):
    owned_project(email, name)
    selected_reference = reference_id if reference_id else None
    validation = validate_project(
        name, root=service_root(), verify_checksums=False, reference_id=selected_reference,
    )
    if validation.get("samples") and not validation.get("errors"):
        try:
            validation["fastq_profile"] = profile_fastq_samples(validation["samples"], maximum_records=2000)
        except FastqFormatError as error:
            validation["errors"].append("FASTQ profiling failed: {}".format(error))
    return validation_payload(validation)


def create_project_for_user(request):
    user = approved_user(request.get("email", ""))
    personal = os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") == "1"
    name = validate_project_name(request.get("name", ""))
    if not personal and not user.get("is_admin"):
        raise ValueError("Only the single-user administrator can register a prepared service folder. Lab members must use personal mode.")
    root = service_root().resolve(strict=True)
    project_base = projects_root(root)
    if personal and (project_base.is_symlink() or not project_base.is_dir()
                     or project_base.stat().st_uid != os.geteuid()):
        raise ValueError("The personal workspace is not safely owned by this account.")
    source = project_root(name, root=root)
    if source.is_symlink() or not source.is_dir() or (personal and source.stat().st_uid != os.geteuid()):
        raise ValueError("The selected project folder is unavailable or not owned by this account.")
    data_source = source / "datasets" if personal else source
    _audit_imported_inputs(data_source, require_owner=personal)
    preview = preview_sample_sheet(data_source, name, require_owner=personal)
    if preview["errors"]:
        raise ValueError("Fix prepared project data before loading: {}".format("; ".join(preview["errors"])))
    _audit_imported_inputs(data_source, validation={
        "metadata_file": preview["metadata_file"],
        "samples": [
            {
                "sample_id": check["sample_id"],
                "read1": str(data_source / "raw_data" / check["sample_id"] / check["read1"]),
                "read2": str(data_source / "raw_data" / check["sample_id"] / check["read2"]),
            }
            for check in preview["input_checks"]
        ],
    }, require_owner=personal)
    destination = create_project(
        name, request.get("organism", ""), request.get("description", ""),
        reference_id=request.get("reference_id", ""), root=root, owner_email=user["email"],
        prepared_existing=True, input_subdirectory="datasets" if personal else "",
    )
    return {
        "name": destination.name,
        "path": str(destination),
        "created_by": user["email"],
        "message": "Prepared project folder checked and registered.",
    }


def browse_project_folders(email):
    user = approved_user(email)
    root = service_root().resolve(strict=True)
    folders = []
    registered = {item["name"] for item in list_projects(root=root, owner_email=None if user.get("is_admin") else user["email"])}
    for name in sorted(registered):
        candidate = project_root(name, root=root)
        if candidate.is_dir() and not candidate.is_symlink():
            folders.append({"name": name, "path": str(candidate), "kind": "project"})
    if os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") == "1" or user.get("is_admin"):
        base = projects_root(root)
        if base.is_dir() and not base.is_symlink():
            for candidate in sorted(base.iterdir(), key=lambda item: item.name.lower()):
                if candidate.name in registered or candidate.is_symlink() or not candidate.is_dir():
                    continue
                if os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") == "1" and candidate.stat().st_uid != os.geteuid():
                    continue
                try:
                    project_root(candidate.name, root=root)
                except ValueError:
                    continue
                if (os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") == "1"
                        and not all((candidate / "datasets" / part).is_dir()
                                    for part in ("meta_data", "raw_data"))):
                    continue
                if not (candidate / "project_config.json").exists():
                    folders.append({"name": candidate.name, "path": str(candidate), "kind": "prepared"})
    return {"folders": folders}


def preview_prepared_project(email, name):
    if os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") != "1":
        raise ValueError("Prepared project preview is available only in personal mode.")
    approved_user(email)
    root = service_root().resolve(strict=True)
    project_base = projects_root(root)
    if (project_base.is_symlink() or not project_base.is_dir()
            or project_base.stat().st_uid != os.geteuid()):
        raise ValueError("The personal workspace is not safely owned by this account.")
    source = project_root(name, root=root)
    if (source.is_symlink() or not source.is_dir() or source.stat().st_uid != os.geteuid()
            or (source / "project_config.json").exists()):
        raise ValueError("The selected prepared project is unavailable or not owned by this account.")
    data_source = source / "datasets"
    _audit_imported_inputs(data_source, require_owner=True)
    return preview_sample_sheet(data_source, name)


def prepare_intake(request):
    root = service_root().resolve(strict=True)
    project_name = str(request.get("project", "")).strip()
    user, config = owned_project(request.get("email", ""), project_name, root=root)
    if config.get("owner_email", "") != user["email"]:
        raise ValueError("Only the project owner may prepare its intake folder.")
    intake = intake_project_root(stable_identifier(user["email"]), project_name, root=root)
    for directory in (intake.parent.parent, intake.parent, intake, intake / "meta_data", intake / "raw_data"):
        if directory.is_symlink():
            raise ValueError("Intake folders cannot be symbolic links.")
        directory.mkdir(mode=0o700, exist_ok=True)
        if directory.stat().st_mode & 0o007:
            raise ValueError("Intake folder has access for all users; contact the service administrator.")
    return {
        "project": project_name, "directory": str(intake),
        "message": (
            "Folder prepared. Add sample_sheet.tsv and paired FASTQs using your own DartFS access."
            if os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") == "1" else
            "Folder prepared. An administrator must grant this member a narrow DartFS ACL before deposit; do not grant lab-wide access."
        ),
    }


def list_datasets(email):
    if os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") != "1":
        raise ValueError("Dataset browsing is available only in personal mode.")
    approved_user(email)
    root = service_root().resolve(strict=True)
    base = root / "datasets"
    base.mkdir(mode=0o700, exist_ok=True)
    if base.is_symlink() or base.stat().st_uid != os.geteuid():
        raise ValueError("The personal dataset directory is not safely owned by this account.")
    datasets = []
    for candidate in sorted(base.iterdir(), key=lambda item: item.name.lower()):
        if candidate.is_symlink() or not candidate.is_dir():
            continue
        try:
            validate_project_name(candidate.name)
        except ValueError:
            continue
        if candidate.stat().st_uid == os.geteuid():
            datasets.append({"name": candidate.name, "path": str(candidate)})
    return {"directory": str(base), "datasets": datasets}


def preview_sample_sheet(source, label, require_owner=True):
    metadata = source / "meta_data"
    if (source.is_symlink() or metadata.is_symlink()
            or not source.is_dir() or (require_owner and source.stat().st_uid != os.geteuid())
            or not metadata.is_dir() or (require_owner and metadata.stat().st_uid != os.geteuid())
            or source.stat().st_mode & 0o002 or metadata.stat().st_mode & 0o002):
        raise ValueError("The selected data are unavailable or not safely owned by this account.")
    for candidate in metadata.iterdir():
        if candidate.is_symlink() or (candidate.is_file() and candidate.stat().st_size > 10 * 1024 * 1024):
            raise ValueError("Metadata must be a regular file no larger than 10 MiB.")
    samples, metadata_file = read_samples(source)
    if metadata_file.parent.resolve(strict=True) != metadata.resolve(strict=True):
        raise ValueError("Metadata file must be inside the selected data folder.")
    raw_data = source / "raw_data"
    checks = []
    errors = []
    seen = set()
    if not samples:
        errors.append("Sample sheet has no sample rows.")
    for sample in samples:
        sample_id = sample["sample_id"]
        try:
            validate_project_name(sample_id)
        except ValueError:
            errors.append("Invalid sample ID in sample sheet: {}.".format(sample_id))
            continue
        if sample_id in seen:
            errors.append("Duplicate sample ID in sample sheet: {}.".format(sample_id))
            continue
        seen.add(sample_id)
        directory = raw_data / sample_id
        read1 = None
        read2 = None
        for suffix in ("fq.gz", "fastq.gz"):
            candidate1 = directory / "{}_1.{}".format(sample_id, suffix)
            candidate2 = directory / "{}_2.{}".format(sample_id, suffix)
            if read1 is None and candidate1.is_file() and not candidate1.is_symlink():
                read1 = candidate1
            if read2 is None and candidate2.is_file() and not candidate2.is_symlink():
                read2 = candidate2
        issues = []
        if not directory.is_dir() or directory.is_symlink():
            issues.append("raw_data/{} folder is missing or unsafe".format(sample_id))
        else:
            if not read1:
                issues.append("R1 is missing or misnamed")
            if not read2:
                issues.append("R2 is missing or misnamed")
            unexpected = sorted(item.name for item in directory.iterdir()
                                if item.name not in {read1.name if read1 else "", read2.name if read2 else "", "MD5.txt"})
            if unexpected:
                issues.append("Unmatched files: {}".format(", ".join(unexpected)))
        checks.append({
            "sample_id": sample_id, "condition": sample["condition"],
            "read1": read1.name if read1 else "", "read2": read2.name if read2 else "",
            "issues": issues,
        })
        if issues:
            errors.append("Sample {}: {}.".format(sample_id, "; ".join(issues)))
    if not raw_data.is_dir() or raw_data.is_symlink():
        errors.append("raw_data/ folder is missing or unsafe.")
    else:
        unlisted = sorted(item.name for item in raw_data.iterdir() if item.name not in seen)
        if unlisted:
            errors.append("Folders or files in raw_data/ absent from sample sheet: {}.".format(", ".join(unlisted)))
    fastq_profile = {}
    if not errors:
        paired_samples = []
        for check in checks:
            directory = raw_data / check["sample_id"]
            paired_samples.append({
                "sample_id": check["sample_id"],
                "read1": str(directory / check["read1"]),
                "read2": str(directory / check["read2"]),
            })
        try:
            fastq_profile = profile_fastq_samples(paired_samples, maximum_records=2000)
        except FastqFormatError as error:
            errors.append("FASTQ profiling failed: {}".format(error))
    return {
        "dataset": label, "metadata_file": str(metadata_file), "sample_count": len(samples),
        "valid_sample_count": sum(not check["issues"] for check in checks),
        "input_checks": checks, "errors": errors, "fastq_profile": fastq_profile,
        "conditions": sorted({sample["condition"] for sample in samples}),
        "samples": [{"sample_id": sample["sample_id"], "condition": sample["condition"]} for sample in samples[:20]],
        "truncated": len(samples) > 20,
    }


def preview_dataset(email, dataset_name):
    if os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") != "1":
        raise ValueError("Dataset preview is available only in personal mode.")
    approved_user(email)
    root = service_root().resolve(strict=True)
    base = root / "datasets"
    if base.is_symlink() or base.stat().st_uid != os.geteuid():
        raise ValueError("The personal dataset directory is not safely owned by this account.")
    return preview_sample_sheet(base / validate_project_name(dataset_name), dataset_name)


def preview_intake(email, project_name):
    root = service_root().resolve(strict=True)
    user, config = owned_project(email, project_name, root=root)
    if config.get("owner_email") != user["email"]:
        raise ValueError("Only the project owner can preview its intake metadata.")
    intake = intake_project_root(stable_identifier(user["email"]), project_name, root=root)
    return preview_sample_sheet(intake, project_name)


def attach_dataset(request):
    if os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") != "1":
        raise ValueError("Dataset selection is available only in personal mode.")
    root = service_root().resolve(strict=True)
    project_name = str(request.get("project", "")).strip()
    dataset_name = validate_project_name(request.get("dataset", ""))
    user, config = owned_project(request.get("email", ""), project_name, root=root)
    if config.get("owner_email") != user["email"]:
        raise ValueError("Only the project owner can select its dataset.")
    dataset_base = root / "datasets"
    raw_source = dataset_base / dataset_name
    if dataset_base.is_symlink() or raw_source.is_symlink():
        raise ValueError("Dataset folders cannot be symbolic links.")
    source = enforce_rnaseq_boundary(raw_source, root=root)
    if not source.is_dir() or source.stat().st_uid != os.geteuid():
        raise ValueError("The selected dataset is unavailable or not owned by this account.")
    if {item.name for item in source.iterdir()} != {"meta_data", "raw_data"}:
        raise ValueError("A dataset must contain exactly meta_data and raw_data folders.")
    intake = intake_project_root(stable_identifier(user["email"]), project_name, root=root)
    with project_input_lock(project_name, root):
        if intake.exists():
            raise ValueError("This project already has an intake folder. Use its existing Validate and import button.")
        intake.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.rename(source, intake)
        try:
            result = _attach_intake_locked(user, config, project_name, root)
        except Exception:
            os.rename(intake, source)
            raise
        intake.rmdir()
        result["dataset"] = dataset_name
        return result


def attach_intake(request):
    root = service_root().resolve(strict=True)
    project_name = str(request.get("project", "")).strip()
    user, config = owned_project(request.get("email", ""), project_name, root=root)
    with project_input_lock(project_name, root):
        return _attach_intake_locked(user, config, project_name, root)


def _attach_intake_locked(user, config, project_name, root):
    if config.get("owner_email", "") != user["email"]:
        raise ValueError("Only the project owner may attach intake data.")
    if config.get("intake_imported"):
        raise ValueError("This project already has imported inputs; create a new project for a replacement dataset.")
    active = [
        job for job in list_jobs(root=root, refresh=False)
        if job.get("project_name") == project_name and job.get("status") in {"submitted", "queued", "running"}
    ]
    if active:
        raise ValueError("Wait for the active project job to finish before changing its inputs.")
    destination = project_root(project_name, root=root)
    if any(any((destination / subdirectory).iterdir()) for subdirectory in ("meta_data", "raw_data")):
        raise ValueError("Project inputs already exist; create a new project rather than overwrite them.")
    intake = intake_project_root(stable_identifier(user["email"]), project_name, root=root)
    open_flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    try:
        intake_fd = os.open(str(intake), open_flags)
    except OSError:
        raise ValueError("Prepare the private intake folder before importing data.")
    try:
        project_fd = os.open(str(destination), open_flags)
    except OSError:
        os.close(intake_fd)
        raise
    moved = []
    source_modes = {}
    try:
        for name in ("meta_data", "raw_data"):
            try:
                source_stat = os.stat(name, dir_fd=intake_fd, follow_symlinks=False)
            except OSError:
                raise ValueError("Missing or inaccessible intake directory: {}".format(name))
            if not stat.S_ISDIR(source_stat.st_mode) or source_stat.st_uid != os.geteuid():
                raise ValueError("Intake directory must be a service-owned directory: {}".format(name))
            source_modes[name] = stat.S_IMODE(source_stat.st_mode)
        for name in ("meta_data", "raw_data"):
            os.rmdir(name, dir_fd=project_fd)
            os.rename(name, name, src_dir_fd=intake_fd, dst_dir_fd=project_fd)
            moved.append(name)
            secured_fd = os.open(name, open_flags, dir_fd=project_fd)
            try:
                os.fchmod(secured_fd, 0o700)
            finally:
                os.close(secured_fd)
        _audit_imported_inputs(destination)
        imported = validate_project(project_name, root=root, verify_checksums=False)
        if imported["errors"]:
            raise ValueError("Imported project validation failed: {}".format("; ".join(imported["errors"])))
        _audit_imported_inputs(destination, validation=imported)
        try:
            imported["fastq_profile"] = profile_fastq_samples(imported["samples"], maximum_records=2000)
        except FastqFormatError as error:
            raise ValueError("Imported FASTQ profiling failed: {}".format(error))
        save_project_config(project_name, {"intake_imported": True}, root=root)
    except Exception:
        for name in reversed(moved):
            os.rename(name, name, src_dir_fd=project_fd, dst_dir_fd=intake_fd)
            restored_stat = os.stat(name, dir_fd=intake_fd, follow_symlinks=False)
            if stat.S_ISDIR(restored_stat.st_mode) and restored_stat.st_uid == os.geteuid():
                restored_fd = os.open(name, open_flags, dir_fd=intake_fd)
                try:
                    os.fchmod(restored_fd, source_modes[name])
                finally:
                    os.close(restored_fd)
        for name in ("meta_data", "raw_data"):
            try:
                os.mkdir(name, 0o700, dir_fd=project_fd)
            except FileExistsError:
                pass
        raise
    finally:
        os.close(project_fd)
        os.close(intake_fd)
    return validation_payload(imported)


def _audit_imported_inputs(destination, validation=None, require_owner=False):
    if (destination.is_symlink() or not destination.is_dir()
            or (require_owner and destination.stat().st_uid != os.geteuid())):
        raise ValueError("Project input directory is missing, unsafe, or not owned by this account.")
    actual_files = set()
    actual_directories = set()
    for subdirectory in ("meta_data", "raw_data"):
        if (not (destination / subdirectory).is_dir() or (destination / subdirectory).is_symlink()
                or (require_owner and (destination / subdirectory).stat().st_uid != os.geteuid())):
            raise ValueError("Missing or unsafe input directory: {}.".format(subdirectory))
        for item in (destination / subdirectory).rglob("*"):
            if item.is_symlink():
                raise ValueError("Imported inputs cannot contain symbolic links.")
            if require_owner and item.stat().st_uid != os.geteuid():
                raise ValueError("Project inputs must be owned by the signed-in member.")
            relative = str(item.relative_to(destination))
            if item.is_file():
                actual_files.add(relative)
            elif item.is_dir():
                actual_directories.add(relative)
            else:
                raise ValueError("Imported inputs must contain regular files and directories only.")
    if validation is None:
        return
    expected_files = {str(Path(validation["metadata_file"]).relative_to(destination))}
    expected_directories = set()
    for sample in validation["samples"]:
        expected_directories.add("raw_data/{}".format(sample["sample_id"]))
        for key in ("read1", "read2"):
            expected_files.add(str(Path(sample[key]).relative_to(destination)))
        manifest = destination / "raw_data" / sample["sample_id"] / "MD5.txt"
        if manifest.is_file():
            expected_files.add(str(manifest.relative_to(destination)))
    if actual_files != expected_files or actual_directories != expected_directories:
        raise ValueError("Intake contains unlisted files or directories; keep only the sample sheet and listed paired reads.")


def _validated_ase_upload(value, metadata_directory, prefix, suffixes, root):
    if not value:
        return None
    source = enforce_rnaseq_boundary(Path(value), root=root).resolve(strict=True)
    metadata_root = metadata_directory.resolve(strict=True)
    if source.parent != metadata_root or not source.name.startswith(prefix):
        raise ValueError("Refusing an ASE upload outside the selected project's meta_data directory.")
    if not any(source.name.endswith(suffix) for suffix in suffixes):
        raise ValueError("The staged ASE upload has an unsupported filename.")
    if not source.is_file() or source.stat().st_size < 1:
        raise ValueError("The staged ASE upload is empty or unavailable.")
    return source


def install_ase_genotypes(request):
    root = service_root().resolve(strict=True)
    project_name = str(request.get("project", "")).strip()
    owned_project(request.get("email", ""), project_name, root=root)
    projects_directory = projects_root(root).resolve(strict=True)
    project_path = project_root(project_name, root=root).resolve(strict=True)
    if not project_name or project_path.parent != projects_directory or not project_path.is_dir():
        raise ValueError("Invalid project for ASE genotype upload.")
    config = load_project_config(project_name, root=root)
    metadata_directory = (project_path / config.get("input_subdirectory", "") / "meta_data").resolve(strict=True)
    vcf_upload = _validated_ase_upload(
        request.get("vcf_upload_path", ""), metadata_directory,
        ".dna_genotypes.upload.", (".vcf", ".vcf.gz"), root,
    )
    map_upload = _validated_ase_upload(
        request.get("sample_map_upload_path", ""), metadata_directory,
        ".ase_genotype_map.upload.", (".tsv",), root,
    )
    if not vcf_upload:
        raise ValueError("A staged pre-called genotype VCF is required.")
    vcf_destination = metadata_directory / ("dna_genotypes.vcf.gz" if vcf_upload.name.endswith(".vcf.gz") else "dna_genotypes.vcf")
    managed_destinations = [
        metadata_directory / "dna_genotypes.vcf.gz",
        metadata_directory / "dna_genotypes.vcf",
    ]
    map_destination = metadata_directory / "ase_genotype_map.tsv"
    if map_upload:
        managed_destinations.append(map_destination)
    backup_suffix = ".portal-backup-{}".format(os.getpid())
    backups = {}
    installed_destinations = []
    cache_path = metadata_directory / ".dna_genotypes.validation.json"
    try:
        for destination in managed_destinations:
            if destination.is_file():
                backup = destination.with_name(destination.name + backup_suffix)
                if backup.exists():
                    backup.unlink()
                os.replace(str(destination), str(backup))
                backups[destination] = backup
        os.replace(str(vcf_upload), str(vcf_destination))
        installed_destinations.append(vcf_destination)
        if map_upload:
            os.replace(str(map_upload), str(map_destination))
            installed_destinations.append(map_destination)
        if cache_path.exists():
            cache_path.unlink()
        validation = validate_project(
            project_name,
            root=root,
            verify_checksums=False,
            reference_id=str(request.get("reference_id", "")).strip() or None,
        )
        genotype_status = validation.get("ase_genotypes", {})
        if not genotype_status.get("ready"):
            raise ValueError(
                genotype_status.get("error")
                or "The uploaded genotype VCF did not pass ASE validation."
            )
    except Exception:
        for destination in installed_destinations:
            if destination.exists():
                destination.unlink()
        for destination, backup in backups.items():
            if backup.exists():
                os.replace(str(backup), str(destination))
        for upload in (vcf_upload, map_upload):
            if upload and upload.exists():
                upload.unlink()
        if cache_path.exists():
            cache_path.unlink()
        raise
    for backup in backups.values():
        if backup.exists():
            backup.unlink()
    return validation_payload(validation)


def stage_reference_for_admin(request):
    user = approved_admin(request.get("email", ""))
    annotation_mode = str(request.get("annotation_mode", "provided")).strip()
    if annotation_mode not in {"provided", "prokka", "none"}:
        raise ValueError("Annotation mode must be provided, prokka, or none.")
    require_annotation = annotation_mode == "provided"
    record = create_reference_input(
        request.get("reference_id", ""), root=service_root(), require_annotation=require_annotation,
    )
    record.update(
        {
            "created_by": user["email"],
            "annotation_mode": annotation_mode,
            "message": (
                "Reference staging folder is ready. Add one FASTA and its matching GTF/GFF3, then submit the build."
                if require_annotation else
                "FASTA staging folder is ready. Add one FASTA. An optional GTF/GFF3 overrides automatic Prokka or FASTA-only mode."
            ),
        }
    )
    return record


def build_reference_for_admin(request):
    root = service_root().resolve(strict=True)
    user = approved_admin(request.get("email", ""))
    reference_id = str(request.get("reference_id", "")).strip()
    annotation_mode = str(request.get("annotation_mode", "provided")).strip()
    if annotation_mode not in {"provided", "prokka", "none"}:
        raise ValueError("Annotation mode must be provided, prokka, or none.")
    require_annotation = annotation_mode == "provided"
    record = inspect_reference_input(reference_id, root=root, require_annotation=require_annotation)
    if not record["ready"]:
        raise ValueError("Reference inputs are not ready: {}".format("; ".join(record["errors"])))
    if (references_root(root) / reference_id).exists():
        raise ValueError("Reference already exists in the immutable catalog: {}".format(reference_id))
    effective_annotation_mode = "provided" if record.get("annotation") else annotation_mode
    sbatch = shutil.which("sbatch")
    if not sbatch:
        raise ValueError("Slurm submission is unavailable; start the portal with the Discovery backend.")
    label = str(request.get("label", "")).strip()
    organism = str(request.get("organism", "")).strip()
    assembly = str(request.get("assembly", "")).strip()
    if not label or not organism or not assembly:
        raise ValueError("Reference label, organism, and assembly are required.")
    ploidy = int(request.get("recommended_ploidy", 0))
    read_length = int(request.get("max_read_length", 150))
    prokka_kingdom = str(request.get("prokka_kingdom", "Bacteria")).strip()
    if ploidy < 1 or ploidy > 16:
        raise ValueError("Recommended ploidy must be from 1 to 16.")
    if read_length < 25 or read_length > 1000:
        raise ValueError("Maximum read length must be from 25 to 1000 bases.")
    if effective_annotation_mode == "prokka" and prokka_kingdom != "Bacteria":
        raise ValueError("This service restricts Prokka annotation to bacterial genomes.")
    if effective_annotation_mode == "prokka" and not bool(request.get("confirm_bacterial_genome", False)):
        raise ValueError("Confirm that the FASTA is a bacterial genome before running Prokka.")
    script = enforce_rnaseq_boundary(root / "scripts" / "install_reference.slurm", root=root)
    command = [
        sbatch, "--parsable", "--mail-type=END,FAIL", "--mail-user={}".format(user["email"]),
        "--export=ALL,LIAO_SJDB_OVERHANG={},LIAO_ANNOTATION_MODE={},LIAO_PROKKA_KINGDOM={}".format(
            read_length - 1, effective_annotation_mode, prokka_kingdom,
        ), str(script),
        reference_id, label, organism, assembly, record["fasta"], record["annotation"], str(ploidy),
    ]
    completed = subprocess.run(
        command, check=False, universal_newlines=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    if completed.returncode != 0:
        raise ValueError("Reference build submission failed: {}".format(completed.stderr.strip() or completed.stdout.strip()))
    slurm_job_id = completed.stdout.strip().split(";", 1)[0]
    return {
        "reference_id": reference_id,
        "slurm_job_id": slurm_job_id,
        "message": (
            "Expression-ready reference build submitted. It will appear after checksum validation succeeds."
            if effective_annotation_mode == "provided" else (
                "Prokka reference build submitted. The predicted bacterial annotation and its provenance will be retained."
                if effective_annotation_mode == "prokka" else
            "FASTA-only reference build submitted. It will support alignment, variants, ASE, and assembly, but not gene counts or DESeq2."
            )
        ),
    }


def submit(request, prepare_only=False):
    root = service_root().resolve(strict=True)
    user = approved_user(request.get("email", ""))
    project_name = str(request.get("project", "")).strip()
    _, project_config = owned_project(user["email"], project_name, root=root)
    if project_config.get("owner_email") and not project_config.get("intake_imported"):
        raise ValueError("Import this project's staged data before submitting a job.")
    selected_modules = [name for name, enabled in (
        ("differential_expression", request.get("run_differential_expression", True)),
        ("rna_snv", request.get("run_rna_variants", False)),
        ("ase", request.get("run_ase", False)),
        ("trinity", request.get("run_trinity", False)),
    ) if bool(enabled)]
    if len(selected_modules) != 1:
        raise ValueError("Choose exactly one analysis module per job.")
    if selected_modules == ["ase"] and request.get("ase_source", "external_dna_vcf") != "external_dna_vcf":
        raise ValueError("ASE requires a pre-called genotype VCF in genotype_VCF/.")
    threads = request.get("threads", 16)
    memory_gb = request.get("memory_gb", 64)
    walltime_hours = request.get("walltime_hours", 48)
    if type(threads) is not int or not 1 <= threads <= 32:
        raise ValueError("CPUs must be an integer from 1 to 32 for the free-tier app.")
    if type(memory_gb) is not int or not 8 <= memory_gb <= 256:
        raise ValueError("RAM must be an integer from 8 to 256 GB for the free-tier app.")
    if type(walltime_hours) is not int or not 1 <= walltime_hours <= 720:
        raise ValueError("Run time must be an integer from 1 to 720 hours for the standard partition.")
    ploidy = request.get("ploidy", project_config.get("ploidy", 2))
    if type(ploidy) is not int or not 1 <= ploidy <= 16:
        raise ValueError("Sample ploidy must be an integer from 1 to 16.")
    days, hours = divmod(walltime_hours, 24)
    options = {
        "threads": threads,
        "memory": "{}G".format(memory_gb),
        "time_limit": "{}-{:02d}:00:00".format(days, hours) if days else "{}:00:00".format(hours),
        "ploidy": ploidy,
        "reference_id": str(request.get("reference_id", "")).strip(),
        "run_differential_expression": bool(request.get("run_differential_expression", True)),
        "reference_condition": str(request.get("reference_condition", "")).strip(),
        "padj_cutoff": request.get("padj_cutoff", project_config.get("padj_cutoff", 0.05)),
        "log2fc_cutoff": request.get("log2fc_cutoff", project_config.get("log2fc_cutoff", 2.0)),
        "run_rna_variants": bool(request.get("run_rna_variants", False)),
        "variant_min_depth": request.get("variant_min_depth", project_config.get("variant_min_depth", 10)),
        "variant_min_quality": request.get("variant_min_quality", project_config.get("variant_min_quality", 20)),
        "run_ase": bool(request.get("run_ase", False)),
        "ase_min_depth": request.get("ase_min_depth", project_config.get("ase_min_depth", 20)),
        "ase_min_allele_count": request.get("ase_min_allele_count", project_config.get("ase_min_allele_count", 3)),
        "ase_source": "external_dna_vcf",
        "run_trinity": bool(request.get("run_trinity", False)),
        "trinity_min_contig_length": request.get("trinity_min_contig_length", 200),
        "trinity_normalize_reads": bool(request.get("trinity_normalize_reads", True)),
        "run_microbiome": False,
        "run_unmapped_rna": False,
        "run_unmapped_trinity": False,
        "unmapped_rna_mode": str(request.get("unmapped_rna_mode", "rna_virus")),
        "unmapped_rna_min_pairs": request.get("unmapped_rna_min_pairs", 1000),
        "unmapped_rna_min_contig_length": request.get("unmapped_rna_min_contig_length", 200),
        "unmapped_rna_host_min_identity": request.get("unmapped_rna_host_min_identity", 90.0),
        "unmapped_rna_host_min_query_coverage": request.get("unmapped_rna_host_min_query_coverage", 80.0),
        "unmapped_rna_blast_evalue": request.get("unmapped_rna_blast_evalue", 1e-10),
        "candidate_cross_min_identity": request.get("candidate_cross_min_identity", 95.0),
        "candidate_cross_min_shorter_coverage": request.get("candidate_cross_min_shorter_coverage", 80.0),
        "verify_md5": bool(request.get("verify_md5", True)),
        "validate_fastq_structure": bool(request.get("validate_fastq_structure", True)),
    }
    options.update(normalize_preprocessing_options(request))
    with project_input_lock(project_name, root):
        job = prepare_job(project_name, user["email"], requested_options=options, root=root)
        return job if prepare_only else submit_job(job, root=root)


def submit_prepared_job(email, job_id):
    if os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") != "1":
        raise ValueError("Manual submission is available only for personal projects.")
    root = service_root().resolve(strict=True)
    user = approved_user(email)
    job = get_job(job_id, root=root, refresh=False)
    if not job or job.get("submitter_email") != user["email"] or not job.get("personal_mode"):
        raise ValueError("Prepared job not found for this Discovery account.")
    owned_project(user["email"], job["project_name"], root=root)
    output_root = enforce_rnaseq_boundary(Path(job["output_root"]), root=root)
    expected_root = project_root(job["project_name"], root=root) / "results" / job["module"] / job_id
    if output_root != expected_root or output_root.is_symlink() or output_root.stat().st_uid != os.geteuid():
        raise ValueError("Prepared job directory is not owned by this account.")
    for key, expected_name, digest_key in (
        ("slurm_script", "rnaseq.sbatch", "slurm_script_sha256"),
        ("job_config_path", "job_config.json", "job_config_sha256"),
    ):
        candidate = Path(job[key])
        if (candidate != output_root / expected_name or candidate.is_symlink()
                or candidate.stat().st_uid != os.geteuid()
                or hashlib.sha256(candidate.read_bytes()).hexdigest() != job.get(digest_key)):
            raise ValueError("Prepared job file changed; validate and prepare a new job: {}".format(expected_name))
    lock_path = output_root / ".submit.lock"
    with os.fdopen(os.open(lock_path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600), "r+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        current = get_job(job_id, root=root, refresh=False)
        if current.get("status") not in {"prepared", "submission_failed"} or current.get("slurm_job_id"):
            raise ValueError("This job was already submitted; check its status instead of submitting again.")
        if Path(current["status_path"]).exists():
            raise ValueError("This job has already started; check its result status.")
        return submit_job(current, root=root)


def download_path(email, job_id):
    root = service_root().resolve(strict=True)
    user = approved_user(email)
    scheduler_available = bool(shutil.which("squeue"))
    job = get_job(job_id, root=root, refresh=True)
    if job and not scheduler_available:
        job = mounted_job_status(job, root)
    if not job or (not user.get("is_admin") and job.get("submitter_email") != user["email"]):
        raise ValueError("Job not found for this account.")
    if job.get("status") != "completed":
        raise ValueError("Results can be downloaded only after the job completes.")
    expires_at = parse_timestamp(job.get("download_expires_at"))
    if expires_at is None:
        raise ValueError("The result download window is unavailable; results remain on DartFS.")
    if expires_at.tzinfo is None or datetime.now(timezone.utc) >= expires_at:
        raise ValueError("The three-day download window has ended; results remain on DartFS.")
    deliverable_value = str((job.get("artifacts") or {}).get("deliverable", ""))
    remote_prefix = "/dartfs/rc/lab/L/LiaoC/Service_Account/RNAseq_atlas"
    if deliverable_value.startswith(remote_prefix + "/"):
        deliverable_value = str(root) + deliverable_value[len(remote_prefix):]
    deliverable = Path(deliverable_value)
    deliverable = enforce_rnaseq_boundary(deliverable, root=root)
    if not deliverable.is_file():
        raise ValueError("The result bundle is not ready.")
    if deliverable.stat().st_size > 2 * 1024 ** 3:
        raise ValueError("This result bundle is too large for browser download; use the project results folder on DartFS.")
    return {"job_id": job_id, "path": str(deliverable), "filename": deliverable.name, "size": deliverable.stat().st_size}


def main(argv=None):
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command")
    snapshot_parser = subparsers.add_parser("snapshot")
    snapshot_parser.add_argument("--email", required=True)
    register_parser = subparsers.add_parser("register")
    register_parser.add_argument("--email", required=True)
    register_parser.add_argument("--display-name", default="")
    project_parser = subparsers.add_parser("project")
    project_parser.add_argument("--email", required=True)
    project_parser.add_argument("--name", required=True)
    project_parser.add_argument("--reference-id", default="")
    create_project_parser = subparsers.add_parser("create-project")
    create_project_parser.add_argument("--request-json", required=True)
    prepare_intake_parser = subparsers.add_parser("prepare-intake")
    prepare_intake_parser.add_argument("--request-json", required=True)
    attach_intake_parser = subparsers.add_parser("attach-intake")
    attach_intake_parser.add_argument("--request-json", required=True)
    stage_reference_parser = subparsers.add_parser("stage-reference")
    stage_reference_parser.add_argument("--request-json", required=True)
    install_ase_parser = subparsers.add_parser("install-ase-genotypes")
    install_ase_parser.add_argument("--request-json", required=True)
    build_reference_parser = subparsers.add_parser("build-reference")
    build_reference_parser.add_argument("--request-json", required=True)
    submit_parser = subparsers.add_parser("submit")
    submit_parser.add_argument("--request-json", required=True)
    submit_parser.add_argument("--prepare-only", action="store_true")
    job_parser = subparsers.add_parser("job")
    job_parser.add_argument("--email", required=True)
    job_parser.add_argument("--job-id", required=True)
    download_parser = subparsers.add_parser("download")
    download_parser.add_argument("--email", required=True)
    download_parser.add_argument("--job-id", required=True)
    users_parser = subparsers.add_parser("users")
    users_parser.add_argument("--admin-email", required=True)
    approve_parser = subparsers.add_parser("approve")
    approve_parser.add_argument("--admin-email", required=True)
    approve_parser.add_argument("--user-id", required=True)
    datasets_parser = subparsers.add_parser("datasets")
    datasets_parser.add_argument("--email", required=True)
    folders_parser = subparsers.add_parser("project-folders")
    folders_parser.add_argument("--email", required=True)
    prepared_preview_parser = subparsers.add_parser("prepared-project-preview")
    prepared_preview_parser.add_argument("--email", required=True)
    prepared_preview_parser.add_argument("--name", required=True)
    dataset_preview_parser = subparsers.add_parser("dataset-preview")
    dataset_preview_parser.add_argument("--email", required=True)
    dataset_preview_parser.add_argument("--dataset", required=True)
    intake_preview_parser = subparsers.add_parser("intake-preview")
    intake_preview_parser.add_argument("--email", required=True)
    intake_preview_parser.add_argument("--project", required=True)
    attach_dataset_parser = subparsers.add_parser("attach-dataset")
    attach_dataset_parser.add_argument("--request-json", required=True)
    args = parser.parse_args(argv)
    if not args.command:
        parser.error("a command is required")
    try:
        validate_personal_environment()
        if args.command == "snapshot":
            payload = snapshot(args.email)
        elif args.command == "register":
            payload = register(args.email, args.display_name)
        elif args.command == "datasets":
            payload = list_datasets(args.email)
        elif args.command == "project-folders":
            payload = browse_project_folders(args.email)
        elif args.command == "prepared-project-preview":
            payload = preview_prepared_project(args.email, args.name)
        elif args.command == "dataset-preview":
            payload = preview_dataset(args.email, args.dataset)
        elif args.command == "intake-preview":
            payload = preview_intake(args.email, args.project)
        elif args.command == "attach-dataset":
            payload = attach_dataset(json.loads(args.request_json))
        elif args.command == "project":
            payload = project_details(args.email, args.name, args.reference_id)
        elif args.command == "create-project":
            payload = create_project_for_user(json.loads(args.request_json))
        elif args.command == "prepare-intake":
            payload = prepare_intake(json.loads(args.request_json))
        elif args.command == "attach-intake":
            payload = attach_intake(json.loads(args.request_json))
        elif args.command == "stage-reference":
            payload = stage_reference_for_admin(json.loads(args.request_json))
        elif args.command == "install-ase-genotypes":
            payload = install_ase_genotypes(json.loads(args.request_json))
        elif args.command == "build-reference":
            payload = build_reference_for_admin(json.loads(args.request_json))
        elif args.command == "submit":
            payload = submit(json.loads(args.request_json), prepare_only=args.prepare_only)
        elif args.command == "job":
            user = approved_user(args.email)
            payload = get_job(args.job_id, root=service_root(), refresh=True)
            if not payload or (not user.get("is_admin") and payload.get("submitter_email") != user["email"]):
                raise ValueError("Job not found for this account.")
        elif args.command == "download":
            payload = download_path(args.email, args.job_id)
        elif args.command == "users":
            user = approved_admin(args.admin_email)
            payload = {"users": list_users(root=service_root())}
        else:
            user = approved_admin(args.admin_email)
            payload = approve_user(args.user_id, user["email"], root=service_root())
        write_json(payload)
        return 0
    except Exception as error:
        write_json({"error": str(error), "error_type": error.__class__.__name__})
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
