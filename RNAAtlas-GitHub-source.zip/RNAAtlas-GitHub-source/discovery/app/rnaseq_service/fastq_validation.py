"""Streaming single- and paired-end FASTQ structural validation."""

from collections import Counter
from contextlib import ExitStack
import gzip
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


class FastqFormatError(ValueError):
    pass


def compression_format(path):
    source = Path(path)
    with source.open("rb") as handle:
        header = handle.read(65536)
    if len(header) < 10 or header[:2] != b"\x1f\x8b":
        return "plain"
    if not (header[3] & 4) or len(header) < 12:
        return "gzip"
    extra_length = int.from_bytes(header[10:12], byteorder="little")
    offset = 12
    extra_end = min(len(header), offset + extra_length)
    while offset + 4 <= extra_end:
        subfield_id = header[offset:offset + 2]
        subfield_length = int.from_bytes(header[offset + 2:offset + 4], byteorder="little")
        offset += 4
        if subfield_id == b"BC" and subfield_length == 2:
            return "BGZF"
        offset += subfield_length
    return "gzip"


def parse_fastq_header(header):
    stripped = str(header).strip()
    if stripped.startswith("@"):
        stripped = stripped[1:]
    fields = stripped.split()
    identifier = fields[0] if fields else ""
    left = identifier.split(":")
    result = {"read_id": identifier}
    if len(left) >= 7:
        result.update(
            {
                "header_format": "illumina_casava_1.8",
                "instrument": left[0],
                "run_number": left[1],
                "flowcell": left[2],
                "lane": left[3],
            }
        )
    else:
        result["header_format"] = "unrecognized"
    if identifier.endswith("/1") or identifier.endswith("/2"):
        result["mate"] = identifier[-1]
    if len(fields) > 1:
        right = fields[1].split(":")
        if right and right[0] in {"1", "2"} and (len(right) >= 4 or len(fields[1]) == 1):
            result["mate"] = right[0]
        if len(right) >= 4 and right[0] in {"1", "2"}:
            result["filter_flag"] = right[1]
            result["control_number"] = right[2]
            result["sample_index"] = right[3]
    return result


def _quality_encoding(minimum_ascii, maximum_ascii):
    if minimum_ascii is None or maximum_ascii is None:
        return "unknown"
    if minimum_ascii < 59 and maximum_ascii <= 126:
        return "Phred+33-compatible"
    if minimum_ascii >= 64:
        return "ambiguous-high-quality-range"
    return "unrecognized"


def profile_fastq_pair(read1, read2=None, maximum_records=2000, prefix_length=12):
    first_path = Path(read1)
    second_path = Path(read2) if read2 else None
    paths = {"read1": first_path}
    if second_path:
        paths["read2"] = second_path
    limit = max(1, int(maximum_records))
    prefix_size = max(1, int(prefix_length))
    read_lengths = {key: [] for key in paths}
    prefixes = {key: Counter() for key in paths}
    base_counts = Counter()
    minimum_quality_ascii = None
    maximum_quality_ascii = None
    first_headers = {}
    sampled = 0
    try:
        with ExitStack() as stack:
            handles = {key: stack.enter_context(gzip.open(str(path), "rt", encoding="ascii", errors="strict", newline=""))
                       for key, path in paths.items()}
            while sampled < limit:
                records = []
                for read_key, path in paths.items():
                    handle = handles[read_key]
                    header = handle.readline()
                    if not header:
                        records.append(None)
                        continue
                    if not header.startswith("@"):
                        raise FastqFormatError("{} has an invalid FASTQ header near record {}.".format(path, sampled + 1))
                    sequence = handle.readline().rstrip("\r\n")
                    separator = handle.readline().rstrip("\r\n")
                    quality = handle.readline().rstrip("\r\n")
                    if not sequence or not separator.startswith("+") or len(sequence) != len(quality):
                        raise FastqFormatError("{} has an invalid sampled record near record {}.".format(path, sampled + 1))
                    parsed_header = parse_fastq_header(header)
                    expected_mate = "1" if read_key == "read1" else "2"
                    if parsed_header.get("mate") and parsed_header["mate"] != expected_mate:
                        raise FastqFormatError("{} has an unexpected read mate near record {}.".format(path, sampled + 1))
                    if read_key not in first_headers:
                        first_headers[read_key] = parsed_header
                    normalized_name = parsed_header["read_id"]
                    if normalized_name.endswith("/1") or normalized_name.endswith("/2"):
                        normalized_name = normalized_name[:-2]
                    read_lengths[read_key].append(len(sequence))
                    prefixes[read_key][sequence[:prefix_size].upper()] += 1
                    base_counts.update(sequence.upper())
                    if quality:
                        local_minimum = min(ord(character) for character in quality)
                        local_maximum = max(ord(character) for character in quality)
                        minimum_quality_ascii = local_minimum if minimum_quality_ascii is None else min(minimum_quality_ascii, local_minimum)
                        maximum_quality_ascii = local_maximum if maximum_quality_ascii is None else max(maximum_quality_ascii, local_maximum)
                    records.append(normalized_name)
                if all(record is None for record in records):
                    break
                if any(record is None for record in records) or (second_path and records[0] != records[1]):
                    raise FastqFormatError("Paired FASTQ names differ in the sampled profile near record {}.".format(sampled + 1))
                sampled += 1
    except (EOFError, OSError, UnicodeError) as error:
        raise FastqFormatError("Unable to profile FASTQs {}: {}".format(", ".join(map(str, paths.values())), error))
    if sampled < 1:
        raise FastqFormatError("FASTQ input is empty: {}.".format(first_path))
    total_bases = sum(base_counts.values())
    gc_bases = base_counts.get("G", 0) + base_counts.get("C", 0)

    def length_summary(values):
        return {"minimum": min(values), "maximum": max(values), "mean": round(float(sum(values)) / len(values), 2)}

    def prefix_summary(counter):
        sequence, count = counter.most_common(1)[0]
        return {"sequence": sequence, "fraction": round(float(count) / sampled, 4)}

    return {
        "layout": "paired-end" if second_path else "single-end",
        "sampled_read_pairs" if second_path else "sampled_reads": sampled,
        "compression": {key: compression_format(path) for key, path in paths.items()},
        "read_lengths": {key: length_summary(values) for key, values in read_lengths.items()},
        "quality_encoding": _quality_encoding(minimum_quality_ascii, maximum_quality_ascii),
        "quality_ascii_range": [minimum_quality_ascii, maximum_quality_ascii],
        "gc_percent": round(100.0 * gc_bases / max(1, total_bases), 2),
        "n_percent": round(100.0 * base_counts.get("N", 0) / max(1, total_bases), 4),
        "headers": first_headers,
        "leading_sequence_signals": {key: prefix_summary(counter) for key, counter in prefixes.items()},
    }


def profile_fastq_samples(samples, maximum_records=2000):
    profiles = {}
    for sample in samples:
        profiles[sample["sample_id"]] = profile_fastq_pair(
            sample["read1"], sample.get("read2"), maximum_records=maximum_records,
        )
    return {
        "samples": profiles,
        "inferred_fields": [
            "read layout", "compression", "sampled read-length distribution", "quality encoding",
            "instrument/run/flowcell/lane when encoded in the header", "sample index when encoded in the header",
            "GC/N content", "strong fixed leading-sequence signals",
        ],
        "requires_library_metadata": [
            "library kit", "biological meaning of adapters or fixed bases", "UMI/barcode semantics",
            "poly(A) selection or rRNA depletion", "strandedness", "specialized 3-prime/5-prime/small-RNA design",
        ],
    }


def _read_record(handle, path, record_number, expected_mate=None):
    header = handle.readline()
    if not header:
        return None
    sequence = handle.readline()
    separator = handle.readline()
    quality = handle.readline()
    if not sequence or not separator or not quality:
        raise FastqFormatError("{} has an incomplete record at record {}.".format(path, record_number))
    header = header.rstrip("\r\n")
    sequence = sequence.rstrip("\r\n")
    separator = separator.rstrip("\r\n")
    quality = quality.rstrip("\r\n")
    if not header.startswith("@"):
        raise FastqFormatError("{} record {} does not start with @.".format(path, record_number))
    if not separator.startswith("+"):
        raise FastqFormatError("{} record {} does not have a + separator.".format(path, record_number))
    if len(sequence) != len(quality):
        raise FastqFormatError(
            "{} record {} has sequence length {} but quality length {} ({}).".format(
                path, record_number, len(sequence), len(quality), header.split()[0]
            )
        )
    mate = parse_fastq_header(header).get("mate")
    if expected_mate and mate and mate != expected_mate:
        raise FastqFormatError("{} has an unexpected read mate at record {}.".format(path, record_number))
    read_name = header[1:].split()[0]
    if read_name.endswith("/1") or read_name.endswith("/2"):
        read_name = read_name[:-2]
    return read_name


def validate_fastq_pair(read1, read2):
    first_path = Path(read1)
    second_path = Path(read2)
    record_number = 0
    try:
        with gzip.open(str(first_path), "rt", encoding="ascii", errors="strict", newline="") as first_handle:
            with gzip.open(str(second_path), "rt", encoding="ascii", errors="strict", newline="") as second_handle:
                while True:
                    record_number += 1
                    first_name = _read_record(first_handle, first_path, record_number, "1")
                    second_name = _read_record(second_handle, second_path, record_number, "2")
                    if first_name is None and second_name is None:
                        return record_number - 1
                    if first_name is None or second_name is None:
                        raise FastqFormatError(
                            "Paired FASTQs have different record counts near record {}: {} and {}.".format(
                                record_number, first_path, second_path
                            )
                        )
                    if first_name != second_name:
                        raise FastqFormatError(
                            "Paired FASTQ names differ at record {}: {} versus {}.".format(
                                record_number, first_name, second_name
                            )
                        )
    except (EOFError, OSError, UnicodeError) as error:
        raise FastqFormatError("Unable to decode paired FASTQs {} and {}: {}".format(first_path, second_path, error))


def validate_fastq_single(read1):
    path = Path(read1)
    count = 0
    try:
        with gzip.open(str(path), "rt", encoding="ascii", errors="strict", newline="") as handle:
            while True:
                if _read_record(handle, path, count + 1, "1") is None:
                    if count < 1:
                        raise FastqFormatError("Single-end FASTQ is empty: {}.".format(path))
                    return count
                count += 1
    except (EOFError, OSError, UnicodeError) as error:
        raise FastqFormatError("Unable to decode single-end FASTQ {}: {}".format(path, error))


def validate_fastq_samples(samples, workers=4):
    results = {}
    errors = []
    maximum_workers = max(1, min(int(workers), len(samples)))
    with ThreadPoolExecutor(max_workers=maximum_workers) as executor:
        futures = {}
        for sample in samples:
            if sample.get("read2"):
                future = executor.submit(validate_fastq_pair, sample["read1"], sample["read2"])
            else:
                future = executor.submit(validate_fastq_single, sample["read1"])
            futures[future] = sample["sample_id"]
        for future in as_completed(futures):
            sample_id = futures[future]
            try:
                results[sample_id] = future.result()
            except FastqFormatError as error:
                errors.append("{}: {}".format(sample_id, error))
    if errors:
        raise FastqFormatError("; ".join(sorted(errors)))
    return results


def sample_fastq_read_lengths(samples):
    lengths = {}
    for sample in samples:
        sample_lengths = []
        for key in ("read1", "read2"):
            if not sample.get(key):
                continue
            path = Path(sample[key])
            try:
                with gzip.open(str(path), "rt", encoding="ascii", errors="strict", newline="") as handle:
                    header = handle.readline()
                    sequence = handle.readline().rstrip("\r\n")
                if not header.startswith("@") or not sequence:
                    raise FastqFormatError("{} does not begin with a complete FASTQ record.".format(path))
            except (EOFError, OSError, UnicodeError) as error:
                raise FastqFormatError("Unable to sample FASTQ read length from {}: {}".format(path, error))
            sample_lengths.append(len(sequence))
        lengths[sample["sample_id"]] = {"read1": sample_lengths[0]}
        if len(sample_lengths) == 2:
            lengths[sample["sample_id"]]["read2"] = sample_lengths[1]
    return lengths
