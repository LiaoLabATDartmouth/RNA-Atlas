"""Variant-level counts and transcript-aware target hotspot interpretation."""

import csv
import gzip
import math
import re
from collections import defaultdict, namedtuple
from pathlib import Path


COMPLEMENT = str.maketrans("ACGTNacgtn", "TGCANtgcan")
CODON_TABLE = {
    "TTT": "F", "TTC": "F", "TTA": "L", "TTG": "L", "TCT": "S", "TCC": "S", "TCA": "S", "TCG": "S",
    "TAT": "Y", "TAC": "Y", "TAA": "*", "TAG": "*", "TGT": "C", "TGC": "C", "TGA": "*", "TGG": "W",
    "CTT": "L", "CTC": "L", "CTA": "L", "CTG": "L", "CCT": "P", "CCC": "P", "CCA": "P", "CCG": "P",
    "CAT": "H", "CAC": "H", "CAA": "Q", "CAG": "Q", "CGT": "R", "CGC": "R", "CGA": "R", "CGG": "R",
    "ATT": "I", "ATC": "I", "ATA": "I", "ATG": "M", "ACT": "T", "ACC": "T", "ACA": "T", "ACG": "T",
    "AAT": "N", "AAC": "N", "AAA": "K", "AAG": "K", "AGT": "S", "AGC": "S", "AGA": "R", "AGG": "R",
    "GTT": "V", "GTC": "V", "GTA": "V", "GTG": "V", "GCT": "A", "GCC": "A", "GCA": "A", "GCG": "A",
    "GAT": "D", "GAC": "D", "GAA": "E", "GAG": "E", "GGT": "G", "GGC": "G", "GGA": "G", "GGG": "G",
}
HOTSPOT_PATTERN = re.compile(r"^([A-Z*])(\d+)([A-Z*])$")


TargetModel = namedtuple(
    "TargetModel",
    ["gene", "gene_id", "transcript_id", "chrom", "strand", "coding_positions", "position_to_index"],
)


class IndexedFasta:
    def __init__(self, fasta_path):
        self.path = Path(fasta_path)
        index_path = Path("{}.fai".format(self.path))
        if not index_path.exists():
            raise ValueError("FASTA index is missing: {}".format(index_path))
        self.index = {}
        with index_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                fields = line.rstrip("\n").split("\t")
                if len(fields) >= 5:
                    self.index[fields[0]] = tuple(int(value) for value in fields[1:5])
        self.handle = self.path.open("rb")

    def close(self):
        self.handle.close()

    def base(self, chrom, position):
        if chrom not in self.index:
            raise KeyError("Contig is absent from FASTA index: {}".format(chrom))
        length, offset, line_bases, line_width = self.index[chrom]
        if position < 1 or position > length:
            raise IndexError("Position outside {}: {}".format(chrom, position))
        zero_based = position - 1
        byte_offset = offset + (zero_based // line_bases) * line_width + (zero_based % line_bases)
        self.handle.seek(byte_offset)
        return self.handle.read(1).decode("ascii").upper()


def parse_attributes(text):
    attributes = {}
    for field in str(text or "").strip().strip(";").split(";"):
        field = field.strip()
        if not field:
            continue
        if "=" in field:
            key, value = field.split("=", 1)
        elif " " in field:
            key, value = field.split(None, 1)
            value = value.strip().strip('"')
        else:
            continue
        attributes[key.strip()] = value.strip()
    return attributes


def _matches_target(attributes, gene, gene_id):
    values = [str(value).strip().lower() for value in attributes.values()]
    if gene and gene.lower() in values:
        return True
    if gene_id:
        target_id = gene_id.lower()
        if target_id in values:
            return True
        if any("geneid:{}".format(target_id) in value for value in values):
            return True
    return False


def _load_annotation(path):
    features = []
    by_id = {}
    with Path(path).open("r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if not line.strip() or line.startswith("#"):
                continue
            fields = line.rstrip("\n").split("\t")
            if len(fields) != 9:
                continue
            try:
                start, end = int(fields[3]), int(fields[4])
            except ValueError:
                continue
            attributes = parse_attributes(fields[8])
            feature = {
                "chrom": fields[0], "type": fields[2], "start": start, "end": end,
                "strand": fields[6], "phase": fields[7], "attributes": attributes,
            }
            features.append(feature)
            feature_id = attributes.get("ID")
            if feature_id:
                by_id[feature_id] = feature
    return features, by_id


def _ancestor_matches(feature, by_id, gene, gene_id):
    if _matches_target(feature["attributes"], gene, gene_id):
        return True
    pending = [parent for parent in feature["attributes"].get("Parent", "").split(",") if parent]
    visited = set()
    while pending:
        parent_id = pending.pop()
        if parent_id in visited:
            continue
        visited.add(parent_id)
        parent = by_id.get(parent_id)
        if not parent:
            continue
        if _matches_target(parent["attributes"], gene, gene_id):
            return True
        pending.extend(value for value in parent["attributes"].get("Parent", "").split(",") if value)
    return False


def build_target_model(annotation_path, gene, gene_id="", transcript_id=""):
    if not gene and not gene_id:
        return None
    features, by_id = _load_annotation(annotation_path)
    grouped = defaultdict(list)
    for feature in features:
        if feature["type"].lower() != "cds":
            continue
        if not _ancestor_matches(feature, by_id, gene, gene_id):
            continue
        attributes = feature["attributes"]
        transcript = attributes.get("transcript_id") or attributes.get("transcript")
        if not transcript:
            transcript = attributes.get("Parent", "").split(",")[0]
        transcript = transcript or attributes.get("gene_id") or attributes.get("ID") or gene
        if transcript_id and transcript != transcript_id:
            continue
        grouped[transcript].append(feature)
    if not grouped:
        return None

    candidates = []
    for transcript, segments in grouped.items():
        strand = segments[0]["strand"]
        if any(segment["strand"] != strand or segment["chrom"] != segments[0]["chrom"] for segment in segments):
            continue
        ordered = sorted(segments, key=lambda item: item["start"], reverse=strand == "-")
        positions = []
        for segment in ordered:
            if strand == "+":
                positions.extend(range(segment["start"], segment["end"] + 1))
            else:
                positions.extend(range(segment["end"], segment["start"] - 1, -1))
        first_phase = ordered[0]["phase"]
        if first_phase in {"1", "2"}:
            positions = positions[int(first_phase):]
        if len(positions) >= 3:
            candidates.append((len(positions), transcript, ordered[0]["chrom"], strand, positions))
    if not candidates:
        return None
    _, selected_transcript, chrom, strand, positions = max(candidates, key=lambda item: (item[0], item[1]))
    return TargetModel(
        gene=gene, gene_id=gene_id, transcript_id=selected_transcript, chrom=chrom, strand=strand,
        coding_positions=positions, position_to_index={position: index for index, position in enumerate(positions)},
    )


def parse_hotspots(values):
    parsed = set()
    for value in values or []:
        match = HOTSPOT_PATTERN.fullmatch(str(value).strip().upper())
        if match:
            parsed.add((match.group(1), int(match.group(2)), match.group(3)))
    return parsed


def write_hotspot_bed(model, hotspot_values, path):
    amino_positions = sorted({position for _, position, _ in parse_hotspots(hotspot_values)})
    genomic_positions = set()
    for amino_position in amino_positions:
        offset = (amino_position - 1) * 3
        genomic_positions.update(model.coding_positions[offset:offset + 3])
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w", encoding="utf-8") as handle:
        for position in sorted(genomic_positions):
            handle.write("{}\t{}\t{}\n".format(model.chrom, position - 1, position))
    return genomic_positions


def _open_vcf(path):
    return gzip.open(path, "rt", encoding="utf-8", errors="replace") if str(path).endswith(".gz") else Path(path).open("r", encoding="utf-8", errors="replace")


def _sample_metrics(format_keys, sample_value, alt_index):
    values = sample_value.split(":")
    data = dict(zip(format_keys, values))
    genotype = data.get("GT", "./.")
    ad_values = data.get("AD", "").split(",") if data.get("AD") not in (None, ".") else []
    try:
        ref_count = int(ad_values[0]) if ad_values else 0
        alt_count = int(ad_values[alt_index]) if len(ad_values) > alt_index else 0
    except ValueError:
        ref_count, alt_count = 0, 0
    try:
        depth = int(data.get("DP", "."))
    except (TypeError, ValueError):
        depth = ref_count + alt_count
    alleles = re.split(r"[/|]", genotype)
    has_alt = str(alt_index) in alleles
    vaf = float(alt_count) / depth if depth else 0.0
    return genotype, ref_count, alt_count, depth, vaf, has_alt


def _annotate_snv(model, fasta, chrom, position, ref, alt):
    if not model or chrom != model.chrom or position not in model.position_to_index or len(ref) != 1 or len(alt) != 1:
        return None
    coding_index = model.position_to_index[position]
    codon_start = (coding_index // 3) * 3
    codon_positions = model.coding_positions[codon_start:codon_start + 3]
    if len(codon_positions) < 3:
        return None
    reference_codon = "".join(fasta.base(model.chrom, genomic_position) for genomic_position in codon_positions)
    coding_alt = alt.upper()
    if model.strand == "-":
        reference_codon = reference_codon.translate(COMPLEMENT)
        coding_alt = coding_alt.translate(COMPLEMENT)
    codon_offset = coding_index % 3
    alternate_codon = reference_codon[:codon_offset] + coding_alt + reference_codon[codon_offset + 1:]
    reference_aa = CODON_TABLE.get(reference_codon, "X")
    alternate_aa = CODON_TABLE.get(alternate_codon, "X")
    amino_position = coding_index // 3 + 1
    return {
        "transcript_id": model.transcript_id,
        "coding_position": coding_index + 1,
        "reference_codon": reference_codon,
        "alternate_codon": alternate_codon,
        "reference_aa": reference_aa,
        "alternate_aa": alternate_aa,
        "amino_acid_position": amino_position,
        "amino_acid_change": "{}{}{}".format(reference_aa, amino_position, alternate_aa),
    }


def summarize_vcf(vcf_path, output_directory, fasta_path=None, model=None, hotspots=None):
    output_root = Path(output_directory)
    output_root.mkdir(parents=True, exist_ok=True)
    counts_path = output_root / "variant_counts.tsv"
    target_path = output_root / "target_coding_variants.tsv"
    parsed_hotspots = parse_hotspots(hotspots)
    fasta = IndexedFasta(fasta_path) if fasta_path and model else None
    samples = []
    target_rows = []
    variant_rows = 0
    count_fields = ["sample_id", "chrom", "position", "ref", "alt", "quality", "filter", "genotype", "ref_count", "alt_count", "depth", "variant_allele_fraction"]
    target_fields = count_fields + ["gene", "gene_id", "transcript_id", "coding_position", "reference_codon", "alternate_codon", "amino_acid_change", "is_requested_hotspot"]
    try:
        with _open_vcf(vcf_path) as source, counts_path.open("w", encoding="utf-8", newline="") as count_handle, target_path.open("w", encoding="utf-8", newline="") as target_handle:
            count_writer = csv.DictWriter(count_handle, fieldnames=count_fields, delimiter="\t")
            target_writer = csv.DictWriter(target_handle, fieldnames=target_fields, delimiter="\t")
            count_writer.writeheader()
            target_writer.writeheader()
            for line in source:
                if line.startswith("##"):
                    continue
                if line.startswith("#CHROM"):
                    samples = line.rstrip("\n").split("\t")[9:]
                    continue
                if line.startswith("#") or not line.strip():
                    continue
                fields = line.rstrip("\n").split("\t")
                if len(fields) < 10:
                    continue
                chrom, position_text, _, ref, alt_text, quality, filter_value = fields[:7]
                position = int(position_text)
                format_keys = fields[8].split(":")
                for alt_index, alt in enumerate(alt_text.split(","), start=1):
                    annotation = _annotate_snv(model, fasta, chrom, position, ref, alt) if fasta else None
                    for sample_name, sample_value in zip(samples, fields[9:]):
                        genotype, ref_count, alt_count, depth, vaf, has_alt = _sample_metrics(format_keys, sample_value, alt_index)
                        row = {
                            "sample_id": sample_name, "chrom": chrom, "position": position, "ref": ref, "alt": alt,
                            "quality": quality, "filter": filter_value, "genotype": genotype, "ref_count": ref_count,
                            "alt_count": alt_count, "depth": depth, "variant_allele_fraction": "{:.6f}".format(vaf),
                        }
                        count_writer.writerow(row)
                        variant_rows += 1
                        if annotation:
                            target_row = dict(row)
                            target_row.update(
                                {
                                    "gene": model.gene, "gene_id": model.gene_id,
                                    "transcript_id": annotation["transcript_id"], "coding_position": annotation["coding_position"],
                                    "reference_codon": annotation["reference_codon"], "alternate_codon": annotation["alternate_codon"],
                                    "amino_acid_change": annotation["amino_acid_change"],
                                    "is_requested_hotspot": str((annotation["reference_aa"], annotation["amino_acid_position"], annotation["alternate_aa"]) in parsed_hotspots).lower(),
                                }
                            )
                            target_writer.writerow(target_row)
                            target_row["has_alt_genotype"] = has_alt
                            target_rows.append(target_row)
    finally:
        if fasta:
            fasta.close()
    return {
        "variant_counts": str(counts_path), "target_variants": str(target_path), "samples": samples,
        "variant_sample_rows": variant_rows, "target_rows": target_rows,
    }


def parse_samtools_depth(text, sample_names):
    depths = {sample: {} for sample in sample_names}
    for line in str(text or "").splitlines():
        fields = line.split("\t")
        if len(fields) < 2 + len(sample_names):
            continue
        chrom, position = fields[0], int(fields[1])
        for sample_name, value in zip(sample_names, fields[2:]):
            try:
                depths[sample_name][(chrom, position)] = int(value)
            except ValueError:
                depths[sample_name][(chrom, position)] = 0
    return depths


def write_target_status(model, hotspot_values, target_rows, depths, minimum_depth, output_path):
    parsed_hotspots = parse_hotspots(hotspot_values)
    amino_positions = sorted({position for _, position, _ in parsed_hotspots})
    requested_changes = {"{}{}{}".format(ref, position, alt) for ref, position, alt in parsed_hotspots}
    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fields = ["sample_id", "gene", "gene_id", "transcript_id", "status", "hotspot_variants", "other_target_variants"]
    fields.extend("aa{}_minimum_depth".format(position) for position in amino_positions)
    with destination.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        for sample_name in sorted(depths):
            sample_variants = [row for row in target_rows if row["sample_id"] == sample_name and row.get("has_alt_genotype")]
            passing_variants = [row for row in sample_variants if row.get("filter") in {"PASS", "."}]
            hotspot_calls = sorted({row["amino_acid_change"] for row in passing_variants if row["amino_acid_change"] in requested_changes})
            low_quality_hotspots = sorted(
                {
                    row["amino_acid_change"] for row in sample_variants
                    if row.get("filter") not in {"PASS", "."} and row["amino_acid_change"] in requested_changes
                }
            )
            other_calls = sorted({row["amino_acid_change"] for row in passing_variants if row["amino_acid_change"] not in requested_changes})
            row = {
                "sample_id": sample_name, "gene": model.gene, "gene_id": model.gene_id,
                "transcript_id": model.transcript_id, "hotspot_variants": ",".join(hotspot_calls),
                "other_target_variants": ",".join(other_calls),
            }
            covered = True
            for amino_position in amino_positions:
                offset = (amino_position - 1) * 3
                positions = model.coding_positions[offset:offset + 3]
                minimum = min((depths[sample_name].get((model.chrom, position), 0) for position in positions), default=0)
                row["aa{}_minimum_depth".format(amino_position)] = minimum
                covered = covered and len(positions) == 3 and minimum >= int(minimum_depth)
            if hotspot_calls:
                row["status"] = "hotspot_mutant"
            elif low_quality_hotspots:
                row["status"] = "uncertain_low_quality_hotspot"
            elif covered:
                row["status"] = "wild_type_supported"
            else:
                row["status"] = "insufficient_coverage"
            writer.writerow(row)
    return str(destination)


def _binomial_two_sided(successes, trials):
    if trials <= 0:
        return 1.0
    lower = min(int(successes), int(trials) - int(successes))
    log_probabilities = [
        math.lgamma(trials + 1) - math.lgamma(index + 1) - math.lgamma(trials - index + 1) - trials * math.log(2.0)
        for index in range(lower + 1)
    ]
    maximum = max(log_probabilities)
    lower_tail = math.exp(maximum) * sum(math.exp(value - maximum) for value in log_probabilities)
    return min(1.0, 2.0 * lower_tail)


def _benjamini_hochberg(pvalues):
    count = len(pvalues)
    adjusted = [1.0] * count
    running = 1.0
    for rank, index in reversed(list(enumerate(sorted(range(count), key=lambda item: pvalues[item]), start=1))):
        running = min(running, pvalues[index] * count / rank)
        adjusted[index] = min(1.0, running)
    return adjusted


def write_allele_specific_counts(variant_counts_path, output_path, minimum_depth=20, minimum_allele_count=3, source="rna_discovery"):
    candidates = []
    with Path(variant_counts_path).open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            if row.get("filter") not in {"PASS", "."}:
                continue
            genotype_alleles = set(re.split(r"[/|]", row.get("genotype", "")))
            if "0" not in genotype_alleles or not any(allele not in {"0", "."} for allele in genotype_alleles):
                continue
            ref_count = int(row.get("ref_count", 0))
            alt_count = int(row.get("alt_count", 0))
            informative_depth = ref_count + alt_count
            if informative_depth < int(minimum_depth) or min(ref_count, alt_count) < int(minimum_allele_count):
                continue
            record = dict(row)
            record["informative_depth"] = informative_depth
            record["alt_fraction"] = float(alt_count) / informative_depth
            record["imbalance_pvalue"] = _binomial_two_sided(alt_count, informative_depth)
            candidates.append(record)
    adjusted = _benjamini_hochberg([record["imbalance_pvalue"] for record in candidates]) if candidates else []
    fields = [
        "sample_id", "chrom", "position", "ref", "alt", "genotype", "ref_count", "alt_count",
        "informative_depth", "alt_fraction", "imbalance_pvalue", "imbalance_fdr", "genotype_source", "interpretation_note",
    ]
    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    note = (
        "Exploratory: genotype discovered in RNA; mapping/reference bias and expression can affect the call."
        if source == "rna_discovery"
        else "Matched DNA genotype; consider WASP-remapped RNA alignments for reference-bias control."
    )
    with destination.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        for record, fdr in zip(candidates, adjusted):
            writer.writerow(
                {
                    "sample_id": record["sample_id"], "chrom": record["chrom"], "position": record["position"],
                    "ref": record["ref"], "alt": record["alt"], "genotype": record["genotype"],
                    "ref_count": record["ref_count"], "alt_count": record["alt_count"],
                    "informative_depth": record["informative_depth"], "alt_fraction": "{:.6f}".format(record["alt_fraction"]),
                    "imbalance_pvalue": "{:.8g}".format(record["imbalance_pvalue"]),
                    "imbalance_fdr": "{:.8g}".format(fdr), "genotype_source": source,
                    "interpretation_note": note,
                }
            )
    return {"path": str(destination), "sites": len(candidates), "source": source}


def remove_repeated_vcf_positions(source_path, destination_path):
    source = Path(source_path)
    destination = Path(destination_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    pending_key = None
    pending_line = None
    group_size = 0
    kept_records = 0
    excluded_records = 0
    excluded_positions = 0
    with source.open("r", encoding="utf-8", errors="replace") as input_handle, destination.open(
        "w", encoding="utf-8"
    ) as output_handle:
        for line in input_handle:
            if line.startswith("#"):
                output_handle.write(line)
                continue
            fields = line.split("\t", 2)
            if len(fields) < 2:
                raise ValueError("Malformed VCF record in {}".format(source))
            key = (fields[0], fields[1])
            if pending_key is not None and key != pending_key:
                if group_size == 1:
                    output_handle.write(pending_line)
                    kept_records += 1
                else:
                    excluded_records += group_size
                    excluded_positions += 1
                group_size = 0
            if key != pending_key:
                pending_key = key
                pending_line = line
            group_size += 1
        if pending_key is not None:
            if group_size == 1:
                output_handle.write(pending_line)
                kept_records += 1
            else:
                excluded_records += group_size
                excluded_positions += 1
    return {
        "path": str(destination), "kept_records": kept_records,
        "excluded_records": excluded_records, "excluded_positions": excluded_positions,
    }


def combine_gatk_ase_tables(table_paths, output_path, minimum_depth=20, minimum_allele_count=3, source="precalled_dna_genotype_recount"):
    candidates = []
    rna_discovery = source == "rna_discovery_recount"
    for sample_name, table_path in sorted(table_paths.items()):
        with Path(table_path).open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader((line for line in handle if not line.startswith("#")), delimiter="\t")
            for row in reader:
                lowered = {str(key).lower(): value for key, value in row.items()}
                try:
                    ref_count = int(lowered.get("refcount", 0))
                    alt_count = int(lowered.get("altcount", 0))
                except (TypeError, ValueError):
                    continue
                informative_depth = ref_count + alt_count
                if informative_depth < int(minimum_depth) or min(ref_count, alt_count) < int(minimum_allele_count):
                    continue
                candidates.append(
                    {
                        "sample_id": sample_name,
                        "chrom": lowered.get("contig", lowered.get("chrom", "")),
                        "position": lowered.get("position", ""),
                        "ref": lowered.get("refallele", lowered.get("ref", "")),
                        "alt": lowered.get("altallele", lowered.get("alt", "")),
                        "genotype": "heterozygous_RNA" if rna_discovery else "heterozygous_DNA",
                        "ref_count": ref_count,
                        "alt_count": alt_count,
                        "informative_depth": informative_depth,
                        "alt_fraction": float(alt_count) / informative_depth,
                        "imbalance_pvalue": _binomial_two_sided(alt_count, informative_depth),
                    }
                )
    adjusted = _benjamini_hochberg([record["imbalance_pvalue"] for record in candidates]) if candidates else []
    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "sample_id", "chrom", "position", "ref", "alt", "genotype", "ref_count", "alt_count",
        "informative_depth", "alt_fraction", "imbalance_pvalue", "imbalance_fdr", "genotype_source", "interpretation_note",
    ]
    with destination.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        for record, fdr in zip(candidates, adjusted):
            record = dict(record)
            record.update(
                {
                    "alt_fraction": "{:.6f}".format(record["alt_fraction"]),
                    "imbalance_pvalue": "{:.8g}".format(record["imbalance_pvalue"]),
                    "imbalance_fdr": "{:.8g}".format(fdr),
                    "genotype_source": source,
                    "interpretation_note": (
                        "Exploratory: the heterozygous site was discovered and recounted in the same RNA sample; mapping bias, RNA editing, and expression-dependent discovery can affect the result."
                        if rna_discovery
                        else "Pre-called DNA heterozygous site recounted in RNA; confirm sample matching and use mapping-bias correction for primary ASE analyses."
                    ),
                }
            )
            writer.writerow(record)
    return {"path": str(destination), "sites": len(candidates), "source": source}
