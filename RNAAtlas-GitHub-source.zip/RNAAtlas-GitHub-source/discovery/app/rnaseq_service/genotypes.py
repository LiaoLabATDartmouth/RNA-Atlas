"""Validation for optional pre-called DNA genotype inputs used by ASE."""

import csv
import gzip
import json
import os
import re
from collections import defaultdict
from pathlib import Path


GENOTYPE_VCF_FILENAMES = ("dna_genotypes.vcf.gz", "dna_genotypes.vcf")
GENOTYPE_MAP_FILENAME = "ase_genotype_map.tsv"
VCF_COLUMNS = ("#CHROM", "POS", "ID", "REF", "ALT", "QUAL", "FILTER", "INFO", "FORMAT")
CONTIG_ID_PATTERN = re.compile(r"(?:^|,)ID=([^,>]+)")
CONTIG_LENGTH_PATTERN = re.compile(r"(?:^|,)length=([0-9]+)", re.IGNORECASE)
GT_FORMAT_PATTERN = re.compile(r"^##FORMAT=<ID=GT(?:,|>)")
VCF_VERSION_PATTERN = re.compile(r"^VCFv4\.[0-9]+$")


def locate_genotype_vcf(project_path):
    project = Path(project_path)
    candidates = [directory / name for directory in (project / "genotype_VCF", project / "meta_data", project / "datasets" / "meta_data")
                  for name in GENOTYPE_VCF_FILENAMES if (directory / name).is_file()]
    if len(candidates) > 1:
        raise ValueError(
            "Keep only one pre-called genotype file in genotype_VCF/ (or legacy meta_data/): {}.".format(
                " or ".join(GENOTYPE_VCF_FILENAMES)
            )
        )
    return candidates[0] if candidates else None


def _open_vcf(path):
    source = Path(path)
    return gzip.open(source, "rt", encoding="utf-8", errors="strict") if source.name.endswith(".gz") else source.open(
        "r", encoding="utf-8", errors="strict"
    )


def _reference_index(fasta_path):
    if not fasta_path:
        return {}
    fasta = Path(fasta_path)
    index_path = Path("{}.fai".format(fasta))
    if not fasta.is_file() or not index_path.is_file():
        raise ValueError("Selected reference FASTA or FASTA index is missing.")
    index = {}
    with index_path.open("r", encoding="utf-8") as handle:
        for line in handle:
            fields = line.rstrip("\n").split("\t")
            if len(fields) < 5:
                continue
            index[fields[0]] = tuple(int(value) for value in fields[1:5])
    if not index:
        raise ValueError("Selected reference FASTA index contains no contigs.")
    return index


def _reference_sequence(handle, reference_index, chrom, position, length):
    sequence_length, offset, line_bases, line_width = reference_index[chrom]
    if position < 1 or length < 1 or position + length - 1 > sequence_length:
        raise IndexError
    sequence = []
    for zero_based in range(position - 1, position - 1 + length):
        byte_offset = offset + (zero_based // line_bases) * line_width + (zero_based % line_bases)
        handle.seek(byte_offset)
        sequence.append(handle.read(1).decode("ascii").upper())
    return "".join(sequence)


def _parse_contig_header(line):
    content = line[line.find("<") + 1:line.rfind(">")]
    id_match = CONTIG_ID_PATTERN.search(content)
    length_match = CONTIG_LENGTH_PATTERN.search(content)
    return (
        id_match.group(1).strip() if id_match else "",
        int(length_match.group(1)) if length_match else None,
    )


def _is_heterozygous(genotype):
    alleles = re.split(r"[/|]", str(genotype or ""))
    called = [allele for allele in alleles if allele not in {"", "."}]
    return len(called) >= 2 and all(allele.isdigit() for allele in called) and len(set(called)) > 1


def _file_fingerprint(path):
    if not path:
        return None
    source = Path(path)
    stat = source.stat()
    return {
        "path": str(source.resolve(strict=False)),
        "size": stat.st_size,
        "mtime_ns": getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1000000000)),
        "inode": getattr(stat, "st_ino", 0),
    }


def _inspection_cache_key(path, reference_fasta):
    fasta_index = Path("{}.fai".format(reference_fasta)) if reference_fasta else None
    return {
        "schema_version": 1,
        "vcf": _file_fingerprint(path),
        "reference_fasta": _file_fingerprint(reference_fasta),
        "reference_fasta_index": _file_fingerprint(fasta_index) if fasta_index else None,
    }


def _read_inspection_cache(cache_path, cache_key):
    if not cache_path or not Path(cache_path).is_file():
        return None
    try:
        payload = json.loads(Path(cache_path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    result = payload.get("result")
    return result if payload.get("cache_key") == cache_key and isinstance(result, dict) else None


def _write_inspection_cache(cache_path, cache_key, result):
    if not cache_path:
        return
    destination = Path(cache_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name("{}.{}.tmp".format(destination.name, os.getpid()))
    try:
        temporary.write_text(
            json.dumps({"cache_key": cache_key, "result": result}, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        os.replace(str(temporary), str(destination))
    except OSError:
        try:
            temporary.unlink()
        except OSError:
            pass


def inspect_genotype_vcf(path, reference_fasta=None, cache_path=None):
    source = Path(path)
    cache_key = _inspection_cache_key(source, reference_fasta)
    cached = _read_inspection_cache(cache_path, cache_key)
    if cached is not None:
        cached["cached"] = True
        return cached
    errors = []
    warnings = []
    fileformat = ""
    declared_contigs = {}
    sample_names = []
    saw_gt_definition = False
    saw_column_header = False
    record_count = 0
    biallelic_snp_count = 0
    passing_heterozygous_counts = defaultdict(int)
    malformed_lines = []
    reference_mismatches = []
    undeclared_record_contigs = set()
    unknown_reference_contigs = set()
    reference_index = _reference_index(reference_fasta)
    fasta_handle = Path(reference_fasta).open("rb") if reference_index else None
    try:
        try:
            handle = _open_vcf(source)
            with handle:
                for line_number, line in enumerate(handle, start=1):
                    if line.startswith("##fileformat="):
                        fileformat = line.rstrip("\r\n").split("=", 1)[1]
                        continue
                    if line.startswith("##contig=<"):
                        contig_id, contig_length = _parse_contig_header(line.rstrip("\r\n"))
                        if not contig_id:
                            malformed_lines.append("line {} has a contig header without ID".format(line_number))
                        elif contig_id in declared_contigs:
                            malformed_lines.append("line {} redeclares contig {}".format(line_number, contig_id))
                        else:
                            declared_contigs[contig_id] = contig_length
                        continue
                    if GT_FORMAT_PATTERN.match(line):
                        saw_gt_definition = True
                        continue
                    if line.startswith("#CHROM"):
                        header_fields = line.rstrip("\r\n").split("\t")
                        saw_column_header = True
                        if tuple(header_fields[:9]) != VCF_COLUMNS:
                            errors.append(
                                "column header must begin with: {}".format(" ".join(VCF_COLUMNS))
                            )
                        if len(header_fields) < 10:
                            errors.append("at least one genotype sample column is required")
                        else:
                            sample_names = header_fields[9:]
                            if any(not sample for sample in sample_names):
                                errors.append("genotype sample names must be non-empty")
                            if len(sample_names) != len(set(sample_names)):
                                errors.append("genotype sample names must be unique")
                        continue
                    if line.startswith("#") or not line.strip():
                        continue
                    if not saw_column_header:
                        malformed_lines.append("line {} appears before the #CHROM header".format(line_number))
                        continue
                    fields = line.rstrip("\r\n").split("\t")
                    expected_fields = 9 + len(sample_names)
                    if len(fields) != expected_fields:
                        malformed_lines.append(
                            "line {} has {} columns; expected {}".format(line_number, len(fields), expected_fields)
                        )
                        continue
                    chrom, position_text, _, ref, alt, _, filter_value = fields[:7]
                    try:
                        position = int(position_text)
                        if position < 1:
                            raise ValueError
                    except ValueError:
                        malformed_lines.append("line {} has invalid POS {}".format(line_number, position_text))
                        continue
                    if not chrom:
                        malformed_lines.append("line {} is missing CHROM".format(line_number))
                    if not ref or ref == ".":
                        malformed_lines.append("line {} is missing REF".format(line_number))
                    if not alt or alt == ".":
                        malformed_lines.append("line {} is missing ALT".format(line_number))
                    if chrom and chrom not in declared_contigs:
                        undeclared_record_contigs.add(chrom)
                    if reference_index:
                        if chrom not in reference_index:
                            unknown_reference_contigs.add(chrom)
                        elif ref and ref != ".":
                            try:
                                expected_ref = _reference_sequence(fasta_handle, reference_index, chrom, position, len(ref))
                            except IndexError:
                                reference_mismatches.append("{}:{} is outside the selected reference".format(chrom, position))
                            else:
                                if ref.upper() != expected_ref:
                                    reference_mismatches.append(
                                        "{}:{} REF={} but selected reference has {}".format(chrom, position, ref, expected_ref)
                                    )
                    format_keys = fields[8].split(":")
                    if "GT" not in format_keys:
                        malformed_lines.append("line {} FORMAT is missing GT".format(line_number))
                        continue
                    gt_index = format_keys.index("GT")
                    record_count += 1
                    alt_alleles = alt.split(",")
                    is_biallelic_snp = (
                        len(ref) == 1 and len(alt_alleles) == 1 and len(alt_alleles[0]) == 1
                        and ref.upper() in "ACGTN" and alt_alleles[0].upper() in "ACGTN"
                    )
                    if is_biallelic_snp:
                        biallelic_snp_count += 1
                    if is_biallelic_snp and filter_value in {"PASS", "."}:
                        for sample_name, sample_value in zip(sample_names, fields[9:]):
                            values = sample_value.split(":")
                            genotype = values[gt_index] if gt_index < len(values) else ""
                            if _is_heterozygous(genotype):
                                passing_heterozygous_counts[sample_name] += 1
        except (OSError, UnicodeError, EOFError) as error:
            errors.append("file could not be read as VCF text: {}".format(error))
    finally:
        if fasta_handle:
            fasta_handle.close()

    if not fileformat:
        errors.append("missing ##fileformat=VCFv4.x header")
    elif not VCF_VERSION_PATTERN.fullmatch(fileformat):
        errors.append("unsupported or malformed VCF fileformat: {}".format(fileformat))
    if not declared_contigs:
        errors.append("missing ##contig=<ID=...> declarations")
    if not saw_gt_definition:
        errors.append("missing ##FORMAT=<ID=GT,...> definition")
    if not saw_column_header:
        errors.append("missing #CHROM column header")
    if saw_column_header and not record_count:
        errors.append("no valid variant records with GT were found")
    if record_count and not biallelic_snp_count:
        errors.append("no biallelic SNP records were found for ASE")
    if undeclared_record_contigs:
        errors.append("record contigs are not declared in the header: {}".format(", ".join(sorted(undeclared_record_contigs))))
    if reference_index:
        header_unknown = sorted(set(declared_contigs) - set(reference_index))
        if header_unknown:
            errors.append("VCF header contigs are absent from the selected reference: {}".format(", ".join(header_unknown)))
        length_mismatches = []
        for contig_id, declared_length in declared_contigs.items():
            if declared_length is not None and contig_id in reference_index and declared_length != reference_index[contig_id][0]:
                length_mismatches.append(
                    "{} VCF={} reference={}".format(contig_id, declared_length, reference_index[contig_id][0])
                )
        if length_mismatches:
            errors.append("contig lengths disagree with the selected reference: {}".format(", ".join(length_mismatches[:10])))
        if unknown_reference_contigs:
            errors.append("record contigs are absent from the selected reference: {}".format(", ".join(sorted(unknown_reference_contigs))))
        if reference_mismatches:
            errors.append("REF alleles disagree with the selected reference: {}".format("; ".join(reference_mismatches[:10])))
    if malformed_lines:
        errors.append("malformed VCF content: {}".format("; ".join(malformed_lines[:20])))
        if len(malformed_lines) > 20:
            warnings.append("{} additional malformed VCF lines were omitted from the error summary.".format(len(malformed_lines) - 20))
    result = {
        "ready": not errors,
        "errors": errors,
        "warnings": warnings,
        "fileformat": fileformat,
        "sample_names": sample_names,
        "declared_contig_count": len(declared_contigs),
        "record_count": record_count,
        "biallelic_snp_count": biallelic_snp_count,
        "passing_heterozygous_counts": dict(passing_heterozygous_counts),
        "cached": False,
    }
    _write_inspection_cache(cache_path, cache_key, result)
    return result


def read_vcf_sample_names(path):
    inspection = inspect_genotype_vcf(path)
    if inspection["errors"]:
        raise ValueError(
            "Pre-called genotype VCF validation failed. Missing or invalid information: {}.".format(
                "; ".join(inspection["errors"])
            )
        )
    return inspection["sample_names"]


def read_genotype_sample_map(path):
    mapping_path = Path(path)
    with mapping_path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if not reader.fieldnames:
            raise ValueError("ASE genotype map has no header.")
        field_map = {name.strip().lower(): name for name in reader.fieldnames}
        rna_key = field_map.get("sample_id")
        vcf_key = field_map.get("vcf_sample_id")
        if not rna_key or not vcf_key:
            raise ValueError("ase_genotype_map.tsv must contain sample_id and vcf_sample_id columns.")
        mapping = {}
        for line_number, row in enumerate(reader, start=2):
            rna_sample = str(row.get(rna_key, "")).strip()
            vcf_sample = str(row.get(vcf_key, "")).strip()
            if not rna_sample and not vcf_sample:
                continue
            if not rna_sample or not vcf_sample:
                raise ValueError("Incomplete ASE genotype map row {}.".format(line_number))
            if rna_sample in mapping:
                raise ValueError("Duplicate RNA sample in ASE genotype map: {}".format(rna_sample))
            mapping[rna_sample] = vcf_sample
    return mapping


def resolve_ase_genotypes(project_path, rna_sample_ids, reference_fasta=None):
    project_root = Path(project_path)
    rna_samples = [str(sample_id) for sample_id in rna_sample_ids]
    vcf_path = locate_genotype_vcf(project_root)
    if not vcf_path:
        raise ValueError(
            "Pre-called DNA genotype ASE requires genotype_VCF/dna_genotypes.vcf.gz "
            "(or dna_genotypes.vcf). Raw DNA FASTQ, BAM, and CRAM inputs are not accepted."
        )
    inspection = inspect_genotype_vcf(
        vcf_path, reference_fasta=reference_fasta,
        cache_path=vcf_path.parent / ".dna_genotypes.validation.json",
    )
    if inspection["errors"]:
        raise ValueError(
            "Pre-called genotype VCF validation failed. Missing or invalid information: {}.".format(
                "; ".join(inspection["errors"])
            )
        )
    vcf_samples = inspection["sample_names"]
    map_path = vcf_path.parent / GENOTYPE_MAP_FILENAME
    mapping = read_genotype_sample_map(map_path) if map_path.is_file() else {
        sample_id: sample_id for sample_id in rna_samples
    }
    unknown_rna_samples = sorted(set(mapping) - set(rna_samples))
    missing_rna_samples = sorted(set(rna_samples) - set(mapping))
    unknown_vcf_samples = sorted(set(mapping.values()) - set(vcf_samples))
    problems = []
    if unknown_rna_samples:
        problems.append("map contains unknown RNA samples: {}".format(", ".join(unknown_rna_samples)))
    if missing_rna_samples:
        problems.append("map is missing RNA samples: {}".format(", ".join(missing_rna_samples)))
    if unknown_vcf_samples:
        problems.append("VCF samples were not found: {}".format(", ".join(unknown_vcf_samples)))
    if not problems:
        samples_without_heterozygous_snps = sorted(
            sample_id for sample_id in rna_samples
            if inspection["passing_heterozygous_counts"].get(mapping[sample_id], 0) < 1
        )
        if samples_without_heterozygous_snps:
            problems.append(
                "mapped RNA samples have no PASS/unfiltered biallelic heterozygous SNPs in their VCF genotype sample: {}".format(
                    ", ".join(samples_without_heterozygous_snps)
                )
            )
    if problems:
        raise ValueError("Invalid ASE genotype mapping or content: {}.".format("; ".join(problems)))
    return {
        "ready": True,
        "vcf_path": str(vcf_path),
        "vcf_filename": vcf_path.name,
        "vcf_samples": vcf_samples,
        "sample_map": {sample_id: mapping[sample_id] for sample_id in rna_samples},
        "map_path": str(map_path) if map_path.is_file() else "",
        "map_filename": map_path.name if map_path.is_file() else "",
        "vcf_fileformat": inspection["fileformat"],
        "vcf_record_count": inspection["record_count"],
        "biallelic_snp_count": inspection["biallelic_snp_count"],
        "declared_contig_count": inspection["declared_contig_count"],
        "passing_heterozygous_counts": inspection["passing_heterozygous_counts"],
        "warnings": inspection["warnings"],
    }


def inspect_ase_genotypes(project_path, rna_sample_ids, reference_fasta=None):
    try:
        vcf_path = locate_genotype_vcf(project_path)
    except ValueError as error:
        return {
            "ready": False, "error": str(error), "errors": [str(error)],
            "vcf_filename": "multiple files", "map_filename": "",
        }
    try:
        details = resolve_ase_genotypes(project_path, rna_sample_ids, reference_fasta=reference_fasta)
    except ValueError as error:
        return {
            "ready": False,
            "error": str(error),
            "errors": [str(error)],
            "vcf_filename": vcf_path.name if vcf_path else "",
            "map_filename": GENOTYPE_MAP_FILENAME if (vcf_path and (vcf_path.parent / GENOTYPE_MAP_FILENAME).is_file()) else "",
        }
    return {
        "ready": True,
        "error": "",
        "errors": [],
        "warnings": details["warnings"],
        "vcf_filename": details["vcf_filename"],
        "map_filename": details["map_filename"],
        "vcf_fileformat": details["vcf_fileformat"],
        "vcf_sample_count": len(details["vcf_samples"]),
        "mapped_rna_sample_count": len(details["sample_map"]),
        "declared_contig_count": details["declared_contig_count"],
        "vcf_record_count": details["vcf_record_count"],
        "biallelic_snp_count": details["biallelic_snp_count"],
    }
