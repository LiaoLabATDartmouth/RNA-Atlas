"""Planning and summaries for project-wide Trinity assemblies."""

import csv
import re
from pathlib import Path

from .parallel import GIBIBYTE, parse_memory_bytes


def validate_salmon_version(version_output):
    match = re.search(r"\bsalmon\s+v?(\d+)\.(\d+)\.(\d+)\b", str(version_output), re.IGNORECASE)
    if not match:
        raise ValueError("Unable to determine the Salmon version.")
    version = tuple(int(value) for value in match.groups())
    if version != (1, 10, 3):
        raise ValueError(
            "Trinity 2.15.2 requires Salmon 1.10.3; found {}.{}.{}.".format(*version)
        )
    return version


def choose_trinity_memory_gb(job_memory, requested=0, reserve_gb=8):
    total_gb = max(1, parse_memory_bytes(job_memory) // GIBIBYTE)
    available_gb = max(4, total_gb - max(0, int(reserve_gb)))
    requested_gb = int(requested or 0)
    if requested_gb > 0:
        return max(4, min(requested_gb, available_gb))
    return available_gb


def trinity_strand_code(strandedness, paired=True):
    codes = {"reverse": "RF", "forward": "FR"} if paired else {"reverse": "R", "forward": "F"}
    return codes.get(str(strandedness), "")


def parse_bowtie2_representation(log_text):
    reads = re.search(r"(?m)^\s*([\d,]+) reads; of these:\s*$", log_text)
    rate = re.search(r"(?m)^\s*(\d+(?:\.\d+)?)% overall alignment rate\s*$", log_text)
    if not reads or not rate:
        raise ValueError("Bowtie2 did not report read input and overall alignment rate.")
    return int(reads.group(1).replace(",", "")), float(rate.group(1))


def summarize_trinity_fasta(fasta_path, destination):
    lengths = []
    current_length = 0
    with Path(fasta_path).open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith(">"):
                if current_length:
                    lengths.append(current_length)
                current_length = 0
            else:
                current_length += len(line.strip())
    if current_length:
        lengths.append(current_length)
    ordered = sorted(lengths, reverse=True)
    total_bases = sum(ordered)
    halfway = total_bases / 2.0
    cumulative = 0
    n50 = 0
    for length in ordered:
        cumulative += length
        if cumulative >= halfway:
            n50 = length
            break
    summary = {
        "transcripts": len(ordered),
        "total_bases": total_bases,
        "minimum_length": min(ordered) if ordered else 0,
        "maximum_length": max(ordered) if ordered else 0,
        "n50": n50,
    }
    output = Path(destination)
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary), delimiter="\t")
        writer.writeheader()
        writer.writerow(summary)
    return {"path": str(output), "summary": summary}
