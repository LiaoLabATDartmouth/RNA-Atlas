"""Combine MetaPhlAn profiles into exploratory microbial composition tables."""

import csv
from pathlib import Path


def read_metaphlan_profile(path, rank="s"):
    abundance = {}
    with Path(path).open("r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if not line.strip() or line.startswith("#"):
                continue
            fields = line.rstrip("\n").split("\t")
            if len(fields) < 3:
                continue
            clade = fields[0]
            if "{}__".format(rank) not in clade.split("|")[-1]:
                continue
            try:
                value = float(fields[2])
            except ValueError:
                continue
            abundance[clade] = value
    return abundance


def combine_metaphlan_profiles(profile_paths, output_path, rank="s"):
    sample_names = sorted(profile_paths)
    profiles = {sample: read_metaphlan_profile(profile_paths[sample], rank=rank) for sample in sample_names}
    taxa = sorted({taxon for profile in profiles.values() for taxon in profile})
    destination = Path(output_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow(["taxon"] + sample_names)
        for taxon in taxa:
            writer.writerow([taxon] + ["{:.8g}".format(profiles[sample].get(taxon, 0.0)) for sample in sample_names])
    return {"path": str(destination), "samples": len(sample_names), "taxa": len(taxa), "rank": rank}

