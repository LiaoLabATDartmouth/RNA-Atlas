"""Interpret STAR gene-count columns from a bounded read alignment."""

import csv
from pathlib import Path


SAMPLED_PAIRS = 50000
MIN_DIRECTIONAL_COUNTS = 200
STRAND_FRACTION_PERCENT = 90


def read_gene_counts(path):
    totals = [0, 0, 0]
    gene_rows = 0
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        for row_number, row in enumerate(csv.reader(handle, delimiter="\t"), start=1):
            if len(row) != 4:
                raise ValueError("STAR gene-count row {} must have four columns.".format(row_number))
            if row[0].startswith("N_"):
                continue
            try:
                values = [int(value) for value in row[1:]]
            except ValueError as error:
                raise ValueError("STAR gene-count row {} is not numeric.".format(row_number)) from error
            if any(value < 0 for value in values):
                raise ValueError("STAR gene-count row {} is negative.".format(row_number))
            totals = [total + value for total, value in zip(totals, values)]
            gene_rows += 1
    if not gene_rows:
        raise ValueError("STAR gene-count output has no annotated genes.")
    return {"unstranded_assigned": totals[0], "forward_assigned": totals[1], "reverse_assigned": totals[2]}


def classify_sample(counts):
    forward = int(counts["forward_assigned"])
    reverse = int(counts["reverse_assigned"])
    informative = forward + reverse
    fraction = forward / informative if informative else None
    if informative < MIN_DIRECTIONAL_COUNTS:
        verdict = "unclear_low_counts"
    elif forward * 100 >= informative * STRAND_FRACTION_PERCENT:
        verdict = "forward"
    elif reverse * 100 >= informative * STRAND_FRACTION_PERCENT:
        verdict = "reverse"
    elif 0.4 <= fraction <= 0.6:
        verdict = "balanced_review"
    else:
        verdict = "unclear_mixed"
    return {**counts, "directional_assigned": informative, "forward_fraction": fraction, "verdict": verdict}


def classify_project(samples):
    verdicts = [sample["verdict"] for sample in samples]
    if verdicts and len(set(verdicts)) == 1 and verdicts[0] in {"forward", "reverse"}:
        return verdicts[0]
    return "needs_review"


def input_reads_from_star_log(path):
    with Path(path).open("r", encoding="utf-8") as handle:
        for line in handle:
            if "|" in line:
                label, value = line.split("|", 1)
                if label.strip() == "Number of input reads":
                    return int(value.strip())
    raise ValueError("STAR final log has no input-read count.")
