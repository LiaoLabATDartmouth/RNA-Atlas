"""HPC RNA-seq pipeline adapted from the supplied STAR/DESeq2 scripts."""

import csv
import html
import json
import math
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import threading
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from .candidate_catalog import (
    build_catalog_rows,
    collect_candidate_records,
    parse_cross_assembler_best_hits,
    parse_cross_assembler_blast,
    write_catalog_fasta,
    write_catalog_summary,
    write_catalog_table,
    write_trinity_strategy_summary,
    write_trinity_strategy_table,
)
from .counts import combine_star_counts
from .fastq_validation import (
    FastqFormatError,
    profile_fastq_samples,
    sample_fastq_read_lengths,
    validate_fastq_pair,
    validate_fastq_samples,
)
from .microbiome import combine_metaphlan_profiles
from .parallel import (
    GIBIBYTE,
    choose_alignment_workers,
    choose_ase_workers,
    choose_variant_shards,
    choose_variant_workers,
    detect_available_cpus,
    parse_memory_bytes,
    partition_reference_intervals,
    read_reference_contigs,
)
from .paths import enforce_rnaseq_boundary, shared_assets_root
from .preprocessing import fastp_command, normalize_preprocessing_options
from .project import validate_project, write_normalized_sample_sheet
from .quality_summary import write_quality_summary
from .strandedness import SAMPLED_PAIRS, classify_project, classify_sample, input_reads_from_star_log, read_gene_counts
from .trinity import choose_trinity_memory_gb, parse_bowtie2_representation, summarize_trinity_fasta, trinity_strand_code, validate_salmon_version
from .utils import atomic_write_json, utc_now
from .unmapped_rna import (
    combine_candidate_tables,
    filter_and_summarize_fasta,
    parse_host_blast,
    parse_viral_blast,
    write_candidate_table,
    write_non_host_fasta,
)
from .variants import (
    build_target_model,
    combine_gatk_ase_tables,
    parse_samtools_depth,
    remove_repeated_vcf_positions,
    summarize_vcf,
    write_allele_specific_counts,
    write_hotspot_bed,
    write_target_status,
)


class PipelineError(RuntimeError):
    pass


TRINITY_REQUIRED_EXECUTABLES = ("Trinity", "jellyfish", "bowtie2", "bowtie2-build", "salmon")
STAR_RETAINED_FILES = ("Log.final.out", "Log.out", "Log.progress.out", "ReadsPerGene.out.tab", "SJ.out.tab")


def recommended_star_sa_index_nbases(genome_length):
    length = int(genome_length)
    if length < 1:
        raise ValueError("Genome length must be positive.")
    return min(14, max(1, int(math.log(length, 2) / 2 - 1)))


def retain_star_outputs(work_directory, retained_directory):
    work = Path(work_directory)
    retained = Path(retained_directory)
    retained.mkdir(parents=True, exist_ok=True)
    copied = []
    for filename in STAR_RETAINED_FILES:
        source = work / filename
        if source.is_file():
            shutil.copy2(source, retained / filename)
            copied.append(filename)
    if "Log.final.out" not in copied:
        raise PipelineError("STAR completed without Log.final.out.")
    return copied


class PipelineRunner:
    def __init__(self, job_config_path):
        self.job_config_path = Path(job_config_path).resolve(strict=True)
        with self.job_config_path.open("r", encoding="utf-8") as handle:
            self.job = json.load(handle)
        self.service_root = Path(self.job["service_root"]).resolve(strict=True)
        self.project_root = enforce_rnaseq_boundary(self.job["project_root"], root=self.service_root)
        self.output_root = enforce_rnaseq_boundary(self.job["output_root"], root=self.service_root)
        self.output_root.mkdir(parents=True, exist_ok=True)
        self.tmp_directory = self.node_local_work_parent() / "pipeline_{}".format(self.job["job_id"])
        if self.tmp_directory.exists():
            raise PipelineError("Pipeline node-local work directory already exists: {}".format(self.tmp_directory))
        self.tmp_directory.mkdir(parents=True)
        self.log_directory = self.output_root / "90_logs"
        self.log_directory.mkdir(parents=True, exist_ok=True)
        self.log_path = self.log_directory / "pipeline.log"
        self.status_path = self.output_root / "status.json"
        self.runtime = Path(self.job.get("runtime_root") or self.service_root / "shared" / "runtime")
        self.bin_directory = self.runtime / "bin"
        self.options = dict(self.job.get("options", {}))
        self.requested_cpu_threads = max(1, int(self.options.get("threads", 1)))
        self.options["threads"] = detect_available_cpus(self.requested_cpu_threads)
        self.validation = None
        self.analysis_samples = None
        self.artifacts = {
            "requested_cpu_threads": self.requested_cpu_threads,
            "effective_cpu_threads": self.options["threads"],
        }
        self._log_lock = threading.Lock()

    def tool(self, name, required=True):
        candidate = self.bin_directory / name
        assets = shared_assets_root(self.service_root)
        optional_candidate = assets / "shared" / "unmapped_runtime" / "bin" / name
        trinity_candidate = assets / "shared" / "trinity_runtime" / "bin" / name
        qc_candidate = assets / "shared" / "qc_runtime" / "bin" / name
        if name == "spades.py" and optional_candidate.exists():
            return str(optional_candidate)
        if candidate.exists():
            return str(candidate)
        if optional_candidate.exists():
            return str(optional_candidate)
        if trinity_candidate.exists():
            return str(trinity_candidate)
        if qc_candidate.exists():
            return str(qc_candidate)
        discovered = shutil.which(name)
        if discovered:
            return discovered
        if required:
            raise PipelineError("Required executable is unavailable: {}".format(name))
        return ""

    def r_script_command(self, script, arguments):
        r_home = self.runtime / "lib" / "R"
        r_executable = r_home / "bin" / "exec" / "R"
        if r_executable.is_file() and os.access(r_executable, os.X_OK):
            return ([str(r_executable), "--vanilla", "--slave", "--file={}".format(script),
                     "--args", *map(str, arguments)], {"R_HOME": str(r_home)})
        return ([self.tool("Rscript"), str(script), *map(str, arguments)], {})

    def log(self, message):
        line = "[{}] {}".format(utc_now(), message)
        with self._log_lock:
            print(line, flush=True)
            with self.log_path.open("a", encoding="utf-8") as handle:
                handle.write(line + "\n")

    def _temporary_command_log(self):
        handle = tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", prefix="command_", suffix=".log",
            dir=str(self.tmp_directory), delete=False,
        )
        return handle, Path(handle.name)

    def _merge_command_log(self, path):
        command_log = Path(path)
        with self._log_lock:
            with command_log.open("r", encoding="utf-8", errors="replace") as source, self.log_path.open(
                "a", encoding="utf-8"
            ) as destination:
                for line in source:
                    sys.stdout.write(line)
                    destination.write(line)
            sys.stdout.flush()
        command_log.unlink()

    def node_local_work_parent(self):
        configured = str(os.environ.get("TMPDIR", "")).strip()
        if not configured:
            raise PipelineError("Node-local TMPDIR is required for alignment and assembly work.")
        work_parent = Path(configured).resolve(strict=True)
        service_root = self.service_root.resolve(strict=True)
        if work_parent == service_root or service_root in work_parent.parents:
            raise PipelineError("TMPDIR is inside the RNA Atlas DartFS root; node-local scratch is required.")
        expected_scratch = (Path("/scratch") / os.environ.get("USER", "")).resolve(strict=False)
        if work_parent != expected_scratch and expected_scratch not in work_parent.parents:
            raise PipelineError("TMPDIR must be inside the Discovery node-local user scratch directory.")
        if not work_parent.is_dir() or not os.access(str(work_parent), os.W_OK | os.X_OK):
            raise PipelineError("Node-local TMPDIR is not writable: {}".format(work_parent))
        return work_parent

    def update_status(self, status, stage, message="", progress=None):
        current = {
            "job_id": self.job["job_id"], "project": self.job["project_name"], "status": status,
            "stage": stage, "message": message, "updated_at": utc_now(), "output_root": str(self.output_root),
            "artifacts": self.artifacts,
        }
        if progress is not None:
            current["progress"] = int(progress)
        atomic_write_json(self.status_path, current)
        self.log("{}: {}".format(stage, message or status))

    def run_command(self, command, label, cwd=None, environment=None, isolated_log=False):
        command = [str(value) for value in command]
        self.log("COMMAND [{}] {}".format(label, " ".join(shlex.quote(value) for value in command)))
        merged_environment = os.environ.copy()
        if environment:
            merged_environment.update(environment)
        if isolated_log:
            log_handle, command_log = self._temporary_command_log()
            with log_handle:
                return_code = subprocess.call(
                    command, cwd=str(cwd) if cwd else None, env=merged_environment,
                    stdout=log_handle, stderr=subprocess.STDOUT,
                )
            self._merge_command_log(command_log)
        else:
            with self.log_path.open("a", encoding="utf-8") as log_handle:
                process = subprocess.Popen(
                    command, cwd=str(cwd) if cwd else None, env=merged_environment,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, bufsize=1,
                )
                for line in process.stdout:
                    sys.stdout.write(line)
                    log_handle.write(line)
                return_code = process.wait()
        if return_code != 0:
            raise PipelineError("{} failed with exit code {}".format(label, return_code))

    def capture_command(self, command, label, cwd=None):
        command = [str(value) for value in command]
        self.log("COMMAND [{}] {}".format(label, " ".join(shlex.quote(value) for value in command)))
        completed = subprocess.run(
            command, cwd=str(cwd) if cwd else None, check=False,
            universal_newlines=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        with self.log_path.open("a", encoding="utf-8") as handle:
            handle.write(completed.stdout)
            handle.write(completed.stderr)
        if completed.returncode != 0:
            raise PipelineError("{} failed with exit code {}: {}".format(label, completed.returncode, completed.stderr.strip()))
        return completed.stdout

    def pipe_commands(self, first, second, label, isolated_log=False):
        first = [str(value) for value in first]
        second = [str(value) for value in second]
        self.log(
            "COMMAND [{}] {} | {}".format(
                label, " ".join(shlex.quote(value) for value in first), " ".join(shlex.quote(value) for value in second)
            )
        )
        if isolated_log:
            log_handle, command_log = self._temporary_command_log()
            with log_handle:
                upstream = subprocess.Popen(first, stdout=subprocess.PIPE, stderr=log_handle)
                downstream = subprocess.Popen(second, stdin=upstream.stdout, stdout=log_handle, stderr=subprocess.STDOUT)
                upstream.stdout.close()
                downstream_code = downstream.wait()
                upstream_code = upstream.wait()
            self._merge_command_log(command_log)
        else:
            with self.log_path.open("a", encoding="utf-8") as log_handle:
                upstream = subprocess.Popen(first, stdout=subprocess.PIPE, stderr=log_handle)
                downstream = subprocess.Popen(second, stdin=upstream.stdout, stdout=log_handle, stderr=subprocess.STDOUT)
                upstream.stdout.close()
                downstream_code = downstream.wait()
                upstream_code = upstream.wait()
        if upstream_code != 0 or downstream_code != 0:
            raise PipelineError("{} failed (upstream={}, downstream={})".format(label, upstream_code, downstream_code))

    def preflight(self):
        self.log(
            "CPU budget: requested {}, effective {} from the Slurm allocation or process CPU limit.".format(
                self.requested_cpu_threads, self.options["threads"],
            )
        )
        self.validation = validate_project(
            self.job["project_name"], root=self.service_root,
            verify_checksums=bool(self.options.get("verify_md5", False)),
            reference_id=self.options.get("reference_id", ""),
            verify_reference_checksums=True,
        )
        if self.validation["errors"]:
            raise PipelineError("Project validation failed: {}".format("; ".join(self.validation["errors"])))
        self.validation["config"]["ploidy"] = int(self.options.get("ploidy", self.validation["config"].get("ploidy", 2)))
        layout = self.validation.get("read_layout")
        if layout == "single" and (self.options.get("run_unmapped_rna") or self.options.get("run_unmapped_trinity")):
            raise PipelineError("Mapping-first candidate workflows still require paired-end reads.")
        self.options.update(normalize_preprocessing_options(
            self.options, config=self.validation["config"],
            layout="single-end" if layout == "single" else "paired-end",
        ))
        if self.options.get("validate_fastq_structure", True):
            self.update_status("running", "preflight", "Validating FASTQ structure", 3)
            try:
                fastq_records = validate_fastq_samples(self.validation["samples"], workers=min(self.options["threads"], 4))
            except FastqFormatError as error:
                raise PipelineError("FASTQ structural validation failed: {}".format(error))
            self.artifacts["fastq_record_counts"] = fastq_records
        sampled_read_lengths = sample_fastq_read_lengths(self.validation["samples"])
        self.artifacts["sampled_fastq_read_lengths"] = sampled_read_lengths
        qc_directory = self.output_root / "00_qc"
        qc_directory.mkdir(parents=True, exist_ok=True)
        fastq_profile = profile_fastq_samples(self.validation["samples"], maximum_records=10000)
        fastq_profile_path = qc_directory / "fastq_profile.json"
        atomic_write_json(fastq_profile_path, fastq_profile)
        self.artifacts["fastq_profile"] = str(fastq_profile_path)
        maximum_read_length = max(
            max(pair_lengths.values()) for pair_lengths in sampled_read_lengths.values()
        )
        sjdb_overhang = int(self.validation.get("reference_star_sjdb_overhang", 0))
        if sjdb_overhang and maximum_read_length - 1 > sjdb_overhang:
            warning = (
                "Selected STAR index sjdbOverhang={} is below sampled read length minus one ({}); "
                "alignment can run, but rebuild this reference for optimal splice-junction sensitivity."
            ).format(sjdb_overhang, maximum_read_length - 1)
            self.validation["warnings"].append(warning)
            self.log("WARNING: {}".format(warning))
        required_tools = ["STAR", "samtools", "pigz", "fastqc", "multiqc"]
        if self.options.get("trimming_mode", "auto") != "none":
            required_tools.append("fastp")
        if self.options.get("run_rna_variants", True) or self.options.get("run_ase", True):
            required_tools.append("bcftools")
            if self.options.get("run_ase", True):
                required_tools.append("gatk")
        if self.options.get("run_differential_expression", True):
            r_executable = self.runtime / "lib" / "R" / "bin" / "exec" / "R"
            if not r_executable.is_file() or not os.access(r_executable, os.X_OK):
                required_tools.append("Rscript")
        if self.options.get("run_microbiome", False):
            required_tools.append("metaphlan")
        run_unmapped_rna = self.options.get("run_unmapped_rna", False)
        run_unmapped_trinity = self.options.get("run_unmapped_trinity", False)
        if run_unmapped_rna or run_unmapped_trinity:
            required_tools.extend(["samtools", "blastn"])
        if run_unmapped_rna:
            required_tools.append("spades.py")
        if self.options.get("run_trinity", False) or run_unmapped_trinity:
            required_tools.extend(TRINITY_REQUIRED_EXECUTABLES)
        for tool_name in required_tools:
            self.tool(tool_name)
        if self.options.get("run_trinity", False) or run_unmapped_trinity:
            salmon = self.tool("salmon")
            completed = subprocess.run(
                [salmon, "--version"], check=False, universal_newlines=True,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            )
            if completed.returncode != 0:
                raise PipelineError("Unable to verify the Salmon version required by Trinity.")
            try:
                salmon_version = validate_salmon_version(completed.stdout)
            except ValueError as error:
                raise PipelineError(str(error))
            self.artifacts["trinity_salmon_version"] = ".".join(str(value) for value in salmon_version)
        metadata_directory = self.output_root / "00_metadata"
        metadata_directory.mkdir(parents=True, exist_ok=True)
        sample_sheet = write_normalized_sample_sheet(self.validation, metadata_directory / "samples.tsv")
        shutil.copy2(self.project_root / "project_config.json", metadata_directory / "project_config.json")
        self.artifacts["sample_sheet"] = str(sample_sheet)

    def _run_fastqc(self, samples, output_directory, label):
        destination = Path(output_directory)
        destination.mkdir(parents=True, exist_ok=True)
        inputs = []
        for sample in samples:
            inputs.append(sample["read1"])
            if sample.get("read2"):
                inputs.append(sample["read2"])
        command = [
            self.tool("fastqc"), "--threads", str(min(max(1, int(self.options["threads"])), 4)),
            "--outdir", destination,
        ] + inputs
        self.run_command(command, label)
        return destination

    def _run_multiqc(self, qc_directory, input_directories):
        output_directory = Path(qc_directory) / "multiqc"
        output_directory.mkdir(parents=True, exist_ok=True)
        command = [
            self.tool("multiqc"), "--force", "--filename", "multiqc_report.html",
            "--outdir", output_directory,
        ] + [str(path) for path in input_directories]
        self.run_command(command, "MultiQC aggregate report")
        report = output_directory / "multiqc_report.html"
        if not report.is_file():
            raise PipelineError("MultiQC completed without producing multiqc_report.html.")
        self.artifacts["multiqc_report"] = str(report)
        return report

    def preprocess_reads(self):
        self.update_status("running", "read_qc", "Profiling raw reads and running FastQC", 5)
        qc_directory = self.output_root / "00_qc"
        raw_samples = [dict(sample) for sample in self.validation["samples"]]
        raw_fastqc = self._run_fastqc(raw_samples, qc_directory / "raw_fastqc", "raw-read FastQC")
        self.artifacts["raw_fastqc_directory"] = str(raw_fastqc)
        mode = self.options.get("trimming_mode", "auto")
        preprocessing_manifest = {
            "mode": mode,
            "raw_reads_preserved": True,
            "cleaned_reads_retained": False,
            "cleaned_read_work_location": "node-local temporary storage",
            "base_correction": False,
            "deduplication": False,
            "poly_g_trimming": False,
            "poly_x_trimming": False,
            "options": {key: self.options.get(key) for key in (
                "library_type", "library_prep", "adapter_handling", "adapter_read1", "adapter_read2",
                "trim_quality_tails", "trim_quality_threshold", "trim_minimum_length", "trim_front_read1",
                "trim_front_read2", "trim_tail_read1", "trim_tail_read2", "umi_status", "selection_method",
                "strandedness", "prior_processing",
            )},
        }
        if mode == "none":
            self.analysis_samples = raw_samples
            preprocessing_manifest["analysis_read_source"] = "raw"
            self._run_multiqc(qc_directory, [raw_fastqc])
        else:
            self.update_status("running", "read_qc", "Conservatively trimming reads with fastp", 9)
            work_parent = self.node_local_work_parent()
            cleaned_root = work_parent / "preprocessed_reads"
            cleaned_root.mkdir(parents=True, exist_ok=True)
            report_root = qc_directory / "fastp"
            report_root.mkdir(parents=True, exist_ok=True)
            total_threads = max(1, int(self.options["threads"]))
            workers = min(len(raw_samples), max(1, total_threads // 4), 4)
            threads_per_worker = min(16, max(1, total_threads // workers))

            def preprocess_sample(sample):
                sample_id = sample["sample_id"]
                output_read1 = cleaned_root / "{}_1.fastq.gz".format(sample_id)
                output_read2 = cleaned_root / "{}_2.fastq.gz".format(sample_id)
                json_report = report_root / "{}.fastp.json".format(sample_id)
                html_report = report_root / "{}.fastp.html".format(sample_id)
                command = fastp_command(
                    self.tool("fastp"), sample, output_read1, output_read2,
                    json_report, html_report, self.options, threads_per_worker,
                )
                self.run_command(command, "fastp {}".format(sample_id), isolated_log=workers > 1)
                if not output_read1.is_file() or (sample.get("read2") and not output_read2.is_file()):
                    raise PipelineError("fastp did not create cleaned reads for {}.".format(sample_id))
                return {
                    "sample_id": sample_id, "condition": sample["condition"],
                    "read1": str(output_read1), "read2": str(output_read2) if sample.get("read2") else "",
                    "layout": sample.get("layout", "paired"),
                }

            completed = {}
            with ThreadPoolExecutor(max_workers=workers) as executor:
                futures = {executor.submit(preprocess_sample, sample): sample["sample_id"] for sample in raw_samples}
                for future in as_completed(futures):
                    cleaned = future.result()
                    completed[cleaned["sample_id"]] = cleaned
            self.analysis_samples = [completed[sample["sample_id"]] for sample in raw_samples]
            try:
                cleaned_counts = validate_fastq_samples(
                    self.analysis_samples, workers=min(int(self.options["threads"]), 4),
                )
            except FastqFormatError as error:
                raise PipelineError("Cleaned FASTQ validation failed: {}".format(error))
            self.artifacts["cleaned_fastq_record_counts"] = cleaned_counts
            self.update_status("running", "read_qc", "Running post-trimming FastQC and MultiQC", 14)
            cleaned_fastqc = self._run_fastqc(
                self.analysis_samples, qc_directory / "cleaned_fastqc", "cleaned-read FastQC",
            )
            self.artifacts["fastp_report_directory"] = str(report_root)
            self.artifacts["cleaned_fastqc_directory"] = str(cleaned_fastqc)
            self._run_multiqc(qc_directory, [raw_fastqc, report_root, cleaned_fastqc])
            preprocessing_manifest["analysis_read_source"] = "cleaned"
            preprocessing_manifest["parallel_fastp_workers"] = workers
            preprocessing_manifest["fastp_threads_per_worker"] = threads_per_worker
        manifest_path = qc_directory / "preprocessing_manifest.json"
        atomic_write_json(manifest_path, preprocessing_manifest)
        self.artifacts["preprocessing_manifest"] = str(manifest_path)
        self.artifacts["trimming_mode"] = mode
        return self.analysis_samples

    def prepare_reference(self):
        self.update_status("running", "reference", "Verifying the selected preinstalled reference", 18)
        fasta = Path(self.validation["reference_fasta"])
        annotation_value = str(self.validation.get("annotation_file", "")).strip()
        annotation = Path(annotation_value) if annotation_value else None
        fasta_index = Path("{}.fai".format(fasta))
        if not fasta_index.exists():
            raise PipelineError("Preinstalled reference FASTA index is missing: {}".format(fasta_index))
        genome_length = int(self.validation.get("reference_genome_bases", 0))
        sa_index_nbases = int(self.validation.get("reference_star_sa_index_nbases", 0))
        index_directory = Path(self.validation["star_index"])
        if not (index_directory / "Genome").exists():
            raise PipelineError("Selected preinstalled STAR index is incomplete: {}".format(index_directory))
        self.artifacts.update(
            {
                "reference_id": self.validation["reference_id"],
                "reference_label": self.validation["reference_label"],
                "reference_fasta": str(fasta), "annotation_file": str(annotation) if annotation else "",
                "reference_has_annotation": bool(annotation),
                "star_index": str(index_directory), "star_sa_index_nbases": sa_index_nbases,
                "star_sjdb_overhang": self.validation.get("reference_star_sjdb_overhang", 0),
                "reference_genome_bases": genome_length,
            }
        )
        return fasta, annotation, index_directory

    def check_strandedness(self, index_directory):
        if not (self.options.get("run_differential_expression") or self.options.get("run_trinity")):
            return True
        self.update_status("running", "strand_check", "Checking library orientation on a small alignment per sample", 19)
        evidence_root = self.output_root / "00_qc" / "strandedness"
        evidence_root.mkdir(parents=True, exist_ok=True)
        samples = []
        if self.validation.get("reference_has_annotation"):
            work_root = self.tmp_directory / "strand_check"
            work_root.mkdir()
            for sample in self.analysis_samples:
                sample_id = sample["sample_id"]
                work_directory = work_root / sample_id
                work_directory.mkdir()
                prefix = "{}/".format(work_directory)
                command = [
                    self.tool("STAR"), "--runThreadN", str(min(4, int(self.options["threads"]))),
                    "--genomeDir", str(index_directory),
                    "--readFilesIn", sample["read1"], *([sample["read2"]] if sample.get("read2") else []),
                    "--readFilesCommand", self.tool("pigz"), "-dc", "-p", "1",
                    "--readMapNumber", str(SAMPLED_PAIRS),
                    "--quantMode", "GeneCounts", "--outSAMtype", "None",
                    "--outFileNamePrefix", prefix,
                ]
                self.run_command(command, "STAR strand check {}".format(sample_id))
                counts_path = work_directory / "ReadsPerGene.out.tab"
                log_path = work_directory / "Log.final.out"
                if not counts_path.is_file() or not log_path.is_file():
                    raise PipelineError("STAR strand check did not create counts and final log for {}.".format(sample_id))
                counts = classify_sample(read_gene_counts(counts_path))
                count_field = "sampled_reads" if self.validation.get("read_layout") == "single" else "sampled_pairs"
                counts.update({"sample_id": sample_id, count_field: input_reads_from_star_log(log_path)})
                retained = evidence_root / sample_id
                retained.mkdir(exist_ok=True)
                shutil.copy2(counts_path, retained / counts_path.name)
                shutil.copy2(log_path, retained / log_path.name)
                samples.append(counts)
            shutil.rmtree(work_root)
        else:
            count_field = "sampled_reads" if self.validation.get("read_layout") == "single" else "sampled_pairs"
            samples = [{"sample_id": sample["sample_id"], count_field: 0,
                        "unstranded_assigned": 0, "forward_assigned": 0, "reverse_assigned": 0,
                        "directional_assigned": 0, "forward_fraction": None,
                        "verdict": "unclear_no_annotation"} for sample in self.analysis_samples]
        inferred = classify_project(samples)
        requested = self.options.get("strandedness", "auto")
        selected = self.validation["config"].get("strandedness", "reverse") if requested == "project_default" else requested
        reviewed = self.options.get("strandedness_reviewed") is True
        if selected == "auto":
            resolved = inferred if inferred in {"forward", "reverse"} else ""
        elif selected == inferred or reviewed:
            resolved = selected
        else:
            resolved = ""
        verdict = "ready" if resolved else "needs_review"
        evidence = {
            "method": "STAR GeneCounts on the first {} {} per sample after preprocessing".format(
                SAMPLED_PAIRS, "reads" if self.validation.get("read_layout") == "single" else "read pairs",
            ),
            "read_layout": self.validation.get("read_layout", "paired"),
            "reference_id": self.validation["reference_id"],
            "annotation_file": str(self.validation.get("annotation_file", "")),
            "sample_count": len(samples), "samples": samples,
            "project_inference": inferred, "requested_strandedness": requested,
            "review_confirmed": reviewed, "resolved_strandedness": resolved,
            "status": verdict,
            "interpretation": "Forward/reverse calls require at least 200 directional gene counts and 90% in one direction. Balanced, intermediate, low-count, missing-annotation, or discordant samples require protocol review; balanced counts do not prove an unstranded library.",
        }
        evidence_path = evidence_root / "evidence.json"
        atomic_write_json(evidence_path, evidence)
        table_path = evidence_root / "sample_evidence.tsv"
        with table_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle, delimiter="\t")
            count_field = "sampled_reads" if self.validation.get("read_layout") == "single" else "sampled_pairs"
            fields = ("sample_id", count_field, "unstranded_assigned", "forward_assigned",
                      "reverse_assigned", "directional_assigned", "forward_fraction", "verdict")
            writer.writerow(fields)
            for sample in samples:
                writer.writerow([sample.get(field, "") for field in fields])
        self.artifacts.update({"strandedness_evidence": str(evidence_path),
                               "strandedness_evidence_table": str(table_path),
                               "strandedness_check": evidence})
        if not resolved:
            review_bundle = self.output_root / "{}_{}_strand_review.zip".format(
                self.job["project_name"], self.job["job_id"][:8],
            )
            with zipfile.ZipFile(review_bundle, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                for path in sorted(evidence_root.rglob("*")):
                    if path.is_file():
                        archive.write(path, path.relative_to(self.output_root))
            self.artifacts.update({"deliverable": str(review_bundle), "deliverable_bytes": review_bundle.stat().st_size})
            self.update_status("needs_review", "strand_review",
                               "Strand check is unclear or disagrees with the selected setting. Review per-sample evidence and library protocol, then create a new job with an explicit orientation and review confirmation.", 19)
            return False
        self.options["resolved_strandedness"] = resolved
        self.log("Strand check selected {} (inference: {}; manual review: {}).".format(resolved, inferred, reviewed))
        return True

    def align(self, index_directory, samples):
        self.update_status("running", "alignment", "Aligning reads with STAR", 20)
        retained_alignment_root = self.output_root / "10_alignment_qc"
        retained_alignment_root.mkdir(parents=True, exist_ok=True)
        alignment_work_root = self.node_local_work_parent() / "alignment_{}".format(self.job["job_id"])
        if alignment_work_root.exists():
            raise PipelineError("STAR node-local output directory already exists: {}".format(alignment_work_root))
        alignment_work_root.mkdir(parents=True)
        config = self.validation["config"]
        if not samples:
            raise PipelineError("Read QC/preprocessing must provide analysis FASTQs before alignment.")
        total_threads = int(self.options["threads"])
        job_memory = parse_memory_bytes(self.options.get("memory", config.get("memory", "64G")))
        workers = choose_alignment_workers(
            total_threads, len(samples), job_memory,
            int(config.get("star_bam_sort_ram", 16000000000)),
            int(self.artifacts.get("reference_genome_bases", 0)),
            requested=config.get("alignment_parallel_samples", 0),
        )
        threads_per_sample = max(1, total_threads // workers)
        decompression_threads = min(2, max(1, threads_per_sample - 1))
        star_threads = max(1, threads_per_sample - decompression_threads)
        self.artifacts.update(
            {
                "alignment_parallel_workers": workers,
                "alignment_star_threads_per_sample": star_threads,
                "alignment_decompression_threads_per_sample": decompression_threads,
            }
        )
        self.log(
            "Running STAR with {} parallel sample worker(s), {} STAR thread(s), and {} decompression thread(s) "
            "per worker.".format(workers, star_threads, decompression_threads)
        )

        def align_sample(sample):
            sample_id = sample["sample_id"]
            output_directory = alignment_work_root / sample_id
            output_directory.mkdir(parents=True, exist_ok=True)
            retained_directory = retained_alignment_root / sample_id
            prefix = "{}/".format(output_directory)
            star_work_root = self.node_local_work_parent() / "star_sort"
            star_work_root.mkdir(parents=True, exist_ok=True)
            star_tmp_directory = star_work_root / sample_id
            if star_tmp_directory.exists():
                raise PipelineError("STAR node-local work directory already exists: {}".format(star_tmp_directory))
            command = [
                self.tool("STAR"), "--runThreadN", str(star_threads),
                "--genomeDir", index_directory, "--readFilesIn", sample["read1"], *([sample["read2"]] if sample.get("read2") else []),
                "--readFilesCommand", self.tool("pigz"), "-dc", "-p", str(decompression_threads),
                "--outFilterType", "BySJout",
                "--outSAMtype", "BAM", "SortedByCoordinate",
                "--limitBAMsortRAM", str(config.get("star_bam_sort_ram", 16000000000)),
                "--outSAMattrRGline", "ID:{}".format(sample_id), "SM:{}".format(sample_id),
                "--outTmpDir", star_tmp_directory,
                "--outFileNamePrefix", prefix,
            ]
            if self.validation.get("reference_has_annotation"):
                command.extend(["--quantMode", "GeneCounts"])
            if self.options.get("run_microbiome", False):
                command.extend(["--outReadsUnmapped", "Fastx"])
            if self.options.get("run_unmapped_rna", False) or self.options.get("run_unmapped_trinity", False):
                command.extend(["--outSAMunmapped", "Within", "KeepPairs"])
            self.run_command(command, "STAR alignment {}".format(sample_id), isolated_log=workers > 1)
            bam = output_directory / "Aligned.sortedByCoord.out.bam"
            if not bam.exists():
                raise PipelineError("STAR did not create the expected BAM for {}".format(sample_id))
            retain_star_outputs(output_directory, retained_directory)
            return sample_id, output_directory, bam

        completed_samples = 0
        results = {}
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(align_sample, sample): sample["sample_id"] for sample in samples}
            for future in as_completed(futures):
                sample_id, output_directory, bam = future.result()
                results[sample_id] = (output_directory, bam)
                completed_samples += 1
                self.update_status(
                    "running", "alignment", "Aligned {} of {} samples".format(completed_samples, len(samples)),
                    20 + int(30 * completed_samples / len(samples)),
                )
        sample_directories = {sample["sample_id"]: results[sample["sample_id"]][0] for sample in samples}
        rna_bams = {sample["sample_id"]: results[sample["sample_id"]][1] for sample in samples}
        self.artifacts["alignment_qc_directory"] = str(retained_alignment_root)
        self.artifacts["alignment_bam_retained"] = False
        self.artifacts["alignment_sort_work_location"] = "node-local temporary storage"
        return sample_directories, rna_bams

    def expression(self, sample_directories):
        if not self.validation.get("reference_has_annotation"):
            if self.options.get("run_differential_expression", True):
                raise PipelineError("Differential expression requires a reference with a matching annotation.")
            self.log("Gene counts skipped because the selected reference is FASTA-only.")
            return
        self.update_status("running", "expression", "Combining gene counts and running DESeq2", 55)
        expression_root = self.output_root / "20_expression"
        selected_strandedness = self.options.get("resolved_strandedness", self.options.get("strandedness", "project_default"))
        if selected_strandedness == "project_default":
            selected_strandedness = self.validation["config"].get("strandedness", "reverse")
        if selected_strandedness == "auto":
            selected_strandedness = "unstranded"
        combined = combine_star_counts(sample_directories, selected_strandedness, expression_root)
        self.artifacts.update({"raw_gene_counts": combined["counts"], "star_count_qc": combined["qc"]})
        if not self.options.get("run_differential_expression", True):
            self.log("DESeq2 skipped by user request; raw gene counts and STAR count QC were retained.")
            return
        reference_condition = self.options["reference_condition"]
        r_script = shared_assets_root(self.service_root) / "r" / "run_deseq2.R"
        r_command, r_environment = self.r_script_command(r_script, [
            "--counts", combined["counts"],
            "--samples", self.artifacts["sample_sheet"], "--output", expression_root,
            "--reference", reference_condition,
            "--log2fc", str(self.options.get("log2fc_cutoff", self.validation["config"].get("log2fc_cutoff", 2.0))),
            "--padj", str(self.options.get("padj_cutoff", self.validation["config"].get("padj_cutoff", 0.05))),
        ])
        self.run_command(
            r_command,
            "DESeq2 differential expression",
            environment=r_environment,
        )
        self.artifacts["normalized_gene_counts"] = str(expression_root / "normalized_gene_counts.tsv")

    def _prepare_variant_bams(self, samtools, bam_paths):
        for bam_path in bam_paths:
            self.run_command([samtools, "quickcheck", "-v", bam_path], "BAM quickcheck {}".format(bam_path.name))
        unindexed_bams = [
            bam_path for bam_path in bam_paths
            if not Path("{}.bai".format(bam_path)).exists() and not bam_path.with_suffix(".bai").exists()
        ]
        if not unindexed_bams:
            return
        index_workers = min(len(unindexed_bams), max(1, int(self.options["threads"]) // 2), 4)
        index_threads = max(1, int(self.options["threads"]) // index_workers - 1)
        self.log(
            "Indexing {} BAM(s) with {} parallel worker(s) and {} thread(s) per worker.".format(
                len(unindexed_bams), index_workers, index_threads,
            )
        )

        def index_bam(bam_path):
            self.run_command(
                [samtools, "index", "-@", str(index_threads), bam_path],
                "BAM index {}".format(bam_path.name), isolated_log=index_workers > 1,
            )

        with ThreadPoolExecutor(max_workers=index_workers) as executor:
            futures = [executor.submit(index_bam, bam_path) for bam_path in unindexed_bams]
            for future in as_completed(futures):
                future.result()

    def _allele_specific_expression(self, fasta, rna_bams, variant_root, rna_variant_vcf=None):
        if not self.options.get("run_ase", True):
            return
        config = self.validation["config"]
        if int(config.get("ploidy", 2)) < 2:
            raise PipelineError("Allele-specific expression requires project ploidy of at least 2.")
        sample_names = [sample["sample_id"] for sample in self.validation["samples"]]
        source_mode = str(self.options.get("ase_source", "rna_discovered"))
        if source_mode == "rna_discovered":
            if not rna_variant_vcf:
                raise PipelineError("RNA-discovered ASE requires RNA variant discovery output.")
            genotype_vcf = Path(rna_variant_vcf)
            sample_map = {sample_name: sample_name for sample_name in sample_names}
            result_source = "rna_discovery_recount"
        elif source_mode == "external_dna_vcf":
            genotype_vcf = enforce_rnaseq_boundary(self.options.get("ase_genotype_vcf", ""), root=self.service_root)
            allowed_vcf_directories = {
                (self.project_root / directory).resolve(strict=False)
                for directory in ("genotype_VCF", "meta_data", "datasets/meta_data")
            }
            if genotype_vcf.parent.resolve(strict=False) not in allowed_vcf_directories:
                raise PipelineError("Pre-called genotype VCF must be staged in the project genotype_VCF directory.")
            if not genotype_vcf.is_file():
                raise PipelineError("Pre-called genotype VCF is missing: {}".format(genotype_vcf))
            sample_map = dict(self.options.get("ase_genotype_sample_map") or {})
            if set(sample_map) != set(sample_names):
                raise PipelineError("ASE genotype sample mapping no longer matches the RNA sample sheet.")
            result_source = "precalled_dna_genotype_recount"
        else:
            raise PipelineError("Unsupported ASE genotype source: {}".format(source_mode))

        gatk = self.tool("gatk")
        bcftools = self.tool("bcftools")
        ase_heap_gb = int(config.get("ase_java_memory_gb", 8))
        dictionary = fasta.with_suffix(".dict")
        if not dictionary.exists():
            raise PipelineError("Preinstalled reference sequence dictionary is missing: {}".format(dictionary))
        ase_workers = choose_ase_workers(
            self.options["threads"], len(sample_names),
            parse_memory_bytes(self.options.get("memory", config.get("memory", "64G"))),
            heap_gb=ase_heap_gb, requested=config.get("ase_parallel_samples", 0),
        )
        ase_bcftools_threads = max(1, int(self.options["threads"]) // ase_workers)
        self.artifacts["ase_parallel_workers"] = ase_workers
        self.artifacts["ase_genotype_source"] = source_mode
        provenance_path = variant_root / "ase_genotype_provenance.json"
        atomic_write_json(
            provenance_path,
            {
                "source": source_mode,
                "vcf_filename": genotype_vcf.name,
                "rna_to_vcf_sample": sample_map,
                "raw_dna_processed": False,
                "note": "The service consumes only a pre-called genotype VCF when external_dna_vcf is selected.",
            },
        )
        self.artifacts["ase_genotype_provenance"] = str(provenance_path)
        self.log(
            "Running GATK ASEReadCounter with {} parallel sample worker(s), {} GB Java heap per worker, and {} sites.".format(
                ase_workers, ase_heap_gb, source_mode,
            )
        )

        def count_sample_alleles(sample_name):
            vcf_sample_name = sample_map[sample_name]
            sample_vcf = variant_root / "{}.heterozygous.vcf.gz".format(sample_name)
            selected_vcf = self.tmp_directory / "{}.heterozygous.selected.vcf".format(sample_name)
            candidate_vcf = self.tmp_directory / "{}.heterozygous.candidates.vcf".format(sample_name)
            unique_vcf = self.tmp_directory / "{}.heterozygous.unique.vcf".format(sample_name)
            self.run_command(
                [
                    bcftools, "view", "-s", vcf_sample_name, "-g", "het", "-f", "PASS,.",
                    "-v", "snps", "-m2", "-M2", "-Ov", "-o", selected_vcf, genotype_vcf,
                ],
                "select heterozygous SNPs {} ({})".format(sample_name, source_mode), isolated_log=ase_workers > 1,
            )
            if source_mode == "external_dna_vcf":
                self.run_command(
                    [bcftools, "norm", "-f", fasta, "-c", "e", "-Ov", "-o", candidate_vcf, selected_vcf],
                    "validate genotype VCF reference alleles {}".format(sample_name), isolated_log=ase_workers > 1,
                )
                selected_vcf.unlink()
            else:
                selected_vcf.replace(candidate_vcf)
            duplicate_summary = remove_repeated_vcf_positions(candidate_vcf, unique_vcf)
            if duplicate_summary["excluded_positions"]:
                self.log(
                    "Excluded {} multi-record positions ({} records) from ASE for {} because GATK "
                    "ASEReadCounter requires at most one variant record per coordinate.".format(
                        duplicate_summary["excluded_positions"], duplicate_summary["excluded_records"], sample_name,
                    )
                )
            self.run_command(
                [bcftools, "view", "--threads", str(ase_bcftools_threads), "-Oz", "-o", sample_vcf, unique_vcf],
                "compress heterozygous VCF {}".format(sample_name), isolated_log=ase_workers > 1,
            )
            candidate_vcf.unlink()
            unique_vcf.unlink()
            self.run_command(
                [bcftools, "index", "-f", "-t", sample_vcf],
                "index heterozygous VCF {}".format(sample_name), isolated_log=ase_workers > 1,
            )
            ase_table = variant_root / "{}.gatk_ase.tsv".format(sample_name)
            self.run_command(
                [
                    gatk, "--java-options", "-Xmx{}g".format(ase_heap_gb), "ASEReadCounter", "-R", fasta,
                    "-I", rna_bams[sample_name], "-V", sample_vcf, "-O", ase_table,
                    "--min-depth", str(self.options.get("ase_min_depth", config.get("ase_min_depth", 20))),
                    "--min-mapping-quality", "20", "--min-base-quality", "20",
                ],
                "GATK ASEReadCounter {}".format(sample_name), isolated_log=ase_workers > 1,
            )
            return sample_name, ase_table

        ase_tables = {}
        completed_ase_samples = 0
        with ThreadPoolExecutor(max_workers=ase_workers) as executor:
            futures = {executor.submit(count_sample_alleles, sample_name): sample_name for sample_name in sample_names}
            for future in as_completed(futures):
                sample_name, ase_table = future.result()
                ase_tables[sample_name] = ase_table
                completed_ase_samples += 1
                self.update_status(
                    "running", "variants",
                    "Completed ASE recounting for {} of {} samples".format(completed_ase_samples, len(sample_names)),
                    76 + int(5 * completed_ase_samples / len(sample_names)),
                )
        ase = combine_gatk_ase_tables(
            ase_tables, variant_root / "allele_specific_counts.tsv",
            minimum_depth=self.options.get("ase_min_depth", config.get("ase_min_depth", 20)),
            minimum_allele_count=self.options.get("ase_min_allele_count", config.get("ase_min_allele_count", 3)), source=result_source,
        )
        self.artifacts["allele_specific_counts"] = ase["path"]

    def variants(self, fasta, annotation, rna_bams):
        run_rna_variants = self.options.get("run_rna_variants", True)
        run_ase = self.options.get("run_ase", True)
        if not run_rna_variants and not run_ase:
            return
        status_message = "Calling RNA variants and calculating allele counts" if run_rna_variants else "Calculating allele-specific RNA counts from pre-called genotypes"
        self.update_status("running", "variants", status_message, 70)
        variant_root = self.output_root / "30_variants"
        variant_root.mkdir(parents=True, exist_ok=True)
        samtools = self.tool("samtools")
        config = self.validation["config"]
        sample_names = [sample["sample_id"] for sample in self.validation["samples"]]
        bam_paths = [rna_bams[sample_name] for sample_name in sample_names]
        self._prepare_variant_bams(samtools, bam_paths)
        if not run_rna_variants:
            self._allele_specific_expression(fasta, rna_bams, variant_root)
            return
        bcftools = self.tool("bcftools")
        raw_vcf = variant_root / "variants.raw.vcf.gz"
        reference_contigs = read_reference_contigs(Path("{}.fai".format(fasta)))
        reference_length = sum(length for _, length in reference_contigs)
        shard_count = choose_variant_shards(
            self.options["threads"], reference_length, config.get("variant_parallel_shards", 0),
        )
        variant_workers = choose_variant_workers(self.options["threads"], shard_count)
        self.artifacts["variant_parallel_shards"] = shard_count
        self.artifacts["variant_parallel_workers"] = variant_workers
        if shard_count == 1:
            mpileup = [
                bcftools, "mpileup", "--threads", str(self.options["threads"]), "-f", fasta,
                "-q", "20", "-Q", "20", "-d", str(config.get("variant_max_pileup_depth", 10000)),
                "-a", "FORMAT/AD,FORMAT/DP", "-Ou",
            ] + bam_paths
            call = [
                bcftools, "call", "--threads", str(self.options["threads"]), "-m", "-v",
                "--ploidy", str(config.get("ploidy", 2)), "-Oz", "-o", raw_vcf,
            ]
            self.pipe_commands(mpileup, call, "bcftools variant calling")
        else:
            shard_root = self.tmp_directory / "variant_shards"
            shard_root.mkdir(parents=True, exist_ok=True)
            reference_shards = partition_reference_intervals(reference_contigs, shard_count)
            shard_records = []
            for shard_number, regions in enumerate(reference_shards, start=1):
                region_file = shard_root / "shard_{:02d}.regions".format(shard_number)
                region_file.write_text(
                    "".join("{}\t{}\t{}\n".format(name, start, end) for name, start, end in regions),
                    encoding="utf-8",
                )
                shard_records.append(
                    (shard_number, region_file, shard_root / "shard_{:02d}.raw.vcf.gz".format(shard_number))
                )
            self.log(
                "Running {} ordered bcftools reference shards through {} parallel workers across {} CPUs.".format(
                    shard_count, variant_workers, self.options["threads"],
                )
            )

            def call_variant_shard(record):
                shard_number, region_file, shard_vcf = record
                mpileup = [
                    bcftools, "mpileup", "--threads", "0", "-f", fasta, "-R", region_file,
                    "-q", "20", "-Q", "20", "-d", str(config.get("variant_max_pileup_depth", 10000)),
                    "-a", "FORMAT/AD,FORMAT/DP", "-Ou",
                ] + bam_paths
                call = [
                    bcftools, "call", "--threads", "0", "-m", "-v", "--ploidy", str(config.get("ploidy", 2)),
                    "-Oz", "-o", shard_vcf,
                ]
                self.pipe_commands(
                    mpileup, call, "bcftools variant shard {}".format(shard_number), isolated_log=True,
                )
                return shard_number

            completed_shards = 0
            with ThreadPoolExecutor(max_workers=variant_workers) as executor:
                futures = {executor.submit(call_variant_shard, record): record for record in shard_records}
                for future in as_completed(futures):
                    future.result()
                    completed_shards += 1
                    self.update_status(
                        "running", "variants",
                        "Completed {} of {} parallel variant shards".format(completed_shards, shard_count),
                        70 + int(5 * completed_shards / shard_count),
                    )
            self.run_command(
                [bcftools, "concat", "--threads", str(self.options["threads"]), "-Oz", "-o", raw_vcf]
                + [record[2] for record in shard_records],
                "concatenate ordered variant shards",
            )
            shutil.rmtree(shard_root)
        canonical_vcf = variant_root / "variants.canonical.vcf.gz"
        self.run_command(
            [
                bcftools, "view", "--threads", str(self.options["threads"]),
                "-e", 'REF~"[^ACGTN]" || ALT~"[^ACGTN,]"',
                "-Oz", "-o", canonical_vcf, raw_vcf,
            ],
            "exclude variants containing noncanonical reference or alternate bases",
        )
        normalized_vcf = variant_root / "variants.normalized.vcf.gz"
        self.run_command(
            [bcftools, "norm", "--threads", str(self.options["threads"]), "-f", fasta, "-m", "-both", "-Oz", "-o", normalized_vcf, canonical_vcf],
            "bcftools normalization",
        )
        filtered_vcf = variant_root / "variants.filtered.vcf.gz"
        filter_expression = "QUAL<{} || INFO/DP<{}".format(
            self.options.get("variant_min_quality", self.validation["config"].get("variant_min_quality", 20)),
            self.options.get("variant_min_depth", self.validation["config"].get("variant_min_depth", 10)),
        )
        self.run_command(
            [bcftools, "filter", "--threads", str(self.options["threads"]), "-s", "LowQual", "-e", filter_expression, "-Oz", "-o", filtered_vcf, normalized_vcf],
            "bcftools filtering",
        )
        self.run_command([bcftools, "index", "-f", "-t", filtered_vcf], "bcftools index")
        model = None
        if annotation:
            model = build_target_model(
                annotation, config.get("target_gene", ""), config.get("target_gene_id", ""), config.get("target_transcript", ""),
            )
        summary = summarize_vcf(
            filtered_vcf, variant_root, fasta_path=fasta, model=model, hotspots=config.get("target_hotspots", []),
        )
        if set(summary["samples"]) != set(sample_names):
            raise PipelineError(
                "VCF sample names do not match sample metadata. Check BAM @RG SM fields: VCF={}, expected={}".format(
                    ",".join(summary["samples"]), ",".join(sample_names)
                )
            )
        self.artifacts.update({"variant_vcf": str(filtered_vcf), "variant_counts": summary["variant_counts"]})
        self._allele_specific_expression(fasta, rna_bams, variant_root, rna_variant_vcf=filtered_vcf)
        if model and config.get("target_hotspots"):
            bed_path = variant_root / "target_hotspot_positions.bed"
            write_hotspot_bed(model, config.get("target_hotspots", []), bed_path)
            depth_text = self.capture_command(
                [samtools, "depth", "-aa", "-b", bed_path] + [rna_bams[sample_name] for sample_name in sample_names],
                "target hotspot depth",
            )
            depths = parse_samtools_depth(depth_text, sample_names)
            status_path = write_target_status(
                model, config.get("target_hotspots", []), summary["target_rows"], depths,
                self.options.get("variant_min_depth", config.get("variant_min_depth", 10)), variant_root / "target_status.tsv",
            )
            self.artifacts.update({"target_coding_variants": summary["target_variants"], "target_status": status_path})
        elif model:
            self.artifacts["target_coding_variants"] = summary["target_variants"]
        elif config.get("target_gene") or config.get("target_gene_id"):
            warning_path = variant_root / "target_not_found.txt"
            warning_path.write_text(
                "The configured target gene could not be interpreted because the selected reference has no annotation, "
                "or the target was not found. Check gene/transcript identifiers and reference capabilities.\n",
                encoding="utf-8",
            )
            self.artifacts["target_warning"] = str(warning_path)

    def _run_trinity_assembly(self, left_reads, right_reads, work_directory, label):
        config = self.validation["config"]
        if work_directory.exists():
            raise PipelineError("Trinity work directory already exists: {}".format(work_directory))
        memory_gb = choose_trinity_memory_gb(
            self.options.get("memory", config.get("memory", "64G")), config.get("trinity_memory_gb", 0),
        )
        minimum_contig_length = int(
            self.options.get("trinity_min_contig_length", config.get("trinity_min_contig_length", 200))
        )
        normalize_reads = bool(
            self.options.get("trinity_normalize_reads", config.get("trinity_normalize_reads", True))
        )
        command = [
            self.tool("Trinity"), "--seqType", "fq",
            "--CPU", str(self.options["threads"]), "--max_memory", "{}G".format(memory_gb),
            "--min_contig_length", str(minimum_contig_length),
            "--output", work_directory,
        ]
        if right_reads:
            command.extend(["--left", ",".join(str(path) for path in left_reads),
                            "--right", ",".join(str(path) for path in right_reads)])
        else:
            command.extend(["--single", ",".join(str(path) for path in left_reads)])
        if normalize_reads:
            command.extend(["--normalize_reads", "--normalize_by_read_set"])
        selected_strandedness = self.options.get("resolved_strandedness", self.options.get("strandedness", "project_default"))
        if selected_strandedness == "project_default":
            selected_strandedness = config.get("strandedness", "reverse")
        strand_code = trinity_strand_code(selected_strandedness, paired=bool(right_reads))
        if strand_code:
            command.extend(["--SS_lib_type", strand_code])
        if config.get("trinity_jaccard_clip", False):
            command.append("--jaccard_clip")
        trinity_bin = shared_assets_root(self.service_root) / "shared" / "trinity_runtime" / "bin"
        trinity_environment = {
            "PATH": os.pathsep.join([str(trinity_bin), os.environ.get("PATH", "")]),
        }
        self.run_command(command, label, environment=trinity_environment)
        assembled_fasta = Path("{}.Trinity.fasta".format(work_directory))
        if not assembled_fasta.is_file():
            raise PipelineError("Trinity completed without producing Trinity.fasta.")
        gene_map = Path("{}.Trinity.fasta.gene_trans_map".format(work_directory))
        return {
            "fasta": assembled_fasta,
            "gene_map": gene_map if gene_map.is_file() else None,
            "in_silico_normalization": normalize_reads,
            "strand_code": strand_code or "unstranded",
            "minimum_contig_length": minimum_contig_length,
            "cpu_threads": int(self.options["threads"]),
            "maximum_memory_gb": memory_gb,
        }

    def trinity(self):
        if not self.options.get("run_trinity", False):
            return
        self.update_status(
            "running", "trinity", "Building a project-wide de novo transcriptome from all reads", 62,
        )
        result_root = self.output_root / "25_denovo_transcriptome"
        result_root.mkdir(parents=True, exist_ok=True)
        work_parent = self.node_local_work_parent()
        minimum_work_bytes = max(20 * GIBIBYTE, int(self.validation.get("fastq_bytes", 0)) * 2)
        free_work_bytes = shutil.disk_usage(work_parent).free
        if free_work_bytes < minimum_work_bytes:
            raise PipelineError(
                "Insufficient node-local space for Trinity: {:.1f} GiB free; at least {:.1f} GiB required.".format(
                    free_work_bytes / GIBIBYTE, minimum_work_bytes / GIBIBYTE,
                )
            )
        work_directory = work_parent / "trinity_{}".format(self.job["job_id"])
        if not self.analysis_samples:
            raise PipelineError("Read QC/preprocessing must provide analysis FASTQs before Trinity.")
        samples = self.analysis_samples
        assembly = self._run_trinity_assembly(
            [sample["read1"] for sample in samples],
            [sample["read2"] for sample in samples] if samples[0].get("read2") else [],
            work_directory,
            "Trinity all-read de novo transcriptome assembly",
        )
        destination_fasta = result_root / "Trinity.fasta"
        shutil.copy2(assembly["fasta"], destination_fasta)
        destination_gene_map = result_root / "Trinity.fasta.gene_trans_map"
        if assembly["gene_map"]:
            shutil.copy2(assembly["gene_map"], destination_gene_map)
        stats = summarize_trinity_fasta(destination_fasta, result_root / "assembly_stats.tsv")
        try:
            representation_path = self._trinity_read_representation(destination_fasta, samples, result_root, work_parent)
            self.artifacts["trinity_read_representation"] = representation_path
        except (OSError, ValueError, PipelineError, subprocess.SubprocessError) as error:
            self.log("WARNING: Trinity read representation could not be measured: {}".format(error))
        manifest_path = result_root / "assembly_manifest.json"
        atomic_write_json(
            manifest_path,
            {
                "assembly_scope": "all_project_paired_reads" if samples[0].get("read2") else "all_project_single_reads",
                "samples": [sample["sample_id"] for sample in samples],
                "in_silico_normalization": assembly["in_silico_normalization"],
                "strand_code": assembly["strand_code"],
                "minimum_contig_length": assembly["minimum_contig_length"],
                "cpu_threads": assembly["cpu_threads"],
                "maximum_memory_gb": assembly["maximum_memory_gb"],
                "summary": stats["summary"],
            },
        )
        shutil.rmtree(work_directory)
        self.artifacts.update(
            {
                "trinity_transcriptome": str(destination_fasta),
                "trinity_assembly_stats": stats["path"],
                "trinity_assembly_manifest": str(manifest_path),
            }
        )
        if destination_gene_map.is_file():
            self.artifacts["trinity_gene_transcript_map"] = str(destination_gene_map)

    def _trinity_read_representation(self, fasta, samples, result_root, work_parent):
        work_directory = work_parent / "trinity_representation_{}".format(self.job["job_id"])
        work_directory.mkdir()
        try:
            index_prefix = work_directory / "assembly"
            self.run_command([self.tool("bowtie2-build"), fasta, index_prefix], "Trinity read-representation index")
            destination = result_root / "read_representation.tsv"
            rows = []
            for sample in samples:
                command = [self.tool("bowtie2"), "-x", str(index_prefix)]
                command.extend(["-1", sample["read1"], "-2", sample["read2"]] if sample.get("read2")
                               else ["-U", sample["read1"]])
                command.extend(["-p", str(min(8, int(self.options["threads"]))), "-S", os.devnull])
                self.log("COMMAND [Trinity read representation {}] {}".format(
                    sample["sample_id"], " ".join(shlex.quote(str(value)) for value in command),
                ))
                completed = subprocess.run(command, check=False, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                with self.log_path.open("a", encoding="utf-8") as handle:
                    handle.write(completed.stderr)
                if completed.returncode != 0:
                    raise PipelineError("Trinity read representation failed for {} with exit code {}".format(
                        sample["sample_id"], completed.returncode,
                    ))
                read_pairs, alignment_percent = parse_bowtie2_representation(completed.stderr)
                rows.append((sample["sample_id"], read_pairs, alignment_percent))
            with destination.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.writer(handle, delimiter="\t")
                writer.writerow(("sample_id", "input_read_pairs" if samples[0].get("read2") else "input_reads",
                                 "overall_alignment_percent"))
                writer.writerows(rows)
            return str(destination)
        finally:
            shutil.rmtree(work_directory)

    def microbiome(self, sample_directories):
        if not self.options.get("run_microbiome", False):
            return
        self.update_status("running", "microbiome", "Profiling exploratory microbial signal", 91)
        config = self.validation["config"]
        database = str(config.get("metaphlan_database", "")).strip()
        if not database:
            raise PipelineError("run_microbiome requires metaphlan_database in project_config.json")
        microbiome_root = self.output_root / "40_microbiome"
        microbiome_root.mkdir(parents=True, exist_ok=True)
        profiles = {}
        for sample_id, sample_directory in sample_directories.items():
            mate1 = sample_directory / "Unmapped.out.mate1"
            mate2 = sample_directory / "Unmapped.out.mate2"
            profile = microbiome_root / "{}.metaphlan.tsv".format(sample_id)
            command = [
                self.tool("metaphlan"), "{},{}".format(mate1, mate2), "--input_type", "fastq",
                "--nproc", str(self.options["threads"]), "--bowtie2db", database,
                "--bowtie2out", microbiome_root / "{}.bowtie2.bz2".format(sample_id), "-o", profile,
            ]
            if config.get("metaphlan_index"):
                command.extend(["--index", config["metaphlan_index"]])
            self.run_command(command, "MetaPhlAn {}".format(sample_id))
            profiles[sample_id] = profile
        combined = combine_metaphlan_profiles(profiles, microbiome_root / "species_relative_abundance.tsv")
        self.artifacts["microbial_relative_abundance"] = combined["path"]

    def _viral_blast_database(self):
        configured = str(self.validation["config"].get("unmapped_rna_blast_database", "")).strip()
        if not configured:
            return None
        candidate = Path(configured)
        if not candidate.is_absolute():
            candidate = self.service_root / candidate
            if not candidate.parent.exists():
                candidate = shared_assets_root(self.service_root) / configured
        candidate = candidate.resolve(strict=False)
        if candidate != self.service_root and self.service_root not in candidate.parents:
            enforce_rnaseq_boundary(candidate, root=shared_assets_root(self.service_root))
        if candidate.parent.exists() and any(candidate.parent.glob(candidate.name + ".*")):
            return candidate
        self.log(
            "WARNING: local viral/viroid BLAST database is unavailable at {}; candidates will not receive "
            "database annotations.".format(candidate)
        )
        return None

    def _genome_unmapped_trinity(self, fasta, read_sets, total_pair_count, work_root, database):
        result_root = self.output_root / "55_unmapped_trinity"
        result_root.mkdir(parents=True, exist_ok=True)
        config = self.validation["config"]
        minimum_pairs = int(
            self.options.get("unmapped_rna_min_pairs", config.get("unmapped_rna_min_pairs", 1000))
        )
        destination_fasta = result_root / "Trinity.fasta"
        candidates = result_root / "assembled_candidates.fasta"
        non_reference = result_root / "non_reference_candidates.fasta"
        candidate_table = result_root / "candidate_contigs.tsv"
        manifest_path = result_root / "assembly_manifest.json"
        manifest = {
            "assembly_scope": "project_fully_genome_unmapped_paired_reads",
            "strategy": "mapping_first_then_trinity",
            "read_filter": "both_mates_unmapped_primary_alignments",
            "samples": [item["sample_id"] for item in read_sets],
            "sample_fully_unmapped_read_pairs": {
                item["sample_id"]: item["pair_count"] for item in read_sets
            },
            "total_fully_unmapped_read_pairs": total_pair_count,
            "minimum_pairs_required": minimum_pairs,
        }
        if total_pair_count < minimum_pairs or not read_sets:
            for path in (destination_fasta, candidates, non_reference):
                path.touch()
            write_candidate_table([], {}, {}, candidate_table, viral_database_used=bool(database))
            manifest["status"] = "skipped_below_minimum_pairs"
            atomic_write_json(manifest_path, manifest)
            self.artifacts.update(
                {
                    "unmapped_trinity_transcriptome": str(destination_fasta),
                    "unmapped_trinity_candidates": str(candidate_table),
                    "unmapped_trinity_non_reference_candidates": str(non_reference),
                    "unmapped_trinity_assembly_manifest": str(manifest_path),
                }
            )
            return

        self.update_status(
            "running", "unmapped_trinity",
            "Building a project-wide Trinity assembly from fully genome-unmapped pairs", 91,
        )
        assembly = self._run_trinity_assembly(
            [item["read1"] for item in read_sets],
            [item["read2"] for item in read_sets],
            work_root / "trinity_assembly",
            "Trinity fully genome-unmapped paired-read assembly",
        )
        shutil.copy2(assembly["fasta"], destination_fasta)
        destination_gene_map = result_root / "Trinity.fasta.gene_trans_map"
        if assembly["gene_map"]:
            shutil.copy2(assembly["gene_map"], destination_gene_map)
        stats = summarize_trinity_fasta(destination_fasta, result_root / "assembly_stats.tsv")
        rows = filter_and_summarize_fasta(
            destination_fasta,
            candidates,
            "project_coassembly",
            "trinity_genome_unmapped_reads",
            minimum_length=assembly["minimum_contig_length"],
        )
        host_hits = {}
        viral_hits = {}
        if rows:
            host_blast = work_root / "trinity_reference_genome_screen.tsv"
            self.run_command(
                [
                    self.tool("blastn"), "-task", "blastn", "-query", candidates, "-subject", fasta,
                    "-evalue", "1e-10", "-max_target_seqs", "25", "-max_hsps", "100",
                    "-num_threads", str(self.options["threads"]),
                    "-outfmt", "6 qseqid qlen qstart qend pident length evalue bitscore sseqid",
                    "-out", host_blast,
                ],
                "mapping-first Trinity reference-genome screen",
            )
            host_hits = parse_host_blast(
                host_blast,
                minimum_identity=self.options.get(
                    "unmapped_rna_host_min_identity", config.get("unmapped_rna_host_min_identity", 90.0)
                ),
                minimum_query_coverage=self.options.get(
                    "unmapped_rna_host_min_query_coverage",
                    config.get("unmapped_rna_host_min_query_coverage", 80.0),
                ),
            )
            non_reference_count = write_non_host_fasta(candidates, non_reference, host_hits)
            if database and non_reference_count:
                viral_blast = work_root / "trinity_viral_viroid_blast.tsv"
                self.run_command(
                    [
                        self.tool("blastn"), "-task", "blastn", "-query", non_reference,
                        "-db", database,
                        "-evalue", str(
                            self.options.get(
                                "unmapped_rna_blast_evalue",
                                config.get("unmapped_rna_blast_evalue", "1e-10"),
                            )
                        ),
                        "-max_target_seqs", "5", "-num_threads", str(self.options["threads"]),
                        "-outfmt", "6 qseqid saccver pident length qcovs evalue bitscore staxids sscinames stitle",
                        "-out", viral_blast,
                    ],
                    "mapping-first Trinity local viral/viroid BLAST",
                    environment={"BLASTDB": str(database.parent)},
                )
                viral_hits = parse_viral_blast(viral_blast)
        else:
            non_reference.touch()
        write_candidate_table(
            rows, host_hits, viral_hits, candidate_table, viral_database_used=bool(database),
        )
        manifest.update(
            {
                "status": "assembled",
                "in_silico_normalization": assembly["in_silico_normalization"],
                "strand_code": assembly["strand_code"],
                "minimum_contig_length": assembly["minimum_contig_length"],
                "cpu_threads": assembly["cpu_threads"],
                "maximum_memory_gb": assembly["maximum_memory_gb"],
                "summary": stats["summary"],
                "non_reference_contigs": sum(row["contig_id"] not in host_hits for row in rows),
            }
        )
        atomic_write_json(manifest_path, manifest)
        self.artifacts.update(
            {
                "unmapped_trinity_transcriptome": str(destination_fasta),
                "unmapped_trinity_assembly_stats": stats["path"],
                "unmapped_trinity_candidates": str(candidate_table),
                "unmapped_trinity_non_reference_candidates": str(non_reference),
                "unmapped_trinity_assembly_manifest": str(manifest_path),
            }
        )
        if destination_gene_map.is_file():
            self.artifacts["unmapped_trinity_gene_transcript_map"] = str(destination_gene_map)

    def unmapped_rna(self, fasta, rna_bams):
        run_rnaspades = bool(self.options.get("run_unmapped_rna", False))
        run_unmapped_trinity = bool(self.options.get("run_unmapped_trinity", False))
        if not run_rnaspades and not run_unmapped_trinity:
            return
        self.update_status("running", "unmapped_rna", "Extracting fully genome-unmapped read pairs", 82)
        config = self.validation["config"]
        mode = str(self.options.get("unmapped_rna_mode", config.get("unmapped_rna_mode", "rna_virus")))
        if mode not in {"transcripts", "rna_virus"}:
            raise PipelineError("Unsupported unmapped RNA discovery mode: {}".format(mode))
        result_root = self.output_root / "50_unmapped_rna"
        work_root = self.node_local_work_parent() / "unmapped_rna_{}".format(self.job["job_id"])
        result_root.mkdir(parents=True, exist_ok=True)
        if work_root.exists():
            raise PipelineError("Unmapped-RNA node-local work directory already exists: {}".format(work_root))
        work_root.mkdir(parents=True)
        samtools = self.tool("samtools")
        spades = self.tool("spades.py") if run_rnaspades else None
        spades_python = Path(spades).parent / "python3" if spades else None
        if spades and not spades_python.exists():
            spades_python = Path(self.tool("python3"))
        blastn = self.tool("blastn")
        database = self._viral_blast_database()
        minimum_pairs = int(self.options.get("unmapped_rna_min_pairs", config.get("unmapped_rna_min_pairs", 1000)))
        minimum_length = int(
            self.options.get("unmapped_rna_min_contig_length", config.get("unmapped_rna_min_contig_length", 200))
        )
        host_minimum_identity = float(
            self.options.get("unmapped_rna_host_min_identity", config.get("unmapped_rna_host_min_identity", 90.0))
        )
        host_minimum_query_coverage = float(
            self.options.get(
                "unmapped_rna_host_min_query_coverage",
                config.get("unmapped_rna_host_min_query_coverage", 80.0),
            )
        )
        viral_blast_evalue = self.options.get(
            "unmapped_rna_blast_evalue", config.get("unmapped_rna_blast_evalue", "1e-10")
        )
        memory_gb = int(config.get("unmapped_rna_memory_gb", 48))
        candidate_tables = []
        read_rows = []
        trinity_read_sets = []
        total_pair_count = 0
        sample_names = [sample["sample_id"] for sample in self.validation["samples"]]
        for sample_number, sample_id in enumerate(sample_names, start=1):
            sample_result = result_root / sample_id
            sample_work = work_root / sample_id
            input_work = sample_work / "reads"
            assembly_work = sample_work / "assembly"
            sample_result.mkdir(parents=True, exist_ok=True)
            input_work.mkdir(parents=True, exist_ok=True)
            mate1 = input_work / "fully_unmapped_1.fastq.gz"
            mate2 = input_work / "fully_unmapped_2.fastq.gz"
            first = [
                samtools, "collate", "-u", "-O", "-T", sample_work / "collate", rna_bams[sample_id],
            ]
            second = [
                samtools, "fastq", "-@", str(self.options["threads"]), "-f", "12", "-F", "2304",
                "-1", mate1, "-2", mate2, "-0", os.devnull, "-s", os.devnull, "-n", "-",
            ]
            self.pipe_commands(first, second, "extract fully unmapped read pairs {}".format(sample_id))
            try:
                pair_count = validate_fastq_pair(mate1, mate2)
            except FastqFormatError as error:
                raise PipelineError("Extracted unmapped FASTQs are invalid for {}: {}".format(sample_id, error))
            read_record = {
                "sample_id": sample_id, "fully_unmapped_read_pairs": pair_count, "assembly_mode": mode,
                "assembled_contigs": 0, "non_reference_contigs": 0, "viral_or_viroid_similarity_contigs": 0,
                "status": "assembled" if run_rnaspades else "rnaspades_not_requested",
            }
            total_pair_count += pair_count
            if pair_count:
                trinity_read_sets.append(
                    {
                        "sample_id": sample_id,
                        "pair_count": pair_count,
                        "read1": mate1,
                        "read2": mate2,
                    }
                )
            candidate_table = sample_result / "candidate_contigs.tsv"
            if not run_rnaspades:
                read_rows.append(read_record)
                self.update_status(
                    "running", "unmapped_rna",
                    "Extracted unmapped pairs for {} of {} samples".format(sample_number, len(sample_names)),
                    82 + int(8 * sample_number / len(sample_names)),
                )
                continue
            if pair_count < minimum_pairs:
                read_record["status"] = "skipped_below_minimum_pairs"
                write_candidate_table([], {}, {}, candidate_table, viral_database_used=bool(database))
                candidate_tables.append(candidate_table)
                read_rows.append(read_record)
                self.update_status(
                    "running", "unmapped_rna",
                    "Skipped low-yield unmapped RNA for {} of {} samples".format(sample_number, len(sample_names)),
                    82 + int(8 * sample_number / len(sample_names)),
                )
                continue
            command = [
                spades_python, spades, "--rna" if mode == "transcripts" else "--rnaviral",
                "-1", mate1, "-2", mate2, "-o", assembly_work,
                "-t", str(self.options["threads"]), "-m", str(memory_gb),
            ]
            if mode == "transcripts":
                strandedness = str(self.options.get("strandedness", "project_default")).lower()
                if strandedness == "project_default":
                    strandedness = str(config.get("strandedness", "unstranded")).lower()
                if strandedness == "reverse":
                    command.extend(["--ss", "rf"])
                elif strandedness == "forward":
                    command.extend(["--ss", "fr"])
            self.run_command(command, "{} assembly {}".format(mode, sample_id))
            assembled = assembly_work / ("transcripts.fasta" if mode == "transcripts" else "contigs.fasta")
            if not assembled.exists():
                raise PipelineError("SPAdes did not create the expected assembly for {}.".format(sample_id))
            candidates = sample_result / "assembled_candidates.fasta"
            rows = filter_and_summarize_fasta(
                assembled, candidates, sample_id, mode, minimum_length=minimum_length,
            )
            read_record["assembled_contigs"] = len(rows)
            host_blast = sample_work / "reference_genome_screen.tsv"
            host_hits = {}
            viral_hits = {}
            non_host = sample_result / "non_reference_candidates.fasta"
            if rows:
                self.run_command(
                    [
                        blastn, "-task", "blastn", "-query", candidates, "-subject", fasta,
                        "-evalue", "1e-10", "-max_target_seqs", "10", "-max_hsps", "50",
                        "-outfmt", "6 qseqid qlen qstart qend pident length evalue bitscore sseqid",
                        "-out", host_blast,
                    ],
                    "reference-genome screen {}".format(sample_id),
                )
                host_hits = parse_host_blast(
                    host_blast,
                    minimum_identity=host_minimum_identity,
                    minimum_query_coverage=host_minimum_query_coverage,
                )
                non_reference_count = write_non_host_fasta(candidates, non_host, host_hits)
                read_record["non_reference_contigs"] = non_reference_count
                if database and non_reference_count:
                    viral_blast = sample_work / "viral_viroid_blast.tsv"
                    self.run_command(
                        [
                            blastn, "-task", "blastn", "-query", non_host, "-db", database,
                            "-evalue", str(viral_blast_evalue),
                            "-max_target_seqs", "5", "-num_threads", str(self.options["threads"]),
                            "-outfmt", "6 qseqid saccver pident length qcovs evalue bitscore staxids sscinames stitle",
                            "-out", viral_blast,
                        ],
                        "local viral/viroid BLAST {}".format(sample_id),
                        environment={"BLASTDB": str(database.parent)},
                    )
                    viral_hits = parse_viral_blast(viral_blast)
                    read_record["viral_or_viroid_similarity_contigs"] = len(viral_hits)
            else:
                candidates.touch()
                non_host.touch()
            write_candidate_table(
                rows, host_hits, viral_hits, candidate_table, viral_database_used=bool(database),
            )
            for filename in ("spades.log", "params.txt"):
                source = assembly_work / filename
                if source.exists():
                    shutil.copy2(source, sample_result / filename)
            candidate_tables.append(candidate_table)
            read_rows.append(read_record)
            self.update_status(
                "running", "unmapped_rna",
                "Processed unmapped RNA for {} of {} samples".format(sample_number, len(sample_names)),
                82 + int(8 * sample_number / len(sample_names)),
            )
        read_counts = result_root / "unmapped_read_summary.tsv"
        read_fields = [
            "sample_id", "fully_unmapped_read_pairs", "assembly_mode", "assembled_contigs",
            "non_reference_contigs", "viral_or_viroid_similarity_contigs", "status",
        ]
        with read_counts.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=read_fields, delimiter="\t")
            writer.writeheader()
            writer.writerows(read_rows)
        self.artifacts.update(
            {
                "unmapped_rna_directory": str(result_root),
                "unmapped_rna_read_summary": str(read_counts),
                "unmapped_rna_viral_database_screened": bool(database),
                "unmapped_rna_work_location": "node-local temporary storage",
            }
        )
        if run_rnaspades:
            combined = combine_candidate_tables(candidate_tables, result_root / "all_candidate_contigs.tsv")
            self.artifacts["unmapped_rna_candidates"] = str(combined)
        if run_unmapped_trinity:
            self._genome_unmapped_trinity(
                fasta, trinity_read_sets, total_pair_count, work_root, database,
            )
        shutil.rmtree(work_root)

    def candidate_catalog(self, fasta):
        if not any(
            self.options.get(option, False)
            for option in ("run_trinity", "run_unmapped_rna", "run_unmapped_trinity")
        ):
            return
        self.update_status(
            "running", "candidate_catalog", "Comparing and annotating non-reference RNA assemblies", 93,
        )
        config = self.validation["config"]
        result_root = self.output_root / "60_candidate_catalog"
        work_root = self.node_local_work_parent() / "candidate_catalog_{}".format(self.job["job_id"])
        result_root.mkdir(parents=True, exist_ok=True)
        if work_root.exists():
            raise PipelineError("Candidate catalog work directory already exists: {}".format(work_root))
        work_root.mkdir(parents=True)
        blastn = self.tool("blastn")
        trinity_source = self.artifacts.get("trinity_transcriptome")
        trinity_non_reference = result_root / "trinity_non_reference_candidates.fasta"
        trinity_rows = []
        if trinity_source and Path(trinity_source).is_file():
            trinity_filtered = work_root / "trinity_candidates.fasta"
            trinity_rows = filter_and_summarize_fasta(
                trinity_source,
                trinity_filtered,
                "project_coassembly",
                "trinity_all_reads",
                minimum_length=int(
                    self.options.get("trinity_min_contig_length", config.get("trinity_min_contig_length", 200))
                ),
            )
            host_hits = {}
            if trinity_rows:
                trinity_host_blast = work_root / "trinity_reference_genome_blast.tsv"
                self.run_command(
                    [
                        blastn, "-task", "blastn", "-query", trinity_filtered, "-subject", fasta,
                        "-evalue", "1e-10", "-max_target_seqs", "25", "-max_hsps", "100",
                        "-num_threads", str(self.options["threads"]),
                        "-outfmt", "6 qseqid qlen qstart qend pident length evalue bitscore sseqid",
                        "-out", trinity_host_blast,
                    ],
                    "Trinity reference-genome screen",
                )
                host_hits = parse_host_blast(
                    trinity_host_blast,
                    minimum_identity=self.options.get(
                        "unmapped_rna_host_min_identity", config.get("unmapped_rna_host_min_identity", 90.0)
                    ),
                    minimum_query_coverage=self.options.get(
                        "unmapped_rna_host_min_query_coverage",
                        config.get("unmapped_rna_host_min_query_coverage", 80.0),
                    ),
                )
                write_non_host_fasta(trinity_filtered, trinity_non_reference, host_hits)
            else:
                trinity_non_reference.touch()
            trinity_table = write_candidate_table(
                trinity_rows,
                host_hits,
                {},
                result_root / "trinity_genome_screen.tsv",
                viral_database_used=False,
            )
            self.artifacts.update(
                {
                    "trinity_genome_screen": str(trinity_table),
                    "trinity_non_reference_candidates": str(trinity_non_reference),
                }
            )

        rnaspades_fastas = []
        unmapped_root = self.output_root / "50_unmapped_rna"
        if unmapped_root.is_dir():
            for candidate in sorted(unmapped_root.glob("*/non_reference_candidates.fasta")):
                rnaspades_fastas.append((candidate.parent.name, candidate))
        normalized_trinity = work_root / "normalized_trinity_candidates.fasta"
        normalized_rnaspades = work_root / "normalized_rnaspades_candidates.fasta"
        records = collect_candidate_records(
            trinity_non_reference if trinity_non_reference.is_file() else None,
            rnaspades_fastas,
            normalized_trinity,
            normalized_rnaspades,
        )
        matches = []
        best_hits = []
        cross_minimum_identity = self.options.get(
            "candidate_cross_min_identity", config.get("candidate_cross_min_identity", 95.0)
        )
        cross_minimum_shorter_coverage = self.options.get(
            "candidate_cross_min_shorter_coverage",
            config.get("candidate_cross_min_shorter_coverage", 80.0),
        )
        if normalized_trinity.stat().st_size and normalized_rnaspades.stat().st_size:
            cross_blast = work_root / "trinity_vs_rnaspades.tsv"
            self.run_command(
                [
                    blastn, "-task", "blastn", "-query", normalized_trinity, "-subject", normalized_rnaspades,
                    "-evalue", "1e-10", "-max_target_seqs", "100", "-max_hsps", "100",
                    "-num_threads", str(self.options["threads"]),
                    "-outfmt", "6 qseqid qlen sseqid slen pident length qstart qend sstart send evalue bitscore",
                    "-out", cross_blast,
                ],
                "Trinity and rnaSPAdes candidate comparison",
            )
            matches = parse_cross_assembler_blast(
                cross_blast,
                minimum_identity=cross_minimum_identity,
                minimum_shorter_coverage=cross_minimum_shorter_coverage,
            )
            best_hits = parse_cross_assembler_best_hits(cross_blast)
        catalog_rows = build_catalog_rows(
            records,
            matches,
            best_hits=best_hits,
        )
        catalog_fasta = write_catalog_fasta(catalog_rows, result_root / "non_reference_candidate_catalog.fasta")
        viral_database = self._viral_blast_database()
        viral_hits = {}
        if viral_database and catalog_rows:
            viral_blast = work_root / "viral_viroid_blast.tsv"
            self.run_command(
                [
                    blastn, "-task", "blastn", "-query", catalog_fasta, "-db", viral_database,
                    "-evalue", str(
                        self.options.get(
                            "unmapped_rna_blast_evalue", config.get("unmapped_rna_blast_evalue", "1e-10")
                        )
                    ),
                    "-max_target_seqs", "5", "-num_threads", str(self.options["threads"]),
                    "-outfmt", "6 qseqid saccver pident length qcovs evalue bitscore staxids sscinames stitle",
                    "-out", viral_blast,
                ],
                "cross-assembler candidate viral and viroid annotation",
                environment={"BLASTDB": str(viral_database.parent)},
            )
            viral_hits = parse_viral_blast(viral_blast)
        catalog_table, annotated_rows = write_catalog_table(
            catalog_rows,
            viral_hits,
            result_root / "non_reference_candidate_catalog.tsv",
            viral_database_used=bool(viral_database),
        )
        catalog_summary = write_catalog_summary(annotated_rows, result_root / "candidate_detection_summary.tsv")
        self.artifacts.update(
            {
                "non_reference_candidate_catalog": str(catalog_table),
                "non_reference_candidate_fasta": str(catalog_fasta),
                "candidate_detection_summary": str(catalog_summary),
                "candidate_catalog_viral_database_screened": bool(viral_database),
                "candidate_catalog_intermediate_location": "node-local temporary storage",
            }
        )
        unmapped_trinity_source = self.artifacts.get("unmapped_trinity_non_reference_candidates")
        if not unmapped_trinity_source:
            retained_unmapped_trinity = self.output_root / "55_unmapped_trinity" / "non_reference_candidates.fasta"
            if retained_unmapped_trinity.is_file():
                unmapped_trinity_source = str(retained_unmapped_trinity)
        if self.options.get("run_unmapped_trinity", False) and unmapped_trinity_source:
            normalized_all_reads = work_root / "normalized_all_read_trinity_candidates.fasta"
            normalized_unmapped_reads = work_root / "normalized_unmapped_read_trinity_candidates.fasta"
            strategy_records = collect_candidate_records(
                trinity_non_reference if trinity_non_reference.is_file() else None,
                [("project_coassembly", Path(unmapped_trinity_source))],
                normalized_all_reads,
                normalized_unmapped_reads,
            )
            strategy_matches = []
            strategy_best_hits = []
            if normalized_all_reads.stat().st_size and normalized_unmapped_reads.stat().st_size:
                strategy_blast = work_root / "all_reads_vs_unmapped_reads_trinity.tsv"
                self.run_command(
                    [
                        blastn, "-task", "blastn", "-query", normalized_all_reads,
                        "-subject", normalized_unmapped_reads,
                        "-evalue", "1e-10", "-max_target_seqs", "100", "-max_hsps", "100",
                        "-num_threads", str(self.options["threads"]),
                        "-outfmt", "6 qseqid qlen sseqid slen pident length qstart qend sstart send evalue bitscore",
                        "-out", strategy_blast,
                    ],
                    "assemble-first and map-first Trinity candidate comparison",
                )
                strategy_matches = parse_cross_assembler_blast(
                    strategy_blast,
                    minimum_identity=cross_minimum_identity,
                    minimum_shorter_coverage=cross_minimum_shorter_coverage,
                )
                strategy_best_hits = parse_cross_assembler_best_hits(strategy_blast)
            strategy_rows = build_catalog_rows(
                strategy_records,
                strategy_matches,
                best_hits=strategy_best_hits,
            )
            strategy_table, annotated_strategy_rows = write_trinity_strategy_table(
                strategy_rows,
                result_root / "trinity_assembly_strategy_comparison.tsv",
            )
            strategy_summary = write_trinity_strategy_summary(
                annotated_strategy_rows,
                result_root / "trinity_assembly_strategy_summary.tsv",
            )
            self.artifacts.update(
                {
                    "trinity_assembly_strategy_comparison": str(strategy_table),
                    "trinity_assembly_strategy_summary": str(strategy_summary),
                }
            )
        shutil.rmtree(work_root)

    def report(self):
        self.update_status("running", "reporting", "Preparing reports and deliverable bundle", 95)
        report_directory = self.output_root / "91_reports"
        report_directory.mkdir(parents=True, exist_ok=True)
        quality_path, quality = write_quality_summary(
            self.output_root, self.validation["samples"], self.artifacts,
            self.job.get("module", "legacy"),
        )
        self.artifacts["qc_summary"] = quality_path
        scientific_cautions = [
            "RNA-derived variants are research calls and can be affected by editing, mapping bias, and allele-specific expression.",
            "Absence of an RNA variant is not wild-type evidence without adequate site coverage.",
            "RNA-seq microbial profiles are exploratory and strongly affected by library preparation and contamination.",
            "Genome-unmapped RNA assemblies are discovery candidates, not proof of a new transcript or active RNA-virus replication.",
            "Trinity contigs are reconstruction hypotheses and can be fragmented, redundant, chimeric, or contaminant-derived.",
            "The Trinity assembly is not a per-sample expression result until reads are quantified back to the common assembly.",
            "A viral database match supports sequence identity but does not distinguish active infection from contamination or an expressed DNA virus.",
            "Gene-level ASE aggregation requires phased heterozygous variants; unphased reference/alternate counts must not be summed across sites.",
        ]
        if self.options.get("run_ase", True):
            if self.options.get("ase_source", "rna_discovered") == "external_dna_vcf":
                scientific_cautions.append(
                    "DNA-informed ASE depends on correct donor/sample matching, a reference-compatible VCF, and RNA mapping-bias control."
                )
            else:
                scientific_cautions.append(
                    "RNA-discovered allelic imbalance is exploratory because the same expression-dependent RNA data discover and recount candidate sites."
                )
        summary = {
            "generated_at": utc_now(), "job_id": self.job["job_id"], "project": self.job["project_name"],
            "samples": len(self.validation["samples"]), "conditions": self.validation["conditions"],
            "warnings": self.validation["warnings"] + quality["warnings"], "artifacts": self.artifacts,
            "scientific_cautions": scientific_cautions,
        }
        summary_path = report_directory / "analysis_summary.json"
        atomic_write_json(summary_path, summary)
        rows = "".join(
            "<tr><th>{}</th><td><code>{}</code></td></tr>".format(html.escape(key), html.escape(str(value)))
            for key, value in sorted(self.artifacts.items())
        )
        quality_rows = "".join(
            "<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>".format(
                html.escape(sample_id),
                html.escape(str(metrics.get("validated_input_pairs", "not measured"))),
                html.escape(str(metrics.get("fastp_retained_percent", "not trimmed"))),
                html.escape(str(metrics.get("unique_mapping_percent", "not measured"))),
            )
            for sample_id, metrics in sorted(quality["samples"].items())
        )
        cautions = "".join("<li>{}</li>".format(html.escape(item)) for item in summary["scientific_cautions"])
        report_path = report_directory / "index.html"
        report_path.write_text(
            "<!doctype html><html><head><meta charset='utf-8'><title>RNA-seq results</title>"
            "<style>body{{font:16px system-ui;max-width:1050px;margin:40px auto;padding:0 24px;color:#172033}}"
            "table{{border-collapse:collapse;width:100%}}th,td{{padding:10px;border-bottom:1px solid #d9e0ea;text-align:left}}"
            ".warning{{background:#fff4db;border-left:4px solid #e49b0f;padding:16px}}</style></head><body>"
            "<h1>{} RNA-seq results</h1><p>Job <code>{}</code>; {} samples.</p>"
            "<div class='warning'><strong>Research-use cautions</strong><ul>{}</ul></div>"
            "<h2>Quality review</h2><p>All samples were retained. Review the QC summary and MultiQC report before interpreting results.</p>"
            "<table><tr><th>Sample</th><th>Validated input pairs</th><th>Retained reads (%)</th>"
            "<th>Unique STAR mapping (%)</th></tr>{}</table>"
            "<ul>{}</ul><h2>Artifacts</h2><table>{}</table>"
            "</body></html>".format(
                html.escape(self.job["project_name"]), html.escape(self.job["job_id"]),
                len(self.validation["samples"]), cautions, quality_rows,
                "".join("<li>{}</li>".format(html.escape(item)) for item in quality["warnings"])
                or "<li>No automatic QC warning was raised; manual review is still required.</li>", rows,
            ),
            encoding="utf-8",
        )
        deliverable = self.output_root / "{}_{}_results.zip".format(self.job["project_name"], self.job["job_id"][:8])
        excluded_suffixes = {".bam", ".bai", ".bcf"}
        with zipfile.ZipFile(deliverable, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as archive:
            for path in sorted(self.output_root.rglob("*")):
                if (not path.is_file() or path == deliverable or path.suffix.lower() in excluded_suffixes
                        or "_code" in path.relative_to(self.output_root).parts):
                    continue
                if "tmp" in path.relative_to(self.output_root).parts:
                    continue
                archive.write(path, path.relative_to(self.output_root))
        self.artifacts.update({
            "analysis_summary": str(summary_path), "html_report": str(report_path),
            "deliverable": str(deliverable), "deliverable_bytes": deliverable.stat().st_size,
        })

    def run(self):
        self.update_status("running", "preflight", "Validating project and runtime", 1)
        try:
            self.preflight()
            analysis_samples = self.preprocess_reads()
            fasta, annotation, index_directory = self.prepare_reference()
            if not self.check_strandedness(index_directory):
                return 0
            sample_directories, rna_bams = self.align(index_directory, samples=analysis_samples)
            self.expression(sample_directories)
            self.trinity()
            self.variants(fasta, annotation, rna_bams)
            self.unmapped_rna(fasta, rna_bams)
            self.microbiome(sample_directories)
            self.candidate_catalog(fasta)
            self.report()
            self.update_status("completed", "complete", "Analysis completed successfully", 100)
            return 0
        except Exception as error:
            self.update_status("failed", "failed", str(error))
            raise


def run_pipeline(job_config_path):
    return PipelineRunner(job_config_path).run()
