"""Project discovery, metadata parsing, and validation."""

import csv
import hashlib
import json
from pathlib import Path

from .genotypes import inspect_ase_genotypes
from .paths import enforce_rnaseq_boundary, project_root, projects_root, service_root, validate_project_name
from .references import load_reference
from .utils import atomic_write_json, human_size, load_json, utc_now
from .xlsx_reader import read_rows as read_xlsx_rows


PROJECT_SUBDIRECTORIES = ("meta_data", "ref_genome", "raw_data")
DEFAULT_CONFIG = {
    "owner_email": "",
    "intake_imported": False,
    "input_subdirectory": "",
    "organism": "",
    "description": "",
    "reference_id": "",
    "strandedness": "reverse",
    "star_bam_sort_ram": 16000000000,
    "alignment_parallel_samples": 0,
    "reference_condition": "",
    "threads": 16,
    "memory": "64G",
    "time_limit": "48:00:00",
    "partition": "standard",
    "verify_md5": True,
    "validate_fastq_structure": True,
    "trimming_mode": "auto",
    "library_type": "standard_bulk",
    "library_prep": "",
    "adapter_handling": "detect",
    "adapter_read1": "",
    "adapter_read2": "",
    "trim_quality_tails": True,
    "trim_quality_threshold": 15,
    "trim_minimum_length": 30,
    "trim_front_read1": 0,
    "trim_front_read2": 0,
    "trim_tail_read1": 0,
    "trim_tail_read2": 0,
    "umi_status": "unknown",
    "selection_method": "unknown",
    "prior_processing": "",
    "run_differential_expression": True,
    "run_rna_variants": True,
    "run_ase": True,
    "run_microbiome": False,
    "run_unmapped_rna": False,
    "run_unmapped_trinity": False,
    "unmapped_rna_mode": "rna_virus",
    "unmapped_rna_min_pairs": 1000,
    "unmapped_rna_min_contig_length": 200,
    "unmapped_rna_memory_gb": 48,
    "unmapped_rna_host_min_identity": 90.0,
    "unmapped_rna_host_min_query_coverage": 80.0,
    "unmapped_rna_blast_evalue": "1e-10",
    "unmapped_rna_blast_database": "shared/databases/ncbi_viral_refseq/non_host_rna_refseq",
    "candidate_cross_min_identity": 95.0,
    "candidate_cross_min_shorter_coverage": 80.0,
    "run_trinity": False,
    "trinity_min_contig_length": 200,
    "trinity_memory_gb": 0,
    "trinity_normalize_reads": True,
    "trinity_jaccard_clip": False,
    "log2fc_cutoff": 2.0,
    "padj_cutoff": 0.05,
    "variant_min_depth": 10,
    "variant_min_quality": 20,
    "variant_max_pileup_depth": 10000,
    "variant_parallel_shards": 0,
    "ploidy": 2,
    "variant_caller": "bcftools",
    "ase_source": "rna_discovered",
    "ase_min_depth": 20,
    "ase_min_allele_count": 3,
    "ase_java_memory_gb": 8,
    "ase_parallel_samples": 0,
    "target_gene": "",
    "target_gene_id": "",
    "target_transcript": "",
    "target_hotspots": ["L100Q", "L100P", "L100R", "L102Q", "L102P", "L102R"],
    "metaphlan_database": "",
    "metaphlan_index": "",
}


def _relative_file(path, root):
    return str(Path(path).resolve(strict=False).relative_to(Path(root).resolve(strict=False)))


def load_project_config(name, root=None):
    path = project_root(name, root=root) / "project_config.json"
    configured = load_json(path, default={}) or {}
    unsupported = sorted(set(configured) - set(DEFAULT_CONFIG) - {"created_at", "updated_at"})
    if unsupported:
        raise ValueError("Unsupported project_config keys: {}".format(", ".join(unsupported)))
    result = dict(DEFAULT_CONFIG)
    result.update(configured)
    result["name"] = name
    return result


def save_project_config(name, updates, root=None):
    root_path = root or service_root()
    destination = project_root(name, root=root_path) / "project_config.json"
    allowed = set(DEFAULT_CONFIG)
    existing = load_project_config(name, root=root_path)
    for key, value in updates.items():
        if key in allowed:
            existing[key] = value
    existing.pop("name", None)
    existing["updated_at"] = utc_now()
    atomic_write_json(enforce_rnaseq_boundary(destination, root=root_path), existing)
    return existing


def create_project(name, organism="", description="", reference_id="", root=None, owner_email="", prepared_existing=False, input_subdirectory=""):
    root_path = root or service_root()
    safe_name = validate_project_name(name)
    if input_subdirectory not in ("", "datasets"):
        raise ValueError("Unsupported project input directory.")
    if input_subdirectory and not prepared_existing:
        raise ValueError("Nested project inputs require a prepared project folder.")
    destination = project_root(safe_name, root=root_path)
    data_path = destination / input_subdirectory if input_subdirectory else destination
    if destination.exists() and not prepared_existing:
        raise ValueError("Project already exists: {}".format(safe_name))
    if prepared_existing:
        if (not destination.is_dir() or destination.is_symlink()
                or (destination / "project_config.json").exists()
                or data_path.is_symlink()
                or any(not (data_path / part).is_dir() or (data_path / part).is_symlink()
                       for part in ("meta_data", "raw_data"))
                or destination.stat().st_mode & 0o002):
            raise ValueError("Prepare a safe project folder with datasets/meta_data/ and datasets/raw_data/ before loading it." if input_subdirectory else "Prepare a safe project folder with meta_data/ and raw_data/ before loading it.")
    selected_reference = str(reference_id or "").strip()
    reference = None
    if selected_reference:
        reference = load_reference(selected_reference, root=root_path)
    if not prepared_existing:
        destination.mkdir(mode=0o700, parents=True)
    subdirectories = ("ref_genome", "genotype_VCF", "results") if input_subdirectory else (*PROJECT_SUBDIRECTORIES, "genotype_VCF", "results")
    for subdirectory in subdirectories:
        if (destination / subdirectory).is_symlink():
            raise ValueError("Project directories cannot be symbolic links.")
        enforce_rnaseq_boundary(destination / subdirectory, root=root_path).mkdir(mode=0o700, exist_ok=prepared_existing)
    for module in ("differential_expression", "rna_snv", "ase", "trinity"):
        if (destination / "results" / module).is_symlink():
            raise ValueError("Project result directories cannot be symbolic links.")
        enforce_rnaseq_boundary(destination / "results" / module, root=root_path).mkdir(mode=0o700, exist_ok=prepared_existing)
    config = dict(DEFAULT_CONFIG)
    config.update(
        {
            "organism": reference["organism"] if reference else str(organism).strip(),
            "ploidy": reference["recommended_ploidy"] if reference else DEFAULT_CONFIG["ploidy"],
            "description": str(description).strip(),
            "reference_id": selected_reference, "owner_email": str(owner_email).strip().lower(),
            "input_subdirectory": input_subdirectory,
            "run_rna_variants": False, "run_ase": False, "ase_source": "external_dna_vcf",
            "intake_imported": bool(prepared_existing),
            "created_at": utc_now(),
        }
    )
    atomic_write_json(destination / "project_config.json", config)
    return destination


def list_projects(root=None, owner_email=None):
    root_path = root or service_root()
    base = projects_root(root_path)
    if not base.exists():
        return []
    projects = []
    for path in sorted(base.iterdir(), key=lambda item: item.name.lower()):
        if (not path.is_dir() or path.is_symlink() or not (path / "project_config.json").is_file()
                or path.name.startswith(".") or path.name.startswith("_")):
            continue
        try:
            project_root(path.name, root=root_path)
        except ValueError:
            continue
        config = load_project_config(path.name, root=root_path)
        if owner_email is not None and config.get("owner_email", "") != owner_email:
            continue
        validation = validate_project(path.name, root=root_path, verify_checksums=False)
        projects.append(
            {
                "name": path.name,
                "ready": not validation["errors"],
                "sample_count": len(validation["samples"]),
                "errors": validation["errors"],
                "warnings": validation["warnings"],
                "organism": config.get("organism", ""),
                "owner_email": config.get("owner_email", ""),
                "intake_imported": bool(config.get("intake_imported")),
            }
        )
    return projects


def _read_tsv_sample_sheet(path):
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if not reader.fieldnames:
            raise ValueError("Sample sheet has no header.")
        field_map = {name.strip().lower(): name for name in reader.fieldnames}
        sample_key = field_map.get("sample_id") or field_map.get("sampleid")
        condition_key = field_map.get("condition") or field_map.get("group_id") or field_map.get("groupid")
        if not sample_key or not condition_key:
            raise ValueError("Sample sheet must contain sample_id and condition columns.")
        rows = []
        for row in reader:
            sample_id = str(row.get(sample_key) or "").strip()
            condition = str(row.get(condition_key) or "").strip()
            if sample_id:
                if not condition:
                    raise ValueError("Sample sheet row for {} has no condition.".format(sample_id))
                rows.append({"sample_id": sample_id, "condition": condition, "variant_bam": str(row.get(field_map.get("variant_bam", "")) or "").strip()})
            elif any(str(value or "").strip() for value in row.values()):
                raise ValueError("Sample sheet has a row without sample_id.")
        return rows


def _read_xlsx_sample_sheet(path):
    rows = read_xlsx_rows(path)
    if not rows:
        return []
    header = [str(value).strip().lower() for value in rows[0]]
    try:
        sample_index = header.index("sampleid")
    except ValueError:
        try:
            sample_index = header.index("sample_id")
        except ValueError as error:
            raise ValueError("XLSX metadata must contain a SampleID column.") from error
    group_index = header.index("groupid") if "groupid" in header else header.index("condition")
    result = []
    for row in rows[1:]:
        sample_id = str((row[sample_index] if sample_index < len(row) else "") or "").strip()
        condition = str((row[group_index] if group_index < len(row) else "") or "").strip()
        if sample_id:
            if not condition:
                raise ValueError("Sample sheet row for {} has no condition.".format(sample_id))
            result.append({"sample_id": sample_id, "condition": condition, "variant_bam": ""})
    return result


def read_samples(project_path):
    metadata = Path(project_path) / "meta_data"
    candidates = [metadata / "sample_sheet.tsv", metadata / "samples.tsv"]
    for candidate in candidates:
        if candidate.exists():
            return _read_tsv_sample_sheet(candidate), candidate
    workbooks = sorted(metadata.glob("*.xlsx"))
    if workbooks:
        return _read_xlsx_sample_sheet(workbooks[0]), workbooks[0]
    raise ValueError("No sample_sheet.tsv or XLSX sample/group workbook was found in meta_data.")


def _validate_checksum_file(sample_directory, errors):
    manifest = sample_directory / "MD5.txt"
    if not manifest.exists():
        return
    for line in manifest.read_text(encoding="utf-8", errors="replace").splitlines():
        fields = line.strip().split()
        if len(fields) < 2:
            continue
        expected, filename = fields[0].lower(), fields[-1].lstrip("*")
        if Path(filename).name != filename or filename in (".", ".."):
            errors.append("MD5 manifest contains an unsafe filename.")
            continue
        target = sample_directory / filename
        if not target.exists():
            errors.append("MD5 manifest references a missing file: {}".format(target))
            continue
        digest = hashlib.md5()
        with target.open("rb") as handle:
            for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
                digest.update(chunk)
        if digest.hexdigest().lower() != expected:
            errors.append("MD5 mismatch: {}".format(target))


def validate_project(name, root=None, verify_checksums=False, reference_id=None, verify_reference_checksums=False):
    root_path = root or service_root()
    path = project_root(name, root=root_path)
    errors = []
    warnings = []
    if not path.is_dir():
        return {"project": name, "errors": ["Project directory does not exist."], "warnings": [], "samples": []}
    config = load_project_config(name, root=root_path)
    input_subdirectory = config.get("input_subdirectory", "")
    if input_subdirectory not in ("", "datasets"):
        errors.append("Unsupported project input directory.")
    data_path = path / "datasets" if input_subdirectory == "datasets" else path
    if data_path.is_symlink():
        errors.append("Project datasets directory cannot be a symbolic link.")
    for subdirectory in ("ref_genome", "meta_data", "raw_data"):
        required_path = data_path / subdirectory if subdirectory != "ref_genome" else path / subdirectory
        if not required_path.is_dir() or required_path.is_symlink():
            errors.append("Missing or unsafe required directory: {}".format(required_path.relative_to(path)))
    if errors:
        return {"project": name, "errors": errors, "warnings": warnings, "samples": []}
    selected_reference_id = str(config.get("reference_id", "") if reference_id is None else reference_id).strip()
    reference = None
    if not selected_reference_id:
        errors.append("Select a preinstalled reference before running this project.")
    else:
        try:
            reference = load_reference(
                selected_reference_id, root=root_path, verify_checksums=verify_reference_checksums,
            )
        except ValueError as error:
            errors.append(str(error))
    fasta = Path(reference["fasta"]) if reference else None
    annotation = Path(reference["annotation"]) if reference and reference.get("annotation") else None

    try:
        samples, metadata_path = read_samples(data_path)
    except (ValueError, OSError, KeyError, IndexError) as error:
        samples, metadata_path = [], None
        errors.append(str(error))
    seen = set()
    normalized_samples = []
    input_checks = []
    for sample in samples:
        try:
            sample_id = validate_project_name(sample.get("sample_id", ""))
        except ValueError as error:
            errors.append("Invalid sample ID '{}': {}".format(sample.get("sample_id", ""), error))
            continue
        if sample_id in seen:
            errors.append("Duplicate sample ID: {}".format(sample_id))
            continue
        seen.add(sample_id)
        sample_directory = data_path / "raw_data" / sample_id
        read1_candidates = [sample_directory / "{}_1.fq.gz".format(sample_id), sample_directory / "{}_1.fastq.gz".format(sample_id)]
        read2_candidates = [sample_directory / "{}_2.fq.gz".format(sample_id), sample_directory / "{}_2.fastq.gz".format(sample_id)]
        read1 = next((candidate for candidate in read1_candidates if candidate.is_file()), None)
        read2 = next((candidate for candidate in read2_candidates if candidate.is_file()), None)
        issues = []
        if not sample_directory.is_dir():
            issues.append("raw_data/{} folder is missing".format(sample_id))
        else:
            if not read1:
                issues.append("R1 missing (expected {}_1.fq.gz or {}_1.fastq.gz)".format(sample_id, sample_id))
            if not read2:
                issues.append("R2 missing (expected {}_2.fq.gz or {}_2.fastq.gz)".format(sample_id, sample_id))
            unexpected = sorted(
                item.name for item in sample_directory.iterdir()
                if item.is_file() and item not in (read1, read2) and item.name != "MD5.txt"
            )
            if unexpected:
                issues.append("Unmatched files: {}".format(", ".join(unexpected)))
        input_checks.append({
            "sample_id": sample_id, "condition": str(sample.get("condition", "")).strip(),
            "read1": read1.name if read1 else "", "read2": read2.name if read2 else "",
            "issues": issues,
        })
        if not read1 or not read2:
            errors.append("Sample {}: {}.".format(sample_id, "; ".join(issues)))
            continue
        if unexpected:
            errors.append("Sample {}: {}.".format(sample_id, "; ".join(issues)))
        if verify_checksums:
            _validate_checksum_file(sample_directory, errors)
        variant_bam = str(sample.get("variant_bam", "")).strip()
        if variant_bam:
            errors.append(
                "variant_bam is not supported by this RNA-only service; remove it for sample {}.".format(sample_id)
            )
        normalized_samples.append(
            {
                "sample_id": sample_id,
                "condition": str(sample.get("condition", "")).strip(),
                "read1": str(read1),
                "read2": str(read2),
            }
        )
    raw_data_directory = data_path / "raw_data"
    unlisted = sorted(item.name for item in raw_data_directory.iterdir() if item.is_dir() and item.name not in seen)
    if unlisted:
        errors.append("Folders in raw_data/ absent from sample sheet: {}.".format(", ".join(unlisted)))
    if not normalized_samples:
        errors.append("No valid samples were found.")
    if any(not sample["condition"] for sample in normalized_samples):
        warnings.append("One or more samples have no condition; differential expression will be skipped.")
    conditions = sorted({sample["condition"] for sample in normalized_samples if sample["condition"]})
    if len(conditions) < 2:
        warnings.append("At least two conditions are needed for differential expression.")
    if config.get("reference_condition") and config["reference_condition"] not in conditions:
        errors.append("Configured reference_condition is not present in sample metadata.")
    if int(config.get("ploidy", 2)) < 1:
        errors.append("ploidy must be at least 1.")
    if reference and int(config.get("ploidy", 2)) != int(reference["recommended_ploidy"]):
        warnings.append(
            "Project ploidy {} differs from the reference recommendation {} for {}.".format(
                config.get("ploidy", 2), reference["recommended_ploidy"], reference["label"],
            )
        )
    if reference and not reference.get("has_annotation"):
        warnings.append(
            "The selected reference is FASTA-only. STAR alignment, variants, ASE, and assembly are available; "
            "gene counts and differential expression are unavailable."
        )
    if int(config.get("star_bam_sort_ram", 16000000000)) < 1000000000:
        errors.append("star_bam_sort_ram must be at least 1000000000 bytes.")
    for key in ("alignment_parallel_samples", "variant_parallel_shards", "ase_parallel_samples"):
        value = int(config.get(key, 0))
        if value < 0 or value > 64:
            errors.append("{} must be 0 for automatic selection or an integer from 1 to 64.".format(key))
    if int(config.get("ase_java_memory_gb", 8)) < 2 or int(config.get("ase_java_memory_gb", 8)) > 64:
        errors.append("ase_java_memory_gb must be an integer from 2 to 64.")
    if str(config.get("unmapped_rna_mode", "rna_virus")) not in {"transcripts", "rna_virus"}:
        errors.append("unmapped_rna_mode must be transcripts or rna_virus.")
    if int(config.get("unmapped_rna_min_pairs", 1000)) < 1:
        errors.append("unmapped_rna_min_pairs must be at least 1.")
    if int(config.get("unmapped_rna_min_contig_length", 200)) < 100:
        errors.append("unmapped_rna_min_contig_length must be at least 100 bases.")
    if int(config.get("unmapped_rna_memory_gb", 48)) < 4:
        errors.append("unmapped_rna_memory_gb must be at least 4 GB.")
    if int(config.get("trinity_min_contig_length", 200)) < 100:
        errors.append("trinity_min_contig_length must be at least 100 bases.")
    if int(config.get("trinity_memory_gb", 0)) < 0:
        errors.append("trinity_memory_gb must be 0 for automatic selection or a positive integer.")
    if str(config.get("strandedness", "reverse")) not in {"unstranded", "forward", "reverse"}:
        errors.append("strandedness must be unstranded, forward, or reverse.")
    for key in (
        "unmapped_rna_host_min_identity",
        "unmapped_rna_host_min_query_coverage",
        "candidate_cross_min_identity",
        "candidate_cross_min_shorter_coverage",
    ):
        value = float(config.get(key, 0))
        if value <= 0 or value > 100:
            errors.append("{} must be greater than 0 and at most 100.".format(key))
    if str(config.get("genotype_vcf", "")).strip():
        errors.append(
            "Do not configure an arbitrary genotype_vcf path; stage genotype_VCF/dna_genotypes.vcf.gz instead."
        )
    ase_genotypes = inspect_ase_genotypes(
        path, [sample["sample_id"] for sample in normalized_samples], reference_fasta=fasta,
    )
    if ase_genotypes.get("vcf_filename") and not ase_genotypes.get("ready"):
        errors.append(ase_genotypes["error"])

    total_fastq_bytes = sum(Path(sample[key]).stat().st_size for sample in normalized_samples for key in ("read1", "read2"))
    return {
        "project": name,
        "project_root": str(path),
        "errors": errors,
        "warnings": warnings,
        "samples": normalized_samples,
        "input_checks": input_checks,
        "conditions": conditions,
        "ase_genotypes": ase_genotypes,
        "reference_id": selected_reference_id,
        "reference_label": reference["label"] if reference else "",
        "reference_source": "preinstalled" if reference else "",
        "reference_fasta": str(fasta) if fasta else "",
        "annotation_file": str(annotation) if annotation else "",
        "reference_has_annotation": bool(reference and reference.get("has_annotation")),
        "star_index": reference["star_index"] if reference else "",
        "reference_genome_bases": reference["genome_bases"] if reference else 0,
        "reference_star_sa_index_nbases": reference["star_sa_index_nbases"] if reference else 0,
        "reference_star_sjdb_overhang": reference["star_sjdb_overhang"] if reference else 0,
        "metadata_file": str(metadata_path) if metadata_path else "",
        "fastq_bytes": total_fastq_bytes,
        "fastq_size": human_size(total_fastq_bytes),
        "config": config,
    }


def write_normalized_sample_sheet(validation, destination):
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["sample_id", "condition", "read1", "read2", "variant_bam"], delimiter="\t")
        writer.writeheader()
        writer.writerows(validation["samples"])
    return path
