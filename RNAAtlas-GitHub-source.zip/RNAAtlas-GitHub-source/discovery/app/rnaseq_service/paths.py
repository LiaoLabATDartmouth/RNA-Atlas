"""Filesystem boundaries for the RNA-seq service."""

import os
import re
from pathlib import Path


DISCOVERY_ROOT = Path("/dartfs/rc/lab/L/LiaoC/Service_Account/RNAseq_atlas")
LOCAL_MOUNT_ROOT = Path("/Volumes/LiaoC/Service_Account/RNAseq_atlas")
PROJECT_NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")
PERSONAL_RESERVED_NAMES = {"app", "scripts", "shared", "datasets", "user_data", "projects"}


def service_root():
    configured = os.environ.get("LIAO_RNASEQ_ROOT", "").strip()
    if configured:
        return Path(configured).expanduser().resolve(strict=False)
    if DISCOVERY_ROOT.exists():
        return DISCOVERY_ROOT
    if LOCAL_MOUNT_ROOT.exists():
        return LOCAL_MOUNT_ROOT
    return DISCOVERY_ROOT


def shared_assets_root(root=None):
    configured = os.environ.get("LIAO_RNASEQ_SHARED_ROOT", "").strip()
    if not configured:
        return Path(root or service_root()).resolve(strict=False)
    if os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") != "1" or configured != str(DISCOVERY_ROOT):
        raise ValueError("Refusing an unapproved shared RNA-seq asset root.")
    return DISCOVERY_ROOT


def normalize(path):
    return Path(path).expanduser().resolve(strict=False)


def enforce_rnaseq_boundary(path, root=None):
    approved_root = normalize(root or service_root())
    resolved = normalize(path)
    if resolved != approved_root and approved_root not in resolved.parents:
        raise ValueError("Refusing path outside RNA-seq service root: {}".format(resolved))
    return resolved


def validate_project_name(name):
    value = str(name or "").strip()
    if not PROJECT_NAME_PATTERN.fullmatch(value):
        raise ValueError(
            "Project names must start with a letter or number and contain only letters, numbers, '.', '_' or '-'."
        )
    return value


def projects_root(root=None):
    approved_root = root or service_root()
    directory = approved_root if os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") == "1" else approved_root / "projects"
    return enforce_rnaseq_boundary(directory, root=approved_root)


def project_root(name, root=None):
    approved_root = root or service_root()
    safe_name = validate_project_name(name)
    if os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") == "1" and safe_name.lower() in PERSONAL_RESERVED_NAMES:
        raise ValueError("This folder name is reserved for RNA Atlas files.")
    return enforce_rnaseq_boundary(projects_root(approved_root) / safe_name, root=approved_root)


def intake_project_root(user_id, name, root=None):
    approved_root = root or service_root()
    identifier = str(user_id or "")
    if not re.fullmatch(r"[0-9a-f]{20}", identifier):
        raise ValueError("Invalid intake user ID.")
    base = Path(approved_root).resolve(strict=False)
    user_data = base / "user_data"
    user_directory = user_data / identifier
    destination = user_directory / validate_project_name(name)
    for directory in (user_data, user_directory, destination):
        if directory.is_symlink():
            raise ValueError("Intake folders cannot be symbolic links.")
    return enforce_rnaseq_boundary(destination, root=base)


def registry_root(root=None):
    approved_root = root or service_root()
    return enforce_rnaseq_boundary(approved_root / "shared" / "service_registry", root=approved_root)


def references_root(root=None):
    approved_root = root or service_root()
    return enforce_rnaseq_boundary(approved_root / "shared" / "references", root=approved_root)


def runtime_root(root=None):
    approved_root = shared_assets_root(root)
    return enforce_rnaseq_boundary(approved_root / "shared" / "runtime", root=approved_root)
