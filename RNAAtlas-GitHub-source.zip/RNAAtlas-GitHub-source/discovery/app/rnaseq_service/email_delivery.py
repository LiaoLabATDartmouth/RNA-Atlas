"""Generate and deliver job-completion notices through Dartmouth sendmail."""

import os
import shutil
import subprocess
from email.message import EmailMessage
from pathlib import Path

from .paths import enforce_rnaseq_boundary
from .utils import atomic_write_json, load_json, normalize_email, parse_bool, utc_now


def generate_notice(job, status, portal_url=""):
    output_root = Path(job["output_root"])
    report_url = "{}/jobs/{}".format(portal_url.rstrip("/"), job["job_id"]) if portal_url else ""
    message = EmailMessage()
    message["Subject"] = "RNA-seq job {}: {}".format(status.get("status", "finished"), job["project_name"])
    message["From"] = os.environ.get("LIAO_RNASEQ_MAIL_FROM", "liao-rnaseq@dartmouth.edu")
    message["To"] = job["submitter_email"]
    lines = [
        "Your RNA-seq job has finished.", "", "Project: {}".format(job["project_name"]),
        "Job: {}".format(job["job_id"]), "Status: {}".format(status.get("status", "unknown")),
        "Stage: {}".format(status.get("stage", "")), "Message: {}".format(status.get("message", "")),
        "Results directory: {}".format(output_root),
    ]
    if report_url:
        lines.append("Portal: {}".format(report_url))
    lines.extend(
        [
            "", "Research-use note: RNA-derived variants and allele-specific expression results require coverage, mapping-bias, and matched-DNA review.",
            "Large result files are not attached to email.",
        ]
    )
    message.set_content("\n".join(lines) + "\n")
    return message


def notify_job(job_config_path, exit_code=0):
    job_path = Path(job_config_path).resolve(strict=True)
    with job_path.open("r", encoding="utf-8") as handle:
        job = __import__("json").load(handle)
    output_root = enforce_rnaseq_boundary(job["output_root"], root=job["service_root"])
    delivery_path = output_root / "email_delivery.json"
    existing = load_json(delivery_path, default={}) or {}
    if existing.get("status") == "sent":
        return existing
    status_path = output_root / "status.json"
    status = load_json(status_path, default={}) or {}
    terminal_statuses = {"completed", "failed", "cancelled", "failed_unverified"}
    if not status or status.get("status") not in terminal_statuses:
        final_status = "failed_unverified" if int(exit_code) == 0 else "failed"
        status = {
            "status": final_status, "stage": "shell_exit",
            "message": "Pipeline process exited with code {} without a final pipeline status.".format(exit_code),
            "updated_at": utc_now(),
        }
        atomic_write_json(status_path, status)
    email = normalize_email(
        job["submitter_email"], allowed_domain=os.environ.get("LIAO_RNASEQ_ALLOWED_EMAIL_DOMAIN", "dartmouth.edu"),
        allow_external=parse_bool(os.environ.get("LIAO_RNASEQ_ALLOW_EXTERNAL_EMAIL"), False),
    )
    job["submitter_email"] = email
    message = generate_notice(job, status, portal_url=os.environ.get("LIAO_RNASEQ_PORTAL_URL", ""))
    notice_path = output_root / "completion_notice.eml"
    notice_path.write_bytes(message.as_bytes())
    method = os.environ.get("LIAO_RNASEQ_EMAIL_METHOD", "sendmail")
    payload = {"generated_at": utc_now(), "recipient": email, "method": method, "notice": str(notice_path)}
    if method == "dry-run":
        payload.update({"status": "not_sent", "detail": "Dry run only."})
    else:
        sendmail = os.environ.get("LIAO_RNASEQ_SENDMAIL_PATH", "/usr/sbin/sendmail")
        executable = sendmail if Path(sendmail).exists() else shutil.which(sendmail)
        if not executable:
            payload.update({"status": "failed", "detail": "sendmail executable not found"})
        else:
            completed = subprocess.run(
                [executable, "-t", "-oi"], input=message.as_bytes(), check=False,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            )
            payload.update(
                {
                    "status": "sent" if completed.returncode == 0 else "failed",
                    "detail": completed.stderr.decode("utf-8", errors="replace").strip(),
                }
            )
    atomic_write_json(delivery_path, payload)
    return payload
