"""Generate guarded Slurm jobs and submit them on Discovery."""

import hashlib
import math
import os
import re
import shlex
import shutil
import subprocess
import uuid
from pathlib import Path

from .genotypes import resolve_ase_genotypes
from .paths import enforce_rnaseq_boundary, runtime_root, service_root, shared_assets_root
from .preprocessing import normalize_preprocessing_options
from .project import load_project_config, validate_project
from .registry import create_job_record, list_jobs, update_job
from .utils import atomic_write_json, normalize_email, utc_now


def quote(value):
    return shlex.quote(str(value))


def scientific_int_option(requested, config, key, default, minimum, maximum):
    value = requested.get(key, config.get(key, default))
    if type(value) is int:
        parsed = value
    elif isinstance(value, str) and re.fullmatch(r"[+-]?\d+", value.strip()):
        parsed = int(value)
    else:
        raise ValueError("{} must be an integer.".format(key))
    if parsed < minimum or parsed > maximum:
        raise ValueError("{} must be between {} and {}.".format(key, minimum, maximum))
    return parsed


def scientific_float_option(requested, config, key, default, minimum, maximum, minimum_inclusive=True):
    value = requested.get(key, config.get(key, default))
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        raise ValueError("{} must be numeric.".format(key))
    below_minimum = parsed < minimum if minimum_inclusive else parsed <= minimum
    if not math.isfinite(parsed) or below_minimum or parsed > maximum:
        lower_text = "at least" if minimum_inclusive else "greater than"
        raise ValueError("{} must be {} {} and at most {}.".format(key, lower_text, minimum, maximum))
    return parsed


def validated_time_limit(value):
    text = str(value).strip()
    match = re.fullmatch(r"(?:(\d+)-)?(\d{1,3}):([0-5]\d):([0-5]\d)", text)
    if not match:
        raise ValueError("Run time must use Slurm days-hours:minutes:seconds or hours:minutes:seconds format.")
    days = int(match.group(1) or 0)
    hours = int(match.group(2))
    if match.group(1) and hours > 23:
        raise ValueError("Run time hours must be below 24 when days are specified.")
    total_seconds = ((days * 24 + hours) * 60 + int(match.group(3))) * 60 + int(match.group(4))
    if total_seconds < 3600 or total_seconds > 30 * 24 * 3600:
        raise ValueError("Run time must be between 1 hour and 30 days.")
    return text


def validated_memory(value):
    match = re.fullmatch(r"(\d+)G", str(value).strip())
    if not match or not 8 <= int(match.group(1)) <= 256:
        raise ValueError("RAM must be between 8G and 256G for the free-tier app.")
    return "{}G".format(int(match.group(1)))


def validated_threads(value):
    text = str(value).strip()
    if not re.fullmatch(r"\d+", text) or not 1 <= int(text) <= 32:
        raise ValueError("CPUs must be an integer from 1 to 32 for the free-tier app.")
    return int(text)


def create_code_snapshot(root_path, output_root):
    snapshot = output_root / "_code"
    sources = [
        *sorted((root_path / "app" / "rnaseq_service").glob("*.py")),
        root_path / "scripts" / "run_pipeline.py",
        root_path / "scripts" / "notify_job.py",
    ]
    if len(sources) < 3:
        raise ValueError("Personal pipeline source is incomplete.")
    snapshot.mkdir(mode=0o700)
    manifest = []
    for source in sources:
        if not source.is_file() or source.is_symlink():
            raise ValueError("Personal pipeline source is missing or symlinked: {}".format(source))
        relative = source.relative_to(root_path)
        destination = snapshot / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        contents = source.read_bytes()
        destination.write_bytes(contents)
        destination.chmod(0o444)
        manifest.append("{}  {}".format(hashlib.sha256(contents).hexdigest(), relative))
    manifest_path = snapshot / "SOURCE_SHA256SUMS.txt"
    manifest_path.write_text("\n".join(manifest) + "\n", encoding="utf-8")
    manifest_path.chmod(0o444)
    for directory in sorted((path for path in snapshot.rglob("*") if path.is_dir()), reverse=True):
        directory.chmod(0o555)
    snapshot.chmod(0o555)
    return snapshot, hashlib.sha256(manifest_path.read_bytes()).hexdigest()


def verify_code_snapshot(job, output_root):
    snapshot = output_root / "_code"
    if Path(job.get("code_root", "")) != snapshot or snapshot.is_symlink() or not snapshot.is_dir():
        raise ValueError("Prepared pipeline code snapshot is missing.")
    manifest_path = snapshot / "SOURCE_SHA256SUMS.txt"
    if manifest_path.is_symlink() or not manifest_path.is_file():
        raise ValueError("Prepared pipeline code manifest is missing.")
    if hashlib.sha256(manifest_path.read_bytes()).hexdigest() != job.get("code_manifest_sha256"):
        raise ValueError("Prepared pipeline code manifest changed.")
    expected = {"SOURCE_SHA256SUMS.txt"}
    for line in manifest_path.read_text(encoding="utf-8").splitlines():
        digest, separator, name = line.partition("  ")
        relative = Path(name)
        if (not separator or not re.fullmatch(r"[0-9a-f]{64}", digest)
                or relative.is_absolute() or ".." in relative.parts or not name.endswith(".py")
                or name in expected):
            raise ValueError("Prepared pipeline code manifest is invalid.")
        source = snapshot / relative
        if (any(parent.is_symlink() for parent in source.parents if parent == snapshot or snapshot in parent.parents)
                or source.is_symlink() or not source.is_file()
                or hashlib.sha256(source.read_bytes()).hexdigest() != digest):
            raise ValueError("Prepared pipeline code changed: {}".format(name))
        expected.add(name)
    actual = {str(path.relative_to(snapshot)) for path in snapshot.rglob("*") if path.is_file()}
    if actual != expected:
        raise ValueError("Prepared pipeline code snapshot has unexpected files.")


def render_k5start():
    return r'''SERVICE_KEYTAB=${LIAO_SERVICE_KEYTAB:-/dartfs/rc/lab/L/LiaoC/Service_Account/.secrets/f008qv8.keytab}
SERVICE_PRINCIPAL=${LIAO_SERVICE_PRINCIPAL:-f008qv8@KIEWIT.DARTMOUTH.EDU}
K5START_INTERVAL_MINUTES=${LIAO_K5START_INTERVAL_MINUTES:-60}

run_with_k5start() {
  if [[ -r "${SERVICE_KEYTAB}" ]] && command -v k5start >/dev/null 2>&1; then
    "$(command -v k5start)" -K "${K5START_INTERVAL_MINUTES}" -x -f "${SERVICE_KEYTAB}" "${SERVICE_PRINCIPAL}" -- "$@"
  else
    echo "WARNING: k5start/keytab unavailable; running without automatic Kerberos renewal." >&2
    "$@"
  fi
}'''


def render_slurm_script(job):
    options = job["options"]
    personal = job.get("personal_mode", False)
    mail_recipient = normalize_email(job.get("submitter_email"), allowed_domain="dartmouth.edu") if personal else ""
    code_root = job.get("code_root", job["service_root"])
    shared_root = job.get("shared_root", job["service_root"])
    return "\n".join(
        [
            "#!/usr/bin/env bash",
            "#SBATCH --job-name=rnaseq_{}".format(job["project_name"][:28]),
            "#SBATCH --partition={}".format(options["partition"]),
            "#SBATCH --cpus-per-task={}".format(options["threads"]),
            "#SBATCH --mem={}".format(options["memory"]),
            "#SBATCH --time={}".format(options["time_limit"]),
            "#SBATCH --output={}".format(job["output_root"] + "/90_logs/slurm_%j.out"),
            "#SBATCH --error={}".format(job["output_root"] + "/90_logs/slurm_%j.err"),
            "#SBATCH --mail-type=END,FAIL,TIME_LIMIT" if personal else "",
            "#SBATCH --mail-user={}".format(mail_recipient) if personal else "",
            "",
            "set -euo pipefail",
            "SERVICE_ROOT={}".format(quote(job["service_root"])),
            "PROJECT_NAME={}".format(quote(job["project_name"])),
            'PROJECT_BASE="${SERVICE_ROOT}/projects"',
            "CODE_ROOT={}".format(quote(code_root)),
            "SHARED_ROOT={}".format(quote(shared_root)),
            "PROJECT_ROOT={}".format(quote(job["project_root"])),
            "OUTPUT_ROOT={}".format(quote(job["output_root"])),
            "MODULE={}".format(quote(job.get("module", "legacy"))),
            "JOB_CONFIG={}".format(quote(job["job_config_path"])),
            "CODE_MANIFEST_SHA256={}".format(quote(job.get("code_manifest_sha256", ""))) if personal else "",
            "RUNTIME_ROOT={}".format(quote(job["runtime_root"])),
            "export PATH=\"${RUNTIME_ROOT}/bin:${PATH}\"",
            "export PYTHONPATH=\"${CODE_ROOT}/app${PYTHONPATH:+:${PYTHONPATH}}\"",
            "export PYTHONDONTWRITEBYTECODE=1" if personal else "",
            "export LIAO_RNASEQ_ROOT=\"${SERVICE_ROOT}\"",
            "export LIAO_RNASEQ_SHARED_ROOT=\"${SHARED_ROOT}\"" if personal else "",
            "export LIAO_RNASEQ_PERSONAL_MODE=1" if personal else "",
            "export LIAO_RNASEQ_EMAIL_METHOD=dry-run" if personal else "",
            "",
            "run_with_k5start() { \"$@\"; }" if personal else render_k5start(),
            "",
            r'''if [[ "${PROJECT_ROOT}" != "${PROJECT_BASE}/${PROJECT_NAME}" ]]; then
  echo "Refusing unexpected project path: ${PROJECT_ROOT}" >&2
  exit 2
fi
case "${MODULE}" in
  legacy) expected_root="${PROJECT_ROOT}/results/jobs" ;;
  differential_expression|rna_snv|ase|trinity) expected_root="${PROJECT_ROOT}/results/${MODULE}" ;;
  *) echo "Unsupported analysis module: ${MODULE}" >&2; exit 2 ;;
esac
if [[ "${OUTPUT_ROOT}" != "${expected_root}"/* ]]; then
  echo "Refusing output outside ${expected_root}: ${OUTPUT_ROOT}" >&2
  exit 2
fi

mkdir -p "${OUTPUT_ROOT}/90_logs"
cd "${OUTPUT_ROOT}"
NODE_TMP_BASE="/scratch/${USER:?}"
if [[ ! -d /scratch || ! -w /scratch ]]; then
  echo "Discovery node-local scratch is unavailable: /scratch" >&2
  exit 2
fi
if [[ -e "${NODE_TMP_BASE}" && ! -O "${NODE_TMP_BASE}" ]]; then
  echo "Refusing node-local scratch not owned by ${USER}: ${NODE_TMP_BASE}" >&2
  exit 2
fi
mkdir -p "${NODE_TMP_BASE}"
chmod 700 "${NODE_TMP_BASE}"
if [[ ! -d "${NODE_TMP_BASE}" || ! -w "${NODE_TMP_BASE}" ]]; then
  echo "The required Discovery node-local scratch directory is unavailable: ${NODE_TMP_BASE}" >&2
  exit 2
fi
NODE_TMP=$(mktemp -d "${NODE_TMP_BASE%/}/liao_rnaseq_${USER:-user}_${SLURM_JOB_ID:-$$}_XXXXXX")
ulimit -n 65536
cleanup() {
  exit_code=$?
  trap - EXIT
  if [[ -n "${NODE_TMP}" ]]; then rm -rf "${NODE_TMP}"; fi
  python3 "${CODE_ROOT}/scripts/notify_job.py" --job-config "${JOB_CONFIG}" --exit-code "${exit_code}" || true
  exit "${exit_code}"
}
trap cleanup EXIT
export TMPDIR="${NODE_TMP}"

__PERSONAL_CODE_CHECK__
__PERSONAL_KLIST_CHECK__
run_with_k5start python3 "${CODE_ROOT}/scripts/run_pipeline.py" --job-config "${JOB_CONFIG}"
'''.replace("__PERSONAL_CODE_CHECK__", "printf '%s  %s\\n' \"${CODE_MANIFEST_SHA256}\" \"${CODE_ROOT}/SOURCE_SHA256SUMS.txt\" | sha256sum -c >/dev/null && (cd \"${CODE_ROOT}\" && sha256sum -c SOURCE_SHA256SUMS.txt >/dev/null) || { echo 'Prepared pipeline code changed.' >&2; exit 2; }" if personal else "").replace("__PERSONAL_KLIST_CHECK__", "if ! klist -s; then echo 'No delegated Kerberos ticket on compute node.' >&2; exit 2; fi" if personal else ""),
            "",
        ]
    )


def prepare_job(project_name, submitter_email, requested_options=None, root=None):
    root_path = Path(root or service_root()).resolve(strict=True)
    active = [
        job for job in list_jobs(root=root_path, include_all=True)
        if job.get("project_name") == project_name and job.get("status") in {"submitted", "queued", "running"}
    ]
    if active:
        raise ValueError("Project already has an active job: {}".format(active[0]["job_id"]))
    requested = requested_options or {}
    project_config = load_project_config(project_name, root=root_path)
    selected_reference_id = str(
        requested.get("reference_id", project_config.get("reference_id", ""))
    ).strip()
    validation = validate_project(
        project_name, root=root_path, verify_checksums=False, reference_id=selected_reference_id,
    )
    if validation["errors"]:
        raise ValueError("Project validation failed: {}".format("; ".join(validation["errors"])))
    config = validation["config"]
    ploidy = scientific_int_option(requested, config, "ploidy", 2, 1, 16)
    run_differential_expression = bool(
        requested.get("run_differential_expression", config.get("run_differential_expression", True))
    )
    reference_condition = str(
        requested.get("reference_condition", config.get("reference_condition", ""))
    ).strip()
    if run_differential_expression:
        if not validation.get("reference_has_annotation"):
            raise ValueError(
                "Differential expression requires an expression-ready reference with a matching GTF/GFF3 annotation."
            )
        if len(validation["conditions"]) < 2:
            raise ValueError("Differential expression requires at least two groups.")
        if reference_condition not in validation["conditions"]:
            raise ValueError("Select a reference group present in the sample metadata.")
    run_unmapped_rna = bool(requested.get("run_unmapped_rna", config.get("run_unmapped_rna", False)))
    run_unmapped_trinity = bool(
        requested.get("run_unmapped_trinity", config.get("run_unmapped_trinity", False))
    )
    if validation.get("read_layout") == "single" and (run_unmapped_rna or run_unmapped_trinity):
        raise ValueError("Mapping-first candidate workflows still require paired-end reads.")
    unmapped_rna_mode = str(requested.get("unmapped_rna_mode", config.get("unmapped_rna_mode", "rna_virus")))
    if unmapped_rna_mode not in {"transcripts", "rna_virus"}:
        raise ValueError("Unmapped RNA mode must be transcripts or rna_virus.")
    run_rna_variants = bool(
        requested.get("run_rna_variants", config.get("run_rna_variants", True))
    )
    run_ase = bool(
        requested.get("run_ase", config.get("run_ase", True))
    )
    ase_source = str(requested.get("ase_source", config.get("ase_source", "rna_discovered"))).strip()
    if ase_source not in {"rna_discovered", "external_dna_vcf"}:
        raise ValueError("ASE source must be rna_discovered or external_dna_vcf.")
    if run_ase and ploidy < 2:
        raise ValueError("Allele-specific expression requires a diploid or polyploid project (ploidy at least 2).")
    if run_ase and ase_source == "rna_discovered" and not run_rna_variants:
        raise ValueError("RNA-discovered ASE requires RNA variant discovery to be enabled.")
    ase_genotypes = None
    if run_ase and ase_source == "external_dna_vcf":
        ase_genotypes = resolve_ase_genotypes(
            validation["project_root"], [sample["sample_id"] for sample in validation["samples"]],
            reference_fasta=validation["reference_fasta"],
        )
    preprocessing_options = normalize_preprocessing_options(
        requested, config=config, layout="single-end" if validation.get("read_layout") == "single" else "paired-end",
    )
    discovery_options = {
        "padj_cutoff": scientific_float_option(requested, config, "padj_cutoff", 0.05, 0.0, 1.0, minimum_inclusive=False),
        "log2fc_cutoff": scientific_float_option(requested, config, "log2fc_cutoff", 2.0, 0.0, 20.0),
        "variant_min_depth": scientific_int_option(requested, config, "variant_min_depth", 10, 1, 10000),
        "variant_min_quality": scientific_float_option(requested, config, "variant_min_quality", 20.0, 0.0, 1000.0),
        "ase_min_depth": scientific_int_option(requested, config, "ase_min_depth", 20, 1, 10000),
        "ase_min_allele_count": scientific_int_option(requested, config, "ase_min_allele_count", 3, 0, 1000),
        "trinity_min_contig_length": scientific_int_option(
            requested, config, "trinity_min_contig_length", 200, 100, 10000,
        ),
        "trinity_normalize_reads": bool(
            requested.get("trinity_normalize_reads", config.get("trinity_normalize_reads", True))
        ),
        "unmapped_rna_min_pairs": scientific_int_option(
            requested, config, "unmapped_rna_min_pairs", 1000, 1, 1000000000,
        ),
        "unmapped_rna_min_contig_length": scientific_int_option(
            requested, config, "unmapped_rna_min_contig_length", 200, 100, 10000,
        ),
        "unmapped_rna_host_min_identity": scientific_float_option(
            requested, config, "unmapped_rna_host_min_identity", 90.0, 50.0, 100.0,
        ),
        "unmapped_rna_host_min_query_coverage": scientific_float_option(
            requested, config, "unmapped_rna_host_min_query_coverage", 80.0, 10.0, 100.0,
        ),
        "unmapped_rna_blast_evalue": scientific_float_option(
            requested, config, "unmapped_rna_blast_evalue", 1e-10, 0.0, 1.0, minimum_inclusive=False,
        ),
        "candidate_cross_min_identity": scientific_float_option(
            requested, config, "candidate_cross_min_identity", 95.0, 50.0, 100.0,
        ),
        "candidate_cross_min_shorter_coverage": scientific_float_option(
            requested, config, "candidate_cross_min_shorter_coverage", 80.0, 10.0, 100.0,
        ),
    }
    options = {
        "threads": validated_threads(requested.get("threads", config.get("threads", 16))),
        "memory": validated_memory(requested.get("memory", config.get("memory", "64G"))),
        "time_limit": validated_time_limit(requested.get("time_limit", config.get("time_limit", "48:00:00"))),
        "partition": str(requested.get("partition", config.get("partition", "standard"))),
        "verify_md5": bool(requested.get("verify_md5", config.get("verify_md5", True))),
        "validate_fastq_structure": bool(
            requested.get("validate_fastq_structure", config.get("validate_fastq_structure", True))
        ),
        "reference_id": selected_reference_id,
        "ploidy": ploidy,
        "run_differential_expression": run_differential_expression,
        "reference_condition": reference_condition if run_differential_expression else "",
        "run_rna_variants": run_rna_variants,
        "run_ase": run_ase,
        "ase_source": ase_source,
        "run_microbiome": bool(requested.get("run_microbiome", config.get("run_microbiome", False))),
        "run_unmapped_rna": run_unmapped_rna,
        "run_unmapped_trinity": run_unmapped_trinity,
        "unmapped_rna_mode": unmapped_rna_mode,
        "run_trinity": bool(requested.get("run_trinity", config.get("run_trinity", False))),
    }
    options.update(preprocessing_options)
    options.update(discovery_options)
    if ase_genotypes:
        options.update(
            {
                "ase_genotype_vcf": ase_genotypes["vcf_path"],
                "ase_genotype_sample_map": ase_genotypes["sample_map"],
                "ase_genotype_map": ase_genotypes["map_path"],
            }
        )
    selected_modules = [name for name, enabled in (
        ("differential_expression", run_differential_expression),
        ("rna_snv", run_rna_variants),
        ("ase", run_ase),
        ("trinity", options["run_trinity"]),
    ) if enabled]
    module = selected_modules[0] if len(selected_modules) == 1 and not any(
        options[key] for key in ("run_microbiome", "run_unmapped_rna", "run_unmapped_trinity")
    ) else "legacy"
    job_id = "{}-{}".format(utc_now()[:10].replace("-", ""), uuid.uuid4().hex[:12])
    output_root = enforce_rnaseq_boundary(
        Path(validation["project_root"]) / "results" / ("jobs" if module == "legacy" else module) / job_id,
        root=root_path,
    )
    output_root.mkdir(parents=True, exist_ok=False)
    (output_root / "90_logs").mkdir()
    personal_mode = os.environ.get("LIAO_RNASEQ_PERSONAL_MODE") == "1"
    code_root, code_manifest_sha256 = create_code_snapshot(root_path, output_root) if personal_mode else (root_path, "")
    job_config_path = output_root / "job_config.json"
    job = {
        "job_id": job_id, "module": module, "project_name": project_name, "project_root": validation["project_root"],
        "service_root": str(root_path), "runtime_root": str(runtime_root(root_path)), "output_root": str(output_root),
        "code_root": str(code_root), "code_manifest_sha256": code_manifest_sha256,
        "shared_root": str(shared_assets_root(root_path)),
        "personal_mode": personal_mode,
        "job_config_path": str(job_config_path), "submitter_email": submitter_email, "options": options,
        "status": "prepared", "status_path": str(output_root / "status.json"), "created_at": utc_now(),
        "sample_count": len(validation["samples"]), "conditions": validation["conditions"], "warnings": validation["warnings"],
    }
    atomic_write_json(job_config_path, job)
    slurm_path = output_root / "rnaseq.sbatch"
    slurm_path.write_text(render_slurm_script(job), encoding="utf-8")
    slurm_path.chmod(0o750)
    job["slurm_script"] = str(slurm_path)
    if job["personal_mode"]:
        job["manual_submit_command"] = "python3 {} {}".format(
            shlex.quote(str(root_path / "scripts" / "submit_prepared.py")), shlex.quote(job_id),
        )
        job["slurm_script_sha256"] = hashlib.sha256(slurm_path.read_bytes()).hexdigest()
        job["job_config_sha256"] = hashlib.sha256(job_config_path.read_bytes()).hexdigest()
    create_job_record(job, root=root_path)
    return job


def submit_job(job, root=None):
    sbatch = shutil.which("sbatch")
    if not sbatch:
        return update_job(job["job_id"], {"status": "prepared", "message": "sbatch is unavailable; submit the generated script on Discovery."}, root=root)
    command = [sbatch]
    if job.get("personal_mode"):
        recipient = normalize_email(job.get("submitter_email"), allowed_domain="dartmouth.edu")
        command.extend(["--mail-type=END,FAIL,TIME_LIMIT", "--mail-user={}".format(recipient)])
    command.append(job["slurm_script"])
    completed = subprocess.run(
        command, check=False, universal_newlines=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    if completed.returncode != 0:
        return update_job(
            job["job_id"], {"status": "submission_failed", "message": completed.stderr.strip()}, root=root,
        )
    fields = completed.stdout.strip().split()
    slurm_job_id = fields[-1] if fields else ""
    return update_job(
        job["job_id"], {"status": "submitted", "slurm_job_id": slurm_job_id, "message": completed.stdout.strip()}, root=root,
    )
