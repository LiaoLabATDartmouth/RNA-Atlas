"""Combine STAR ReadsPerGene output into count and QC matrices.

This preserves the supplied Step4 logic while making sample order deterministic,
validating rows, and writing tab-delimited files for R.
"""

import csv
from pathlib import Path


STAR_QC_ROWS = {
    "N_unmapped": "unmapped",
    "N_multimapping": "multimapping",
    "N_noFeature": "no_feature",
    "N_ambiguous": "ambiguous",
}


def read_star_counts(path, column_index):
    genes = {}
    qc = {}
    with Path(path).open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle, delimiter="\t")
        for row_number, row in enumerate(reader, start=1):
            if len(row) <= column_index:
                raise ValueError("{} row {} has too few columns.".format(path, row_number))
            feature = row[0]
            try:
                count = int(row[column_index])
            except ValueError as error:
                raise ValueError("{} row {} contains a non-integer count.".format(path, row_number)) from error
            if feature.startswith("N_"):
                qc[STAR_QC_ROWS.get(feature, feature)] = count
            else:
                genes[feature] = count
    qc["assigned_gene_reads"] = sum(genes.values())
    return genes, qc


def combine_star_counts(sample_directories, strandedness, output_directory):
    column_by_strand = {"unstranded": 1, "forward": 2, "reverse": 3}
    try:
        column_index = column_by_strand[str(strandedness).lower()]
    except KeyError as error:
        raise ValueError("strandedness must be unstranded, forward, or reverse") from error
    sample_names = sorted(sample_directories)
    if not sample_names:
        raise ValueError("No STAR sample directories were provided.")
    gene_counts = {}
    qc_counts = {}
    all_genes = set()
    for sample_name in sample_names:
        count_path = Path(sample_directories[sample_name]) / "ReadsPerGene.out.tab"
        if not count_path.exists():
            raise ValueError("Missing STAR gene-count output: {}".format(count_path))
        genes, qc = read_star_counts(count_path, column_index)
        gene_counts[sample_name] = genes
        qc_counts[sample_name] = qc
        all_genes.update(genes)

    output_root = Path(output_directory)
    output_root.mkdir(parents=True, exist_ok=True)
    counts_path = output_root / "raw_gene_counts.tsv"
    qc_path = output_root / "star_count_qc.tsv"
    with counts_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow(["gene_id"] + sample_names)
        for gene_id in sorted(all_genes):
            writer.writerow([gene_id] + [gene_counts[sample].get(gene_id, 0) for sample in sample_names])
    all_metrics = sorted({metric for sample in sample_names for metric in qc_counts[sample]})
    with qc_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow(["qc_metric"] + sample_names)
        for metric in all_metrics:
            writer.writerow([metric] + [qc_counts[sample].get(metric, 0) for sample in sample_names])
    return {"counts": str(counts_path), "qc": str(qc_path), "samples": sample_names, "genes": len(all_genes)}

