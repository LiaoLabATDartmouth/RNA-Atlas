"""Guarded staging locations for administrator-installed reference packages."""

from pathlib import Path

from .paths import enforce_rnaseq_boundary, service_root
from .references import FASTA_SUFFIXES, validate_reference_id


ANNOTATION_SUFFIXES = (".gtf", ".gff", ".gff3")


def reference_inputs_root(root=None):
    root_path = Path(root or service_root()).resolve(strict=False)
    return enforce_rnaseq_boundary(root_path / "shared" / "reference_inputs", root=root_path)


def reference_input_directory(reference_id, root=None):
    root_path = Path(root or service_root()).resolve(strict=False)
    safe_id = validate_reference_id(reference_id)
    return enforce_rnaseq_boundary(reference_inputs_root(root_path) / safe_id, root=root_path)


def inspect_reference_input(reference_id, root=None, require_annotation=True):
    directory = reference_input_directory(reference_id, root=root)
    fasta_files = []
    annotation_files = []
    if directory.is_dir():
        for path in sorted(directory.iterdir(), key=lambda item: item.name.lower()):
            if not path.is_file() or path.name.startswith("."):
                continue
            suffix = path.suffix.lower()
            if suffix in FASTA_SUFFIXES:
                fasta_files.append(path)
            if suffix in ANNOTATION_SUFFIXES:
                annotation_files.append(path)
    errors = []
    if len(fasta_files) != 1:
        errors.append(
            "Stage exactly one uncompressed FASTA (.fa, .fasta, or .fna); found {}.".format(len(fasta_files))
        )
    if len(annotation_files) > 1:
        errors.append("Stage at most one matching GTF, GFF, or GFF3 annotation; found {}.".format(len(annotation_files)))
    elif require_annotation and not annotation_files:
        if len(fasta_files) == 1:
            errors.append(
                "This expression-ready reference requires one matching GTF/GFF3 annotation."
            )
        else:
            errors.append("Stage exactly one matching GTF, GFF, or GFF3 annotation; found 0.")
    return {
        "reference_id": validate_reference_id(reference_id),
        "directory": str(directory),
        "exists": directory.is_dir(),
        "ready": not errors,
        "errors": errors,
        "fasta": str(fasta_files[0]) if len(fasta_files) == 1 else "",
        "fasta_filename": fasta_files[0].name if len(fasta_files) == 1 else "",
        "annotation": str(annotation_files[0]) if len(annotation_files) == 1 else "",
        "annotation_filename": annotation_files[0].name if len(annotation_files) == 1 else "",
        "has_annotation": len(annotation_files) == 1,
    }


def create_reference_input(reference_id, root=None, require_annotation=True):
    directory = reference_input_directory(reference_id, root=root)
    directory.mkdir(parents=True, exist_ok=True)
    instructions = directory / "README.txt"
    if not instructions.exists():
        instructions.write_text(
            "Stage exactly one uncompressed genome FASTA (.fa/.fasta/.fna). For an expression-ready "
            "reference, also stage exactly one matching annotation (.gtf/.gff/.gff3). In FASTA-only "
            "mode, do not stage an annotation. The service generates the FASTA index, sequence "
            "dictionary, STAR index, checksums, and immutable reference manifest.\n"
            "FASTA-only references support alignment, variants, ASE, and assembly, but not gene counts "
            "or differential expression.\n",
            encoding="utf-8",
        )
    return inspect_reference_input(reference_id, root=root, require_annotation=require_annotation)


def list_reference_inputs(root=None):
    directory = reference_inputs_root(root)
    if not directory.is_dir():
        return []
    records = []
    for path in sorted(directory.iterdir(), key=lambda item: item.name.lower()):
        if not path.is_dir() or path.name.startswith("."):
            continue
        try:
            records.append(inspect_reference_input(path.name, root=root))
        except ValueError:
            continue
    return records
