"""Validated FASTQ QC and conservative preprocessing settings."""

import re

from .utils import bounded_int


TRIMMING_MODES = {"auto", "none", "custom"}
LIBRARY_TYPES = {"standard_bulk", "custom_bulk", "small_rna", "three_prime", "five_prime", "single_cell"}
SUPPORTED_LIBRARY_TYPES = {"standard_bulk", "custom_bulk"}
ADAPTER_HANDLING = {"detect", "provided", "none"}
SELECTION_METHODS = {"unknown", "poly_a", "rrna_depletion", "none", "other"}
STRANDEDNESS_VALUES = {"project_default", "unstranded", "forward", "reverse"}
UMI_STATUS_VALUES = {"none", "unknown", "present"}
DNA_SEQUENCE = re.compile(r"^[ACGTN]+$", re.IGNORECASE)


def _bounded_text(value, label, maximum):
    text = str(value or "").strip()
    if len(text) > maximum:
        raise ValueError("{} must be at most {} characters.".format(label, maximum))
    return text


def _adapter_sequence(value, label):
    sequence = str(value or "").strip().upper()
    if not sequence:
        return ""
    if len(sequence) < 6 or len(sequence) > 200 or not DNA_SEQUENCE.match(sequence):
        raise ValueError("{} must contain 6-200 DNA bases using A, C, G, T, or N.".format(label))
    return sequence


def normalize_preprocessing_options(requested, config=None):
    defaults = config or {}
    mode = str(requested.get("trimming_mode", defaults.get("trimming_mode", "auto"))).strip().lower()
    if mode not in TRIMMING_MODES:
        raise ValueError("Trimming mode must be auto, none, or custom.")
    library_type = str(requested.get("library_type", defaults.get("library_type", "standard_bulk"))).strip().lower()
    if library_type not in LIBRARY_TYPES:
        raise ValueError("Unsupported library type selection.")
    if library_type not in SUPPORTED_LIBRARY_TYPES:
        raise ValueError(
            "This bulk RNA-seq workflow does not support {} preprocessing. Use a dedicated library-specific workflow.".format(
                library_type.replace("_", " ")
            )
        )
    if mode == "auto" and library_type != "standard_bulk":
        raise ValueError("Automatic trimming is restricted to standard bulk paired-end RNA-seq libraries.")
    preparation = _bounded_text(
        requested.get("library_prep", defaults.get("library_prep", "")), "Library preparation", 240,
    )
    if mode == "custom" and not preparation:
        raise ValueError("Custom preprocessing requires the library kit or preparation name.")
    adapter_handling = str(
        requested.get("adapter_handling", defaults.get("adapter_handling", "detect"))
    ).strip().lower()
    if adapter_handling not in ADAPTER_HANDLING:
        raise ValueError("Adapter handling must be detect, provided, or none.")
    adapter_read1 = _adapter_sequence(
        requested.get("adapter_read1", defaults.get("adapter_read1", "")), "R1 adapter sequence",
    )
    adapter_read2 = _adapter_sequence(
        requested.get("adapter_read2", defaults.get("adapter_read2", "")), "R2 adapter sequence",
    )
    if mode == "custom" and adapter_handling == "provided" and (not adapter_read1 or not adapter_read2):
        raise ValueError("Provide both R1 and R2 adapter sequences when custom adapter sequences are selected.")
    if mode != "custom":
        adapter_handling = "detect" if mode == "auto" else "none"
        adapter_read1 = ""
        adapter_read2 = ""
    umi_status = str(requested.get("umi_status", defaults.get("umi_status", "unknown"))).strip().lower()
    if umi_status not in UMI_STATUS_VALUES:
        raise ValueError("UMI status must be none, unknown, or present.")
    if umi_status == "present":
        raise ValueError(
            "UMI-aware extraction and molecule-level counting are not implemented; do not process this library as ordinary bulk RNA-seq."
        )
    selection_method = str(
        requested.get("selection_method", defaults.get("selection_method", "unknown"))
    ).strip().lower()
    if selection_method not in SELECTION_METHODS:
        raise ValueError("Unsupported RNA selection method.")
    strandedness = str(
        requested.get("strandedness", defaults.get("strandedness", "project_default"))
    ).strip().lower()
    if strandedness not in STRANDEDNESS_VALUES:
        raise ValueError("Strandedness must be project_default, unstranded, forward, or reverse.")
    return {
        "trimming_mode": mode,
        "library_type": library_type,
        "library_prep": preparation,
        "adapter_handling": adapter_handling,
        "adapter_read1": adapter_read1,
        "adapter_read2": adapter_read2,
        "trim_quality_tails": bool(
            requested.get("trim_quality_tails", defaults.get("trim_quality_tails", True))
        ),
        "trim_quality_threshold": bounded_int(
            requested.get("trim_quality_threshold", defaults.get("trim_quality_threshold", 15)), 15, 5, 30,
        ),
        "trim_minimum_length": bounded_int(
            requested.get("trim_minimum_length", defaults.get("trim_minimum_length", 30)), 30, 15, 500,
        ),
        "trim_front_read1": bounded_int(
            requested.get("trim_front_read1", defaults.get("trim_front_read1", 0)), 0, 0, 100,
        ),
        "trim_front_read2": bounded_int(
            requested.get("trim_front_read2", defaults.get("trim_front_read2", 0)), 0, 0, 100,
        ),
        "trim_tail_read1": bounded_int(
            requested.get("trim_tail_read1", defaults.get("trim_tail_read1", 0)), 0, 0, 100,
        ),
        "trim_tail_read2": bounded_int(
            requested.get("trim_tail_read2", defaults.get("trim_tail_read2", 0)), 0, 0, 100,
        ),
        "umi_status": umi_status,
        "selection_method": selection_method,
        "strandedness": strandedness,
        "prior_processing": _bounded_text(
            requested.get("prior_processing", defaults.get("prior_processing", "")), "Prior processing description", 500,
        ),
    }


def fastp_command(executable, sample, output_read1, output_read2, json_report, html_report, options, threads):
    command = [
        str(executable),
        "--in1", str(sample["read1"]), "--in2", str(sample["read2"]),
        "--out1", str(output_read1), "--out2", str(output_read2),
        "--json", str(json_report), "--html", str(html_report),
        "--thread", str(max(1, int(threads))),
        "--qualified_quality_phred", str(options["trim_quality_threshold"]),
        "--unqualified_percent_limit", "40",
        "--length_required", str(options["trim_minimum_length"]),
        "--disable_trim_poly_g",
    ]
    if options.get("trim_quality_tails", True):
        command.extend(
            [
                "--cut_right", "--cut_right_window_size", "4",
                "--cut_right_mean_quality", str(options["trim_quality_threshold"]),
            ]
        )
    adapter_handling = options.get("adapter_handling", "detect")
    if adapter_handling == "provided":
        command.extend(
            [
                "--adapter_sequence", options["adapter_read1"],
                "--adapter_sequence_r2", options["adapter_read2"],
            ]
        )
    elif adapter_handling == "detect":
        command.append("--detect_adapter_for_pe")
    else:
        command.append("--disable_adapter_trimming")
    for flag, key in (
        ("--trim_front1", "trim_front_read1"),
        ("--trim_front2", "trim_front_read2"),
        ("--trim_tail1", "trim_tail_read1"),
        ("--trim_tail2", "trim_tail_read2"),
    ):
        command.extend([flag, str(int(options.get(key, 0)))])
    return command
