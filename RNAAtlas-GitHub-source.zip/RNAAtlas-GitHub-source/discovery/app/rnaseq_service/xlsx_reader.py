"""Read the first two columns of a simple XLSX worksheet with the standard library."""

import re
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path


MAIN_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
REL_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
PACKAGE_REL_NS = "{http://schemas.openxmlformats.org/package/2006/relationships}"


def _column_index(reference):
    letters = re.match(r"[A-Z]+", reference or "")
    if not letters:
        return 0
    index = 0
    for letter in letters.group(0):
        index = index * 26 + ord(letter) - ord("A") + 1
    return index - 1


def _shared_strings(archive):
    try:
        payload = archive.read("xl/sharedStrings.xml")
    except KeyError:
        return []
    root = ET.fromstring(payload)
    values = []
    for item in root.findall("{}si".format(MAIN_NS)):
        values.append("".join(node.text or "" for node in item.iter("{}t".format(MAIN_NS))))
    return values


def _first_sheet_path(archive):
    workbook = ET.fromstring(archive.read("xl/workbook.xml"))
    first_sheet = workbook.find("{0}sheets/{0}sheet".format(MAIN_NS))
    if first_sheet is None:
        raise ValueError("Workbook contains no worksheets.")
    relationship_id = first_sheet.attrib.get("{}id".format(REL_NS))
    relationships = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
    for relationship in relationships.findall("{}Relationship".format(PACKAGE_REL_NS)):
        if relationship.attrib.get("Id") == relationship_id:
            target = relationship.attrib["Target"].lstrip("/")
            return target if target.startswith("xl/") else "xl/{}".format(target)
    raise ValueError("Could not resolve the first worksheet.")


def read_rows(path):
    source = Path(path)
    with zipfile.ZipFile(str(source)) as archive:
        shared_strings = _shared_strings(archive)
        sheet = ET.fromstring(archive.read(_first_sheet_path(archive)))
        rows = []
        for row in sheet.findall(".//{}row".format(MAIN_NS)):
            values = {}
            for cell in row.findall("{}c".format(MAIN_NS)):
                reference = cell.attrib.get("r", "")
                value_node = cell.find("{}v".format(MAIN_NS))
                inline_node = cell.find("{}is/{}t".format(MAIN_NS, MAIN_NS))
                value = ""
                if inline_node is not None:
                    value = inline_node.text or ""
                elif value_node is not None:
                    value = value_node.text or ""
                    if cell.attrib.get("t") == "s":
                        value = shared_strings[int(value)]
                values[_column_index(reference)] = value
            if values:
                max_index = max(values)
                rows.append([values.get(index, "") for index in range(max_index + 1)])
        return rows

