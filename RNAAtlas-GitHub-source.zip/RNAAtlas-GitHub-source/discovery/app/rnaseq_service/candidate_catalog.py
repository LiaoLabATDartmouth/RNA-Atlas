"""Build a cross-assembler catalog of non-reference RNA candidates."""

import csv
from pathlib import Path

from .unmapped_rna import read_fasta


CATALOG_FIELDS = [
    "candidate_id",
    "detection_class",
    "trinity_contig_ids",
    "rnaspades_contig_ids",
    "rnaspades_samples",
    "representative_source",
    "representative_contig_id",
    "representative_length",
    "gc_percent",
    "cross_assembler_best_opposite_contig_id",
    "cross_assembler_best_percent_identity",
    "cross_assembler_best_shorter_contig_coverage",
    "cross_assembler_best_evalue",
    "classification",
    "viral_accession",
    "viral_scientific_name",
    "viral_percent_identity",
    "viral_query_coverage",
    "viral_evalue",
    "viral_bitscore",
    "viral_title",
]

TRINITY_STRATEGY_FIELDS = [
    "comparison_id",
    "detection_class",
    "assemble_first_trinity_contig_ids",
    "map_first_trinity_contig_ids",
    "map_first_assembly_scope",
    "representative_strategy",
    "representative_contig_id",
    "representative_length",
    "gc_percent",
    "best_opposite_trinity_contig_id",
    "best_percent_identity",
    "best_shorter_contig_coverage",
    "best_evalue",
]


def _write_fasta_record(handle, name, sequence):
    handle.write(">{}\n".format(name))
    for start in range(0, len(sequence), 80):
        handle.write(sequence[start:start + 80] + "\n")


def collect_candidate_records(trinity_fasta, rnaspades_fastas, trinity_output, rnaspades_output):
    records = {}
    trinity_path = Path(trinity_output)
    rnaspades_path = Path(rnaspades_output)
    trinity_path.parent.mkdir(parents=True, exist_ok=True)
    rnaspades_path.parent.mkdir(parents=True, exist_ok=True)
    with trinity_path.open("w", encoding="utf-8") as output:
        if trinity_fasta and Path(trinity_fasta).is_file():
            for number, (name, description, sequence) in enumerate(read_fasta(trinity_fasta), start=1):
                key = "TRINITY_CAND_{:07d}".format(number)
                sequence = sequence.upper()
                records[key] = {
                    "key": key,
                    "source": "trinity",
                    "sample_id": "",
                    "contig_id": name,
                    "description": description,
                    "sequence": sequence,
                    "length": len(sequence),
                }
                _write_fasta_record(output, key, sequence)
    with rnaspades_path.open("w", encoding="utf-8") as output:
        number = 0
        for sample_id, fasta_path in sorted(rnaspades_fastas or []):
            if not Path(fasta_path).is_file():
                continue
            for name, description, sequence in read_fasta(fasta_path):
                number += 1
                key = "RNASPADES_CAND_{:07d}".format(number)
                sequence = sequence.upper()
                records[key] = {
                    "key": key,
                    "source": "rnaspades",
                    "sample_id": sample_id,
                    "contig_id": name,
                    "description": description,
                    "sequence": sequence,
                    "length": len(sequence),
                }
                _write_fasta_record(output, key, sequence)
    return records


def _covered_bases(intervals):
    merged = []
    for start, end in sorted(intervals):
        if merged and start <= merged[-1][1] + 1:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    return sum(end - start + 1 for start, end in merged)


def _parse_cross_assembler_pairs(path, minimum_hsp_identity=None):
    fields = [
        "qseqid", "qlen", "sseqid", "slen", "pident", "length", "qstart", "qend",
        "sstart", "send", "evalue", "bitscore",
    ]
    grouped = {}
    blast_path = Path(path)
    if not blast_path.is_file():
        return []
    with blast_path.open("r", encoding="utf-8", errors="replace") as handle:
        reader = csv.reader(handle, delimiter="\t")
        for values in reader:
            if not values or values[0].startswith("#"):
                continue
            row = dict(zip(fields, values))
            if minimum_hsp_identity is not None and float(row["pident"]) < float(minimum_hsp_identity):
                continue
            key = (row["qseqid"], row["sseqid"])
            item = grouped.setdefault(
                key,
                {
                    "trinity_id": row["qseqid"],
                    "rnaspades_id": row["sseqid"],
                    "trinity_length": int(row["qlen"]),
                    "rnaspades_length": int(row["slen"]),
                    "trinity_intervals": [],
                    "rnaspades_intervals": [],
                    "identity_bases": 0.0,
                    "aligned_bases": 0,
                    "evalue": float(row["evalue"]),
                    "bitscore": 0.0,
                },
            )
            query_start, query_end = sorted((int(row["qstart"]), int(row["qend"])))
            subject_start, subject_end = sorted((int(row["sstart"]), int(row["send"])))
            alignment_length = int(row["length"])
            item["trinity_intervals"].append((query_start, query_end))
            item["rnaspades_intervals"].append((subject_start, subject_end))
            item["identity_bases"] += float(row["pident"]) * alignment_length / 100.0
            item["aligned_bases"] += alignment_length
            item["evalue"] = min(item["evalue"], float(row["evalue"]))
            item["bitscore"] = max(item["bitscore"], float(row["bitscore"]))
    matches = []
    for item in grouped.values():
        trinity_coverage = 100.0 * _covered_bases(item.pop("trinity_intervals")) / item["trinity_length"]
        rnaspades_coverage = 100.0 * _covered_bases(item.pop("rnaspades_intervals")) / item["rnaspades_length"]
        shorter_coverage = (
            trinity_coverage
            if item["trinity_length"] <= item["rnaspades_length"]
            else rnaspades_coverage
        )
        item["percent_identity"] = 100.0 * item.pop("identity_bases") / item.pop("aligned_bases")
        item["trinity_coverage"] = trinity_coverage
        item["rnaspades_coverage"] = rnaspades_coverage
        item["shorter_coverage"] = shorter_coverage
        matches.append(item)
    return sorted(matches, key=lambda item: (item["trinity_id"], item["rnaspades_id"]))


def parse_cross_assembler_blast(path, minimum_identity=95.0, minimum_shorter_coverage=80.0):
    return [
        item
        for item in _parse_cross_assembler_pairs(path, minimum_hsp_identity=minimum_identity)
        if item["shorter_coverage"] >= float(minimum_shorter_coverage)
    ]


def parse_cross_assembler_best_hits(path):
    return _parse_cross_assembler_pairs(path)


def build_catalog_rows(records, matches, best_hits=None):
    best_hits = list(matches if best_hits is None else best_hits)
    adjacency = {key: set() for key in records}
    match_by_pair = {}
    for match in matches:
        trinity_id = match["trinity_id"]
        rnaspades_id = match["rnaspades_id"]
        if trinity_id not in records or rnaspades_id not in records:
            continue
        adjacency[trinity_id].add(rnaspades_id)
        adjacency[rnaspades_id].add(trinity_id)
        match_by_pair[frozenset((trinity_id, rnaspades_id))] = match
    components = []
    unseen = set(records)
    while unseen:
        start = min(unseen)
        stack = [start]
        component = set()
        while stack:
            key = stack.pop()
            if key in component:
                continue
            component.add(key)
            unseen.discard(key)
            stack.extend(adjacency[key] - component)
        components.append(component)

    def component_order(component):
        sources = {records[key]["source"] for key in component}
        detection = "both" if len(sources) == 2 else "{}_only".format(next(iter(sources)))
        rank = {"both": 0, "trinity_only": 1, "rnaspades_only": 2}[detection]
        maximum_length = max(records[key]["length"] for key in component)
        return rank, -maximum_length, min(component)

    rows = []
    for number, component in enumerate(sorted(components, key=component_order), start=1):
        trinity_keys = sorted(key for key in component if records[key]["source"] == "trinity")
        rnaspades_keys = sorted(key for key in component if records[key]["source"] == "rnaspades")
        detection = "both" if trinity_keys and rnaspades_keys else "trinity_only" if trinity_keys else "rnaspades_only"
        representative_key = max(
            component,
            key=lambda key: (records[key]["length"], records[key]["source"] == "trinity", key),
        )
        representative = records[representative_key]
        gc_count = representative["sequence"].count("G") + representative["sequence"].count("C")
        component_matches = [
            match
            for pair, match in match_by_pair.items()
            if pair.issubset(component)
        ]
        best_match = max(
            component_matches,
            key=lambda item: (item["shorter_coverage"], item["percent_identity"], item["bitscore"]),
        ) if component_matches else {}
        best_opposite_id = ""
        if not best_match and detection != "both":
            source_key = trinity_keys[0] if trinity_keys else rnaspades_keys[0]
            opposite_hits = [
                item
                for item in best_hits
                if item["trinity_id"] == source_key or item["rnaspades_id"] == source_key
            ]
            if opposite_hits:
                best_match = max(
                    opposite_hits,
                    key=lambda item: (item["shorter_coverage"], item["percent_identity"], item["bitscore"]),
                )
                opposite_key = (
                    best_match["rnaspades_id"]
                    if records[source_key]["source"] == "trinity"
                    else best_match["trinity_id"]
                )
                opposite = records[opposite_key]
                best_opposite_id = opposite["contig_id"]
        rows.append(
            {
                "candidate_id": "NRCAND_{:07d}".format(number),
                "detection_class": detection,
                "trinity_contig_ids": ";".join(records[key]["contig_id"] for key in trinity_keys),
                "rnaspades_contig_ids": ";".join(records[key]["contig_id"] for key in rnaspades_keys),
                "rnaspades_samples": ";".join(sorted({records[key]["sample_id"] for key in rnaspades_keys})),
                "representative_source": representative["source"],
                "representative_contig_id": representative["contig_id"],
                "representative_length": representative["length"],
                "gc_percent": "{:.2f}".format(100.0 * gc_count / representative["length"]),
                "cross_assembler_best_opposite_contig_id": best_opposite_id,
                "cross_assembler_best_percent_identity": "{:.2f}".format(best_match["percent_identity"]) if best_match else "",
                "cross_assembler_best_shorter_contig_coverage": "{:.2f}".format(best_match["shorter_coverage"]) if best_match else "",
                "cross_assembler_best_evalue": "{:.3g}".format(best_match["evalue"]) if best_match else "",
                "_sequence": representative["sequence"],
            }
        )
    return rows


def write_catalog_fasta(rows, destination):
    output_path = Path(destination)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as handle:
        for row in rows:
            _write_fasta_record(handle, row["candidate_id"], row["_sequence"])
    return output_path


def write_catalog_table(rows, viral_hits, destination, viral_database_used=False):
    output_path = Path(destination)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_rows = []
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CATALOG_FIELDS, delimiter="\t", extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            output = dict(row)
            viral = viral_hits.get(row["candidate_id"], {})
            if viral:
                if float(viral.get("qcovs", 0)) >= 80.0 and float(viral.get("pident", 0)) >= 90.0:
                    classification = "high_coverage_viral_or_viroid_similarity"
                else:
                    classification = "partial_viral_or_viroid_similarity"
            elif viral_database_used:
                classification = "unclassified_non_reference_rna"
            else:
                classification = "non_reference_rna_not_database_screened"
            output.update(
                {
                    "classification": classification,
                    "viral_accession": viral.get("saccver", ""),
                    "viral_scientific_name": viral.get("sscinames", ""),
                    "viral_percent_identity": viral.get("pident", ""),
                    "viral_query_coverage": viral.get("qcovs", ""),
                    "viral_evalue": viral.get("evalue", ""),
                    "viral_bitscore": viral.get("bitscore", ""),
                    "viral_title": viral.get("stitle", ""),
                }
            )
            writer.writerow(output)
            output_rows.append(output)
    return output_path, output_rows


def write_catalog_summary(rows, destination):
    output_path = Path(destination)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "detection_class", "candidate_count", "high_coverage_viral_or_viroid", "partial_viral_or_viroid",
        "unclassified_or_not_screened",
    ]
    groups = ["both", "trinity_only", "rnaspades_only"]
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t")
        writer.writeheader()
        for group in groups + ["total"]:
            selected = rows if group == "total" else [row for row in rows if row["detection_class"] == group]
            writer.writerow(
                {
                    "detection_class": group,
                    "candidate_count": len(selected),
                    "high_coverage_viral_or_viroid": sum(
                        row["classification"] == "high_coverage_viral_or_viroid_similarity" for row in selected
                    ),
                    "partial_viral_or_viroid": sum(
                        row["classification"] == "partial_viral_or_viroid_similarity" for row in selected
                    ),
                    "unclassified_or_not_screened": sum(
                        row["classification"] not in {
                            "high_coverage_viral_or_viroid_similarity", "partial_viral_or_viroid_similarity",
                        }
                        for row in selected
                    ),
                }
            )
    return output_path


def write_trinity_strategy_table(rows, destination):
    output_path = Path(destination)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    detection_classes = {
        "both": "both_strategies",
        "trinity_only": "assemble_first_only",
        "rnaspades_only": "map_first_only",
    }
    representative_strategies = {
        "trinity": "assemble_first_all_reads",
        "rnaspades": "map_first_genome_unmapped_reads",
    }
    output_rows = []
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=TRINITY_STRATEGY_FIELDS, delimiter="\t")
        writer.writeheader()
        for number, row in enumerate(rows, start=1):
            output = {
                "comparison_id": "TRSTRAT_{:07d}".format(number),
                "detection_class": detection_classes[row["detection_class"]],
                "assemble_first_trinity_contig_ids": row["trinity_contig_ids"],
                "map_first_trinity_contig_ids": row["rnaspades_contig_ids"],
                "map_first_assembly_scope": row["rnaspades_samples"],
                "representative_strategy": representative_strategies[row["representative_source"]],
                "representative_contig_id": row["representative_contig_id"],
                "representative_length": row["representative_length"],
                "gc_percent": row["gc_percent"],
                "best_opposite_trinity_contig_id": row["cross_assembler_best_opposite_contig_id"],
                "best_percent_identity": row["cross_assembler_best_percent_identity"],
                "best_shorter_contig_coverage": row["cross_assembler_best_shorter_contig_coverage"],
                "best_evalue": row["cross_assembler_best_evalue"],
            }
            writer.writerow(output)
            output_rows.append(output)
    return output_path, output_rows


def write_trinity_strategy_summary(rows, destination):
    output_path = Path(destination)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    groups = ["both_strategies", "assemble_first_only", "map_first_only"]
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["detection_class", "candidate_cluster_count"],
            delimiter="\t",
        )
        writer.writeheader()
        for group in groups + ["total"]:
            selected = rows if group == "total" else [row for row in rows if row["detection_class"] == group]
            writer.writerow({"detection_class": group, "candidate_cluster_count": len(selected)})
    return output_path
