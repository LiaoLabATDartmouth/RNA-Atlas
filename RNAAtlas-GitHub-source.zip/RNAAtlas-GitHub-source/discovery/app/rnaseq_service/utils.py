"""Small dependency-free helpers shared by service and pipeline code."""

import hashlib
import json
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path


EMAIL_PATTERN = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def utc_now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_bool(value, default=False):
    if value is None or value == "":
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def bounded_int(value, default, minimum=None, maximum=None):
    try:
        result = int(str(value).strip())
    except (TypeError, ValueError):
        result = int(default)
    if minimum is not None:
        result = max(int(minimum), result)
    if maximum is not None:
        result = min(int(maximum), result)
    return result


def normalize_email(value, allowed_domain="dartmouth.edu", allow_external=False):
    email = str(value or "").strip().lower()
    if not EMAIL_PATTERN.fullmatch(email):
        raise ValueError("A valid email address is required.")
    if not allow_external and not email.endswith("@{}".format(allowed_domain.lower().lstrip("@"))):
        raise ValueError("Registration is limited to {} email addresses.".format(allowed_domain))
    return email


def atomic_write_json(path, payload):
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=".{}-".format(destination.name), dir=str(destination.parent))
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_name, destination)
    except Exception:
        try:
            os.unlink(temporary_name)
        except OSError:
            pass
        raise
    return destination


def load_json(path, default=None):
    source = Path(path)
    if not source.exists():
        return default
    with source.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def stable_identifier(value, length=20):
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()[:length]


def human_size(size):
    amount = float(size)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if amount < 1024.0 or unit == "TiB":
            return "{:.1f} {}".format(amount, unit)
        amount /= 1024.0
