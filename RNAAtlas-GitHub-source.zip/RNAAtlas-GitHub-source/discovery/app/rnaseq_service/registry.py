"""Atomic JSON registries for users and jobs."""

import os
import subprocess
from datetime import datetime, timedelta
from pathlib import Path

from .paths import enforce_rnaseq_boundary, registry_root, service_root
from .utils import atomic_write_json, load_json, stable_identifier, utc_now


def _users_directory(root=None, create=True):
    directory = registry_root(root) / "users"
    if create:
        directory.mkdir(parents=True, exist_ok=True)
    return directory


def _jobs_directory(root=None, create=True):
    directory = registry_root(root) / "jobs"
    if create:
        directory.mkdir(parents=True, exist_ok=True)
    return directory


def user_path(email, root=None, create=True):
    return _users_directory(root, create=create) / "{}.json".format(stable_identifier(email))


def get_user(email, root=None):
    return load_json(user_path(str(email).lower(), root=root, create=False), default=None)


def list_users(root=None):
    directory = _users_directory(root, create=False)
    if not directory.is_dir():
        return []
    users = [load_json(path, default={}) for path in directory.glob("*.json")]
    return sorted((user for user in users if user), key=lambda item: (item.get("status", ""), item.get("email", "")))


def register_user(email, display_name="", root=None, admin_emails=None, auto_approve=False):
    root_path = root or service_root()
    existing = get_user(email, root=root_path)
    if existing:
        return existing
    administrators = {value.strip().lower() for value in (admin_emails or []) if value.strip()}
    is_admin = email.lower() in administrators
    status = "approved" if is_admin or auto_approve else "pending"
    payload = {
        "user_id": stable_identifier(email), "email": email.lower(), "display_name": str(display_name).strip(),
        "status": status, "is_admin": is_admin, "registered_at": utc_now(), "updated_at": utc_now(),
    }
    atomic_write_json(user_path(email, root=root_path, create=True), payload)
    return payload


def approve_user(user_id, approver_email, root=None):
    root_path = root or service_root()
    matches = list(_users_directory(root_path).glob("{}.json".format(user_id)))
    if not matches:
        raise ValueError("User not found.")
    user = load_json(matches[0], default={})
    user.update({"status": "approved", "approved_by": approver_email, "approved_at": utc_now(), "updated_at": utc_now()})
    atomic_write_json(matches[0], user)
    return user


def create_job_record(payload, root=None):
    root_path = root or service_root()
    destination = _jobs_directory(root_path) / "{}.json".format(payload["job_id"])
    record = dict(payload)
    record.setdefault("created_at", utc_now())
    record["updated_at"] = utc_now()
    atomic_write_json(destination, record)
    atomic_write_json(registry_root(root_path) / "latest_job.json", record)
    return record


def job_path(job_id, root=None, create=False):
    safe_id = "".join(character for character in str(job_id) if character.isalnum() or character in "-_")
    if safe_id != str(job_id) or not safe_id:
        raise ValueError("Invalid job ID.")
    return _jobs_directory(root, create=create) / "{}.json".format(safe_id)


def parse_timestamp(value):
    timestamp = str(value or "").strip()
    if timestamp.endswith("Z"):
        timestamp = timestamp[:-1] + "+0000"
    elif len(timestamp) >= 6 and timestamp[-3] == ":" and timestamp[-6] in "+-":
        timestamp = timestamp[:-3] + timestamp[-2:]
    for format_string in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z"):
        try:
            return datetime.strptime(timestamp, format_string)
        except ValueError:
            continue
    return None


def download_expiry(completed_at):
    timestamp = parse_timestamp(completed_at)
    return (timestamp + timedelta(days=3)).isoformat() if timestamp else ""


def get_job(job_id, root=None, refresh=True):
    record = load_json(job_path(job_id, root=root), default=None)
    if not record or not refresh:
        return record
    status_path = Path(record.get("status_path", ""))
    if status_path.exists():
        status = load_json(status_path, default={}) or {}
        record.update(
            {
                "status": status.get("status", record.get("status")), "stage": status.get("stage", ""),
                "message": status.get("message", ""), "progress": status.get("progress"),
                "artifacts": status.get("artifacts", {}), "updated_at": status.get("updated_at", utc_now()),
            }
        )
        if status.get("status") == "completed":
            expiry = download_expiry(status.get("updated_at"))
            if expiry:
                record["download_expires_at"] = expiry
            else:
                record.pop("download_expires_at", None)
    if record.get("slurm_job_id") and record.get("status") in {"submitted", "queued", "running"}:
        squeue = shutil_which("squeue")
        if squeue:
            completed = subprocess.run(
                [squeue, "-h", "-j", str(record["slurm_job_id"]), "-o", "%T"], check=False,
                universal_newlines=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            )
            state = completed.stdout.strip().lower()
            if state:
                record["status"] = "running" if state == "running" else "queued"
                record["slurm_state"] = state
                record["updated_at"] = utc_now()
            else:
                sacct = shutil_which("sacct")
                if sacct:
                    accounting = subprocess.run(
                        [sacct, "-n", "-X", "-j", str(record["slurm_job_id"]), "--format=State"],
                        check=False, universal_newlines=True,
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    )
                    terminal_state = accounting.stdout.strip().splitlines()
                    terminal_state = terminal_state[0].strip().split()[0].split("+")[0].lower() if terminal_state else ""
                    if terminal_state == "cancelled":
                        record.update({"status": "cancelled", "stage": "cancelled", "slurm_state": terminal_state})
                    elif terminal_state in {"failed", "timeout", "out_of_memory", "node_fail", "preempted"}:
                        record.update({"status": "failed", "stage": "failed", "slurm_state": terminal_state})
                    elif terminal_state == "completed":
                        record.update(
                            {
                                "status": "failed_unverified", "stage": "scheduler_complete",
                                "slurm_state": terminal_state,
                                "message": "Slurm completed without a final pipeline status; review job logs.",
                            }
                        )
                    if terminal_state:
                        record["updated_at"] = utc_now()
    atomic_write_json(job_path(job_id, root=root), record)
    return record


def shutil_which(name):
    from shutil import which

    return which(name)


def list_jobs(root=None, user_email="", include_all=False, refresh=True):
    records = []
    directory = _jobs_directory(root, create=False)
    if not directory.is_dir():
        return []
    for path in directory.glob("*.json"):
        record = get_job(path.stem, root=root, refresh=refresh)
        if record and (include_all or not user_email or record.get("submitter_email") == user_email):
            records.append(record)
    return sorted(records, key=lambda item: item.get("created_at", ""), reverse=True)


def update_job(job_id, updates, root=None):
    record = get_job(job_id, root=root, refresh=False)
    if not record:
        raise ValueError("Job not found.")
    record.update(updates)
    record["updated_at"] = utc_now()
    atomic_write_json(job_path(job_id, root=root), record)
    return record
