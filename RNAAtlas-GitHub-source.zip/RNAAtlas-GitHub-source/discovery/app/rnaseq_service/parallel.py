"""Resource-aware parallel execution planning for RNA-seq stages."""

import os
import re
from pathlib import Path


GIBIBYTE = 1024 ** 3
MEMORY_PATTERN = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*([KMGTPE]?I?B?)?\s*$", re.IGNORECASE)


def _positive_int(value):
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return 0
    return parsed if parsed > 0 else 0


def resolve_cpu_budget(requested=0, slurm_cpus=0, affinity_cpus=0, system_cpus=0):
    requested_cpus = _positive_int(requested)
    available_cpus = next(
        (
            value for value in (
                _positive_int(slurm_cpus),
                _positive_int(affinity_cpus),
                _positive_int(system_cpus),
            ) if value
        ),
        1,
    )
    if requested_cpus:
        return min(requested_cpus, available_cpus)
    return available_cpus


def detect_available_cpus(requested=0, environment=None):
    runtime_environment = os.environ if environment is None else environment
    try:
        affinity_cpus = len(os.sched_getaffinity(0))
    except (AttributeError, OSError):
        affinity_cpus = 0
    return resolve_cpu_budget(
        requested=requested,
        slurm_cpus=runtime_environment.get("SLURM_CPUS_PER_TASK", 0),
        affinity_cpus=affinity_cpus,
        system_cpus=os.cpu_count(),
    )


def parse_memory_bytes(value):
    if isinstance(value, (int, float)):
        return int(value)
    match = MEMORY_PATTERN.fullmatch(str(value or ""))
    if not match:
        raise ValueError("Unsupported memory value: {}".format(value))
    amount = float(match.group(1))
    unit = (match.group(2) or "B").upper().replace("IB", "I").rstrip("B")
    powers = {"": 0, "K": 1, "KI": 1, "M": 2, "MI": 2, "G": 3, "GI": 3, "T": 4, "TI": 4, "P": 5, "PI": 5, "E": 6, "EI": 6}
    if unit not in powers:
        raise ValueError("Unsupported memory unit: {}".format(value))
    return int(amount * (1024 ** powers[unit]))


def read_reference_contigs(fasta_index_path):
    contigs = []
    with Path(fasta_index_path).open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            fields = line.rstrip("\n").split("\t")
            if len(fields) < 2:
                raise ValueError("Malformed FASTA index line {}".format(line_number))
            length = int(fields[1])
            if length < 1:
                raise ValueError("Reference contig length must be positive: {}".format(fields[0]))
            contigs.append((fields[0], length))
    if not contigs:
        raise ValueError("FASTA index contains no reference contigs.")
    return contigs


def partition_contigs_by_length(contigs, shard_count):
    ordered = [(str(name), int(length)) for name, length in contigs]
    if not ordered:
        raise ValueError("At least one reference contig is required.")
    number_of_shards = max(1, min(int(shard_count), len(ordered)))
    shards = []
    index = 0
    remaining_length = sum(length for _, length in ordered)
    while len(shards) < number_of_shards:
        remaining_shards = number_of_shards - len(shards)
        if remaining_shards == 1:
            shard = ordered[index:]
            shards.append(shard)
            break
        target = float(remaining_length) / remaining_shards
        shard = []
        shard_length = 0
        maximum_index = len(ordered) - (remaining_shards - 1)
        while index < maximum_index:
            next_item = ordered[index]
            next_length = next_item[1]
            if shard and abs(shard_length - target) <= abs(shard_length + next_length - target):
                break
            shard.append(next_item)
            shard_length += next_length
            index += 1
        if not shard:
            shard.append(ordered[index])
            shard_length += ordered[index][1]
            index += 1
        shards.append(shard)
        remaining_length -= shard_length
    return shards


def partition_reference_intervals(contigs, shard_count):
    ordered = [(str(name), int(length)) for name, length in contigs]
    if not ordered:
        raise ValueError("At least one reference contig is required.")
    total_length = sum(length for _, length in ordered)
    number_of_shards = max(1, min(int(shard_count), total_length))
    shards = []
    contig_index = 0
    contig_position = 1
    remaining_length = total_length
    while len(shards) < number_of_shards:
        remaining_shards = number_of_shards - len(shards)
        target_length = (remaining_length + remaining_shards - 1) // remaining_shards
        shard = []
        shard_length = 0
        while shard_length < target_length and contig_index < len(ordered):
            contig_name, contig_length = ordered[contig_index]
            available = contig_length - contig_position + 1
            take = min(target_length - shard_length, available)
            end = contig_position + take - 1
            shard.append((contig_name, contig_position, end))
            shard_length += take
            contig_position = end + 1
            if contig_position > contig_length:
                contig_index += 1
                contig_position = 1
        shards.append(shard)
        remaining_length -= shard_length
    return shards


def choose_variant_workers(total_threads, shard_count, maximum_workers=8):
    threads = max(1, int(total_threads))
    cpu_limit = max(1, threads // 2)
    return max(1, min(int(shard_count), cpu_limit, int(maximum_workers)))


def choose_variant_shards(
    total_threads, reference_length, requested=0, maximum_auto_shards=32, minimum_bases_per_shard=100000,
):
    threads = max(1, int(total_threads))
    reference_bases = max(1, int(reference_length))
    worker_limit = max(1, min(8, threads // 2))
    desired = int(requested) if int(requested) > 0 else min(int(maximum_auto_shards), worker_limit * 4)
    size_limit = max(1, reference_bases // int(minimum_bases_per_shard))
    return max(1, min(reference_bases, size_limit, desired))


def choose_alignment_workers(
    total_threads, sample_count, job_memory_bytes, sort_memory_bytes, genome_length,
    requested=0, minimum_threads_per_sample=4, maximum_auto_workers=4,
):
    threads = max(1, int(total_threads))
    samples = max(1, int(sample_count))
    cpu_limit = max(1, threads // max(1, int(minimum_threads_per_sample)))
    estimated_worker_memory = int(sort_memory_bytes) + max(2 * GIBIBYTE, int(genome_length) * 9)
    usable_memory = max(0, int(job_memory_bytes) - 4 * GIBIBYTE)
    memory_limit = max(1, usable_memory // max(1, estimated_worker_memory))
    desired = int(requested) if int(requested) > 0 else int(maximum_auto_workers)
    return max(1, min(samples, cpu_limit, memory_limit, desired))


def choose_ase_workers(total_threads, sample_count, job_memory_bytes, heap_gb=8, requested=0, maximum_auto_workers=6):
    threads = max(1, int(total_threads))
    samples = max(1, int(sample_count))
    worker_memory = (max(1, int(heap_gb)) + 2) * GIBIBYTE
    usable_memory = max(0, int(job_memory_bytes) - 4 * GIBIBYTE)
    memory_limit = max(1, usable_memory // worker_memory)
    desired = int(requested) if int(requested) > 0 else int(maximum_auto_workers)
    return max(1, min(samples, threads, memory_limit, desired))
