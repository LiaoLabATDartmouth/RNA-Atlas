"""Load non-secret KEY=VALUE deployment configuration."""

import os
from pathlib import Path


def load_env_file(path):
    source = Path(path)
    if not source.exists():
        return False
    for line in source.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value
    return True

