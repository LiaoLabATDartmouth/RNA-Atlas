"""Summarize existing per-sample RNA-seq QC without excluding data."""

import csv
import json
import math
import statistics
from collections import Counter
from pathlib import Path

from .utils import atomic_write_json


def _star_metrics(path):
    metrics = {}
    if not path.is_file():
        return metrics
    for line in path.read_text(encoding="utf-8").splitlines():
        if "|" not in line:
            continue
        key, value = (part.strip() for part in line.split("|", 1))
        if key == "Number of input reads":
            metrics["aligned_input_reads"] = int(value.replace(",", ""))
        elif key == "Uniquely mapped reads %":
            metrics["unique_mapping_percent"] = float(value.rstrip("%"))
    return metrics


def _fastp_metrics(path):
    if not path.is_file():
        return {}
    summary = json.loads(path.read_text(encoding="utf-8")).get("summary", {})
    before = int(summary.get("before_filtering", {}).get("total_reads", 0))
    after = int(summary.get("after_filtering", {}).get("total_reads", 0))
    if before < 1:
        return {}
    return {"fastp_input_reads": before, "fastp_retained_reads": after,
            "fastp_retained_percent": round(100 * after / before, 2)}


def _table_counts(path, sample_field, accepted=None):
    counts = Counter()
    if not path.is_file():
        return counts
    with path.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            if accepted is None or accepted(row):
                counts[row[sample_field]] += 1
    return counts


def _median_log_count_correlations(path, sample_ids):
    if not path.is_file() or len(sample_ids) < 2 or len(sample_ids) > 32:
        return {}
    values = {sample_id: [] for sample_id in sample_ids}
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if not set(sample_ids).issubset(reader.fieldnames or []):
            return {}
        for row in reader:
            for sample_id in sample_ids:
                value = float(row[sample_id])
                if not math.isfinite(value) or value < 0:
                    return {}
                values[sample_id].append(math.log1p(value))
    if len(values[sample_ids[0]]) < 2:
        return {}
    correlations = {sample_id: [] for sample_id in sample_ids}
    for index, first in enumerate(sample_ids):
        for second in sample_ids[index + 1:]:
            first_values = values[first]
            second_values = values[second]
            first_mean = statistics.fmean(first_values)
            second_mean = statistics.fmean(second_values)
            numerator = sum((left - first_mean) * (right - second_mean)
                            for left, right in zip(first_values, second_values))
            first_variance = sum((value - first_mean) ** 2 for value in first_values)
            second_variance = sum((value - second_mean) ** 2 for value in second_values)
            if first_variance and second_variance:
                correlation = numerator / math.sqrt(first_variance * second_variance)
                correlations[first].append(correlation)
                correlations[second].append(correlation)
    return {sample_id: round(statistics.median(correlations[sample_id]), 4)
            for sample_id in sample_ids if correlations[sample_id]}


def write_quality_summary(output_root, samples, artifacts, module):
    root = Path(output_root)
    sample_ids = [sample["sample_id"] for sample in samples]
    per_sample = {}
    warnings = []
    checks = {}
    raw_counts = artifacts.get("fastq_record_counts", {})
    cleaned_counts = artifacts.get("cleaned_fastq_record_counts", {})
    alignment_root = Path(artifacts.get("alignment_qc_directory", root / "10_alignment"))
    fastp_root = Path(artifacts.get("fastp_report_directory", root / "00_qc" / "fastp"))
    for sample_id in sample_ids:
        metrics = {}
        if sample_id in raw_counts:
            metrics["validated_input_pairs"] = int(raw_counts[sample_id])
        if sample_id in cleaned_counts:
            metrics["validated_cleaned_pairs"] = int(cleaned_counts[sample_id])
        try:
            metrics.update(_star_metrics(alignment_root / sample_id / "Log.final.out"))
        except (OSError, ValueError) as error:
            warnings.append("{}: STAR QC could not be read: {}".format(sample_id, error))
        try:
            metrics.update(_fastp_metrics(fastp_root / "{}.fastp.json".format(sample_id)))
        except (OSError, ValueError, TypeError) as error:
            warnings.append("{}: fastp QC could not be read: {}".format(sample_id, error))
        if "unique_mapping_percent" not in metrics:
            warnings.append("{}: STAR unique-mapping metric is unavailable.".format(sample_id))
        if metrics.get("fastp_retained_percent", 100) < 70:
            warnings.append("{}: fewer than 70% of reads were retained after trimming; review fastp and FastQC.".format(sample_id))
        if metrics.get("unique_mapping_percent", 100) < 50:
            warnings.append("{}: fewer than 50% of reads mapped uniquely; review the reference, library, and STAR log.".format(sample_id))
        per_sample[sample_id] = metrics

    if module == "differential_expression":
        groups = Counter(sample["condition"] for sample in samples)
        checks["samples_per_condition"] = dict(sorted(groups.items()))
        checks["pca_available"] = (root / "20_expression" / "pca.pdf").is_file()
        try:
            correlations = _median_log_count_correlations(
                root / "20_expression" / "normalized_gene_counts.tsv", sample_ids,
            )
        except (OSError, ValueError, TypeError):
            correlations = {}
        checks["median_log_count_correlation_per_sample"] = correlations
        for sample_id, correlation in sorted(correlations.items()):
            if correlation < 0.8:
                warnings.append("{}: median log-count correlation is below 0.8; inspect PCA, library, and sample labels.".format(sample_id))
        if not correlations:
            warnings.append("Normalized-count sample correlations are unavailable; inspect the PCA and counts manually.")
        for condition, count in sorted(groups.items()):
            if count < 2:
                warnings.append("{} has only {} sample; review replicate support before interpreting DE.".format(condition, count))
        if not checks["pca_available"]:
            warnings.append("PCA output is unavailable; sample clustering and outliers have not been reviewed.")
    elif module == "rna_snv":
        try:
            counts = _table_counts(root / "30_variants" / "variant_counts.tsv", "sample_id",
                                   lambda row: row.get("filter") in {"PASS", "."})
        except (OSError, ValueError, KeyError) as error:
            counts = Counter()
            warnings.append("RNA variant-count QC could not be read: {}".format(error))
        checks["pass_allele_rows_per_sample"] = {sample_id: counts[sample_id] for sample_id in sample_ids}
        checks["interpretation"] = "RNA-only calls are not validated DNA genotypes; review editing and alignment artifacts."
    elif module == "ase":
        try:
            counts = _table_counts(root / "30_variants" / "allele_specific_counts.tsv", "sample_id")
        except (OSError, ValueError, KeyError) as error:
            counts = Counter()
            warnings.append("ASE site-count QC could not be read: {}".format(error))
        checks["recounted_sites_per_sample"] = {sample_id: counts[sample_id] for sample_id in sample_ids}
        for sample_id in sample_ids:
            if counts[sample_id] == 0:
                warnings.append("{}: no heterozygous DNA sites met the ASE recount filters.".format(sample_id))
        checks["mapping_bias_corrected"] = False
        provenance_path = root / "30_variants" / "ase_genotype_provenance.json"
        if provenance_path.is_file():
            try:
                sample_map = json.loads(provenance_path.read_text(encoding="utf-8")).get("rna_to_vcf_sample", {})
                checks["rna_to_vcf_sample"] = sample_map
                if set(sample_map) != set(sample_ids):
                    warnings.append("ASE genotype mapping does not cover every RNA sample; review provenance.")
            except (OSError, ValueError, TypeError) as error:
                warnings.append("ASE genotype provenance could not be read: {}".format(error))
        else:
            warnings.append("ASE genotype provenance is unavailable.")
        warnings.append("ASE counts are not mapping-bias corrected; review donor-to-VCF matching and allele alignment bias.")
    elif module == "trinity":
        stats_path = root / "25_denovo_transcriptome" / "assembly_stats.tsv"
        if stats_path.is_file():
            try:
                with stats_path.open("r", encoding="utf-8", newline="") as handle:
                    checks["assembly_stats"] = next(csv.DictReader(handle, delimiter="\t"), {})
            except (OSError, ValueError) as error:
                warnings.append("Trinity assembly statistics could not be read: {}".format(error))
        representation_path = root / "25_denovo_transcriptome" / "read_representation.tsv"
        representation = {}
        if representation_path.is_file():
            try:
                with representation_path.open("r", encoding="utf-8", newline="") as handle:
                    for row in csv.DictReader(handle, delimiter="\t"):
                        representation[row["sample_id"]] = float(row["overall_alignment_percent"])
            except (OSError, ValueError, KeyError) as error:
                representation = {}
                warnings.append("Trinity read-representation QC could not be read: {}".format(error))
        checks["read_representation_assessed"] = set(representation) == set(sample_ids)
        checks["read_representation_percent_per_sample"] = representation
        for sample_id, percent in sorted(representation.items()):
            if percent < 80:
                warnings.append("{}: fewer than 80% of analysis read pairs aligned to the Trinity assembly; review representation.".format(sample_id))
        checks["busco_completeness_assessed"] = False
        if not checks["read_representation_assessed"]:
            warnings.append("Trinity read representation was not measured for every sample.")
        warnings.append("BUSCO completeness was not measured; assembly statistics and read representation alone do not establish completeness.")

    summary = {"module": module, "samples": per_sample, "checks": checks,
               "warnings": warnings, "automatic_sample_exclusions": 0}
    destination = root / "00_qc" / "qc_summary.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_json(destination, summary)
    return str(destination), summary
