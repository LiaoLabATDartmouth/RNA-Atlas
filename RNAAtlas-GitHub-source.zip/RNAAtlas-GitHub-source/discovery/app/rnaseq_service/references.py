"""Validation and discovery for preinstalled RNA-seq references."""

import hashlib
import json
import re
from pathlib import Path

from .paths import enforce_rnaseq_boundary, references_root, service_root, shared_assets_root


REFERENCE_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,119}$")
FASTA_SUFFIXES = (".fa", ".fasta", ".fna")


def validate_reference_id(reference_id):
    value = str(reference_id or "").strip()
    if not REFERENCE_ID_PATTERN.fullmatch(value):
        raise ValueError(
            "Reference IDs must start with a letter or number and contain only letters, numbers, '.', '_' or '-'."
        )
    return value


def _relative_path(reference_directory, value, label):
    relative = Path(str(value or ""))
    if not str(value or "").strip() or relative.is_absolute():
        raise ValueError("Reference manifest {} must be a relative path.".format(label))
    directory = reference_directory.resolve(strict=False)
    candidate = (directory / relative).resolve(strict=False)
    if candidate != directory and directory not in candidate.parents:
        raise ValueError("Reference manifest {} escapes its reference directory.".format(label))
    return candidate


def _sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_reference(reference_id, root=None, require_ready=True, verify_checksums=False):
    root_path = Path(root or service_root()).resolve(strict=False)
    safe_id = validate_reference_id(reference_id)
    directory = references_root(root_path) / safe_id
    if not directory.exists():
        shared_root = shared_assets_root(root_path)
        directory = references_root(shared_root) / safe_id
        directory = enforce_rnaseq_boundary(directory, root=shared_root)
    else:
        directory = enforce_rnaseq_boundary(directory, root=root_path)
    manifest_path = directory / "reference.json"
    errors = []
    manifest = {}
    if not manifest_path.is_file():
        errors.append("Missing reference manifest: {}".format(manifest_path))
    else:
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as error:
            errors.append("Invalid reference manifest {}: {}".format(manifest_path, error))
    if manifest and str(manifest.get("id", "")) != safe_id:
        errors.append("Reference manifest ID does not match its directory name.")
    resolved = {}
    for key in ("fasta", "star_index"):
        try:
            resolved[key] = _relative_path(directory, manifest.get(key, ""), key)
        except ValueError as error:
            errors.append(str(error))
    annotation_value = str(manifest.get("annotation", "")).strip()
    if annotation_value:
        try:
            resolved["annotation"] = _relative_path(directory, annotation_value, "annotation")
        except ValueError as error:
            errors.append(str(error))
    fasta = resolved.get("fasta")
    annotation = resolved.get("annotation")
    star_index = resolved.get("star_index")
    if fasta and (not fasta.is_file() or fasta.suffix.lower() not in FASTA_SUFFIXES):
        errors.append("Reference FASTA is missing or unsupported: {}".format(fasta))
    if annotation and (not annotation.is_file() or annotation.suffix.lower() != ".gtf"):
        errors.append("Preinstalled reference annotation must be an existing GTF: {}".format(annotation))
    if fasta:
        if not Path("{}.fai".format(fasta)).is_file():
            errors.append("Preinstalled reference is missing its FASTA index: {}.fai".format(fasta))
        if not fasta.with_suffix(".dict").is_file():
            errors.append("Preinstalled reference is missing its sequence dictionary: {}".format(fasta.with_suffix(".dict")))
    if star_index:
        if not star_index.is_dir():
            errors.append("Preinstalled STAR index directory is missing: {}".format(star_index))
        else:
            for marker in ("Genome", "SA", "SAindex", "genomeParameters.txt"):
                if not (star_index / marker).is_file():
                    errors.append("Preinstalled STAR index is incomplete; missing {}.".format(marker))
    for key, path in (("fasta_sha256", fasta), ("annotation_sha256", annotation)):
        if key == "annotation_sha256" and not annotation:
            continue
        expected = str(manifest.get(key, "")).lower()
        if not re.fullmatch(r"[0-9a-f]{64}", expected):
            errors.append("Reference manifest {} must be a SHA-256 digest.".format(key))
        elif verify_checksums and path and path.is_file() and _sha256(path) != expected:
            errors.append("Reference checksum mismatch for {}.".format(path))
    try:
        ploidy = int(manifest.get("recommended_ploidy", 0))
        if ploidy < 1:
            raise ValueError
    except (TypeError, ValueError):
        ploidy = 0
        errors.append("Reference recommended_ploidy must be a positive integer.")
    try:
        genome_bases = int(manifest.get("genome_bases", 0))
        if genome_bases < 1:
            raise ValueError
    except (TypeError, ValueError):
        genome_bases = 0
        errors.append("Reference genome_bases must be a positive integer.")
    try:
        sa_index_nbases = int(manifest.get("star_sa_index_nbases", 0))
        if sa_index_nbases < 1 or sa_index_nbases > 14:
            raise ValueError
    except (TypeError, ValueError):
        sa_index_nbases = 0
        errors.append("Reference star_sa_index_nbases must be an integer from 1 to 14.")
    try:
        sjdb_overhang = int(manifest.get("star_sjdb_overhang", 0))
        if sjdb_overhang < 1:
            raise ValueError
    except (TypeError, ValueError):
        sjdb_overhang = 0
        errors.append("Reference star_sjdb_overhang must be a positive integer.")
    record = {
        "id": safe_id,
        "label": str(manifest.get("label") or safe_id),
        "organism": str(manifest.get("organism", "")),
        "assembly": str(manifest.get("assembly", "")),
        "recommended_ploidy": ploidy,
        "genome_bases": genome_bases,
        "star_sa_index_nbases": sa_index_nbases,
        "star_sjdb_overhang": sjdb_overhang,
        "star_version": str(manifest.get("star_version", "")),
        "fasta": str(fasta) if fasta else "",
        "annotation": str(annotation) if annotation else "",
        "has_annotation": bool(annotation),
        "capabilities": {
            "alignment": True,
            "gene_counts": bool(annotation),
            "differential_expression": bool(annotation),
            "variants": True,
            "ase": True,
            "assembly": True,
        },
        "star_index": str(star_index) if star_index else "",
        "manifest": str(manifest_path),
        "errors": errors,
        "ready": not errors,
    }
    if require_ready and errors:
        raise ValueError("Reference {} is not ready: {}".format(safe_id, "; ".join(errors)))
    return record


def list_references(root=None, ready_only=True):
    root_path = root or service_root()
    directories = [references_root(root_path)]
    shared_root = shared_assets_root(root_path)
    if shared_root != Path(root_path).resolve(strict=False):
        directories.append(references_root(shared_root))
    records = []
    seen = set()
    for directory in directories:
        if not directory.is_dir():
            continue
        for candidate in sorted(directory.iterdir(), key=lambda item: item.name.lower()):
            if not candidate.is_dir() or candidate.name.startswith(".") or candidate.name in seen:
                continue
            seen.add(candidate.name)
            try:
                record = load_reference(candidate.name, root=root_path, require_ready=False)
            except ValueError:
                continue
            if not ready_only or record["ready"]:
                records.append(record)
    return records
