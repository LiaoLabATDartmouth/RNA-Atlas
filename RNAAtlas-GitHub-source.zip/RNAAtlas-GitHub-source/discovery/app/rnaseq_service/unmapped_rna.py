"""Summarize and classify de novo assemblies from genome-unmapped RNA reads."""

import csv
import re
from pathlib import Path


_COVERAGE_PATTERN = re.compile(r"(?:^|_)cov_([0-9]+(?:\.[0-9]+)?)")


def read_fasta(path):
    name = None
    description = ""
    sequence = []
    with Path(path).open("r", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if name is not None:
                    yield name, description, "".join(sequence)
                description = line[1:].strip()
                name = description.split()[0]
                sequence = []
            else:
                if name is None:
                    raise ValueError("FASTA sequence was found before a header in {}.".format(path))
                sequence.append(line)
    if name is not None:
        yield name, description, "".join(sequence)


def _coverage_from_header(description):
    match = _COVERAGE_PATTERN.search(description)
    return match.group(1) if match else ""


def filter_and_summarize_fasta(source, destination, sample_id, mode, minimum_length=200):
    output_path = Path(destination)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    with output_path.open("w", encoding="utf-8") as output:
        for name, description, sequence in read_fasta(source):
            sequence = sequence.upper()
            if len(sequence) < int(minimum_length):
                continue
            gc_count = sequence.count("G") + sequence.count("C")
            gc_percent = 100.0 * gc_count / len(sequence) if sequence else 0.0
            output.write(">{}\n".format(description))
            for start in range(0, len(sequence), 80):
                output.write(sequence[start:start + 80] + "\n")
            rows.append(
                {
                    "sample_id": sample_id,
                    "contig_id": name,
                    "mode": mode,
                    "length": len(sequence),
                    "gc_percent": "{:.2f}".format(gc_percent),
                    "assembler_coverage": _coverage_from_header(description),
                }
            )
    return rows


def parse_host_blast(path, minimum_identity=90.0, minimum_query_coverage=80.0):
    fieldnames = ["qseqid", "qlen", "qstart", "qend", "pident", "length", "evalue", "bitscore", "sseqid"]
    intervals = {}
    query_lengths = {}
    best_hits = {}
    blast_path = Path(path)
    if not blast_path.exists():
        return {}
    with blast_path.open("r", encoding="utf-8", errors="replace") as handle:
        reader = csv.reader(handle, delimiter="\t")
        for fields in reader:
            if not fields or fields[0].startswith("#"):
                continue
            row = dict(zip(fieldnames, fields))
            if float(row["pident"]) < float(minimum_identity):
                continue
            query_id = row["qseqid"]
            query_lengths[query_id] = int(row["qlen"])
            start, end = sorted((int(row["qstart"]), int(row["qend"])))
            intervals.setdefault(query_id, []).append((start, end))
            bitscore = float(row["bitscore"])
            if query_id not in best_hits or bitscore > best_hits[query_id][0]:
                best_hits[query_id] = (bitscore, row["sseqid"])
    results = {}
    for query_id, query_intervals in intervals.items():
        merged = []
        for start, end in sorted(query_intervals):
            if merged and start <= merged[-1][1] + 1:
                merged[-1] = (merged[-1][0], max(merged[-1][1], end))
            else:
                merged.append((start, end))
        covered = sum(end - start + 1 for start, end in merged)
        query_coverage = 100.0 * covered / query_lengths[query_id]
        if query_coverage >= float(minimum_query_coverage):
            results[query_id] = {
                "host_query_coverage": "{:.2f}".format(query_coverage),
                "host_reference_sequence": best_hits[query_id][1],
            }
    return results


def write_non_host_fasta(source, destination, host_hits):
    output_path = Path(destination)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    retained = 0
    with output_path.open("w", encoding="utf-8") as output:
        for name, description, sequence in read_fasta(source):
            if name in host_hits:
                continue
            retained += 1
            output.write(">{}\n".format(description))
            for start in range(0, len(sequence), 80):
                output.write(sequence[start:start + 80] + "\n")
    return retained


def parse_viral_blast(path):
    fieldnames = [
        "qseqid", "saccver", "pident", "length", "qcovs", "evalue", "bitscore", "staxids",
        "sscinames", "stitle",
    ]
    results = {}
    blast_path = Path(path)
    if not blast_path.exists():
        return results
    with blast_path.open("r", encoding="utf-8", errors="replace") as handle:
        reader = csv.reader(handle, delimiter="\t")
        for fields in reader:
            if not fields or fields[0].startswith("#"):
                continue
            row = dict(zip(fieldnames, fields))
            query_id = row["qseqid"]
            bitscore = float(row["bitscore"])
            if query_id not in results or bitscore > results[query_id][0]:
                results[query_id] = (bitscore, row)
    return {query_id: row for query_id, (_, row) in results.items()}


def write_candidate_table(
    rows, host_hits, viral_hits, destination, viral_database_used=False,
    high_coverage_threshold=80.0, high_identity_threshold=90.0,
):
    fieldnames = [
        "sample_id", "contig_id", "mode", "length", "gc_percent", "assembler_coverage",
        "classification", "host_query_coverage", "host_reference_sequence", "viral_accession",
        "viral_scientific_name", "viral_percent_identity", "viral_query_coverage", "viral_evalue",
        "viral_bitscore", "viral_title",
    ]
    output_rows = []
    for row in rows:
        output = dict(row)
        host = host_hits.get(row["contig_id"], {})
        viral = viral_hits.get(row["contig_id"], {})
        if host:
            classification = "reference_genome_derived"
        elif viral:
            if (
                float(viral.get("qcovs", 0)) >= float(high_coverage_threshold)
                and float(viral.get("pident", 0)) >= float(high_identity_threshold)
            ):
                classification = "high_coverage_viral_or_viroid_similarity"
            else:
                classification = "partial_viral_or_viroid_similarity"
        elif viral_database_used:
            classification = "unclassified_non_reference_rna"
        else:
            classification = "non_reference_rna_not_database_screened"
        output.update(
            {
                "classification": classification,
                "host_query_coverage": host.get("host_query_coverage", ""),
                "host_reference_sequence": host.get("host_reference_sequence", ""),
                "viral_accession": viral.get("saccver", ""),
                "viral_scientific_name": viral.get("sscinames", ""),
                "viral_percent_identity": viral.get("pident", ""),
                "viral_query_coverage": viral.get("qcovs", ""),
                "viral_evalue": viral.get("evalue", ""),
                "viral_bitscore": viral.get("bitscore", ""),
                "viral_title": viral.get("stitle", ""),
            }
        )
        output_rows.append(output)
    output_path = Path(destination)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t", extrasaction="ignore")
        writer.writeheader()
        writer.writerows(output_rows)
    return output_path


def combine_candidate_tables(tables, destination):
    rows = []
    fieldnames = None
    for table in tables:
        with Path(table).open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle, delimiter="\t")
            if fieldnames is None:
                fieldnames = reader.fieldnames
            rows.extend(reader)
    output_path = Path(destination)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames or ["sample_id"], delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)
    return output_path
