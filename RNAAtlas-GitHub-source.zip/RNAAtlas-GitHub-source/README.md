# RNA Atlas for Liao lab members

Download `RNAAtlas-GitHub-source.zip` from the private lab repository and extract it on your Mac. If GitHub shows 404, ask the lab maintainer for repository access. GitHub's **Code → Download ZIP** downloads an outer repository ZIP; extract the `RNAAtlas-GitHub-source.zip` inside it as well.

**Open your personal browser page:** In the extracted `RNAAtlas-GitHub-source` folder, double-click `mac/start_personal.command`. A Terminal window opens. First enter **your NetID**. SSH then asks for your Discovery password; its input is hidden completely (no characters or `*` appear). Next enter the full path to a DartFS folder you own under `/dartfs/rc/lab/L/LiaoC/`, outside `Service_Account`. **The path field is visible text; never type a password there.** After the connection and access checks pass, your browser opens RNA Atlas automatically. Keep that Terminal window open. If the browser does not open, copy the **private URL printed in that Terminal window** into a browser on the same Mac. The personal app uses a different local port each time; do **not** open the administrator page at `http://127.0.0.1:8791/` or share your private URL. If Terminal reports an access error, resolve it with the lab maintainer rather than opening the administrator page.

RNA Atlas is a **personal browser app for macOS**. It opens on your own computer and prepares a Slurm script in your DartFS project. At launch, you enter your Discovery password **in Terminal** once; the app reuses that SSH connection to browse and prepare your project. You then log in to Discovery normally in Terminal and run the RNA Atlas submission command under your NetID. Your FASTQs, job logs, temporary workspace, and results stay in your own DartFS workspace. The lab maintains shared genome indexes and software under `Service_Account/RNAseq_atlas`; it is **not** where your projects run. The maintainer must confirm your account has safe read-only access to those assets before you use the app.

**Use the personal app for lab work.** Its header identifies your own Discovery account and its button says **Create Slurm job**. That button prepares one script, then displays the script location and exact command to run on Discovery; it does **not** submit the job. If a page instead says **service session** and **Submit Slurm job**, you are viewing the separately restricted administrator QA app. Its button submits immediately under the service account. Do not use that page for member projects or share its private URL or token.

This repository is intended to remain **private to the lab**. Do not put patient information, passwords, SSH keys, Kerberos tickets, or research FASTQs in GitHub. No example reads are bundled in this download.

**First-run check:** Do not use this release for student research until the lab maintainer confirms shared-asset permissions. Once access is safely configured, complete one test job under your own Discovery account using approved data. The paired-end pipeline has been tested with the service account; a member-owned job, long-job compute-node ticket renewal, and the new single-end path still need end-to-end verification. If a job cannot be submitted or completed, stop and ask the lab maintainer to check permissions and credentials; do not move your data into `Service_Account`.

## 1. Check access before downloading

You need a Mac with Python 3.9 or newer, a Discovery account, access to Dartmouth's network or VPN, and a writable DartFS folder under `/dartfs/rc/lab/L/LiaoC/` that you own **outside** `Service_Account`. You also need read/traverse access to the lab's shared `Service_Account/RNAseq_atlas/shared/references` and `shared/runtime` assets. If an access check fails, ask the lab maintainer to verify those permissions; do not use someone else's credentials.

Connect to Dartmouth's campus network or VPN for [Discovery SSH access](https://rc.dartmouth.edu/hpc/intro-to-hpc/logging-into-the-cluster/). Use your own Dartmouth NetID and a DartFS workspace you own.

The launcher starts a reusable SSH connection and asks for your Discovery password **in its Terminal window**, not in the browser. If SSH shows a new host-key fingerprint, verify it with [Dartmouth Research Computing](https://rc.dartmouth.edu/hpc/discovery-overview/) **before** accepting it. Never accept an unfamiliar or changed key just to continue. The launcher then checks that Discovery reports your NetID, has a valid **Discovery-side** Kerberos ticket, and can read your DartFS workspace and the shared app assets. A password login alone does not prove DartFS ticket availability. If this check fails, stop and resolve your Discovery-side access; the browser will not open on an unverified connection. **Never enter your password in the RNA Atlas browser page or send it to the lab**; the app does not collect or save it.

## 2. Download and launch

From the extracted `RNAAtlas-GitHub-source/` folder, double-click `mac/start_personal.command`. On first launch, the script installs its pinned local Python packages, asks for your NetID, then starts SSH's hidden password prompt in Terminal. **Nothing appears as you type the password**; press Return when finished. Only then does it ask for **your own full DartFS workspace path—not a password**. For example, `/dartfs/rc/lab/L/LiaoC/<your-folder>/RNAseq_atlas` is valid only if `<your-folder>` is assigned to you. It must not point inside `Service_Account` or to a folder on your Mac. The launcher retries an invalid path without prompting for a password again. After the access checks pass, it opens the browser on `127.0.0.1` with a private URL token and prints that URL in Terminal as a fallback. Keep the launcher window open while using the app; closing it stops the browser server but does not cancel submitted Slurm jobs. The reusable SSH connection may also end after eight idle hours or when the network changes.

For a diagnostic check from Terminal instead of opening the page:

```bash
cd mac
scripts/setup_mac.sh
.venv-web/bin/python personal_launcher.py --check
```

The first launch creates `~/.rnaseq-atlas/personal.json`, a private browser token, and a user-only SSH connection socket on **your Mac**. To change your NetID or DartFS workspace later, run `.venv-web/bin/python personal_launcher.py --configure`. If the page shows **Discovery disconnected**, double-click `mac/connect_discovery.command`, enter your password in its Terminal window, then click **Reconnect** in the browser. Do not share the token, expose the localhost port, or commit `~/.rnaseq-atlas/`.

## 3. Prepare a project in your own DartFS workspace

The launcher creates `<personal-workspace>/projects/` automatically. Create one folder for each study inside it; that folder's name becomes the project name. Put inputs in its `datasets/` subfolder before opening it in RNA Atlas. Relaunching the app refreshes `app/` and `scripts/` code without replacing existing project folders or results; `shared/` keeps the job records needed to track previous runs. If you used an older release that kept a project directly under `<personal-workspace>/`, move that project folder into `projects/` yourself before opening it. The launcher does not move or overwrite it:

```text
<personal-workspace>/
├── app/                                    # refreshed launcher code
├── scripts/                                # refreshed launcher code
├── shared/                                 # persistent job records
└── projects/                               # created by the launcher
    └── <project_folder>/
        ├── datasets/
        │   ├── meta_data/sample_sheet.tsv
        │   └── raw_data/
        │       ├── S1/S1_1.fq.gz
        │       ├── S1/S1_2.fq.gz
        │       ├── S2/S2_1.fq.gz
        │       └── S2/S2_2.fq.gz
        ├── genotype_VCF/dna_genotypes.vcf.gz   # only for ASE
        └── results/                            # created by RNA Atlas
```

Use `sample_id` and `condition` columns in `sample_sheet.tsv`; the app offers a downloadable template. Make a `raw_data/<sample_id>/` folder for every sheet row. For paired-end reads, name mates `<sample_id>_1.fq.gz` and `<sample_id>_2.fq.gz`. For single-end reads, name the file `<sample_id>.fq.gz`; `.fastq.gz` also works. If a **genuine single-end** file is named `<sample_id>_1.fq.gz` or `<sample_id>_1.fastq.gz`, add a `layout` column to the sample sheet and set it to `single` for every sample. A lone `_1` file without that declaration is treated as an incomplete pair; do not relabel one mate from a paired library as single-end. Extra or ambiguous FASTQs, missing mates, and mixed layouts in one project are rejected. For ASE, add a pre-called **DNA genotype VCF** under `genotype_VCF/` before submission. If RNA and VCF sample names differ, also add `genotype_VCF/ase_genotype_map.tsv`. Do not use the RNA SNV output as a substitute for DNA genotypes.

In the browser, click **Open project folder**, choose the prepared folder, select a preinstalled reference, and click **Load data**. The app compares the sample sheet with FASTQ filenames and samples up to 2,000 reads or read pairs per sample. The default complete-file validation checks the full FASTQs when analysis begins. Single-end projects show only read-one trimming controls; paired-end projects also show read-two controls. Resolve any missing, mismatched, corrupt, or unreadable inputs before submitting. **No example FASTQs are included in the download**; use reads in your own project folder.

## 4. Choose one analysis and prepare its script

**Dh68 ploidy:** The lab confirms that its Dh68 strain is haploid (1n), matching the reference's 1n setting. This does not establish the ploidy of a different sample: *Debaryomyces hansenii* also has diploid strains ([Jacques et al. 2010](https://pmc.ncbi.nlm.nih.gov/articles/PMC2837983/)). Confirm the sample's identity and ploidy before SNV or ASE interpretation; Trinity does not use ploidy.

Choose **one** module per Slurm job. To run all four analyses, create and submit four separate jobs. Each job handles all samples, input checks, QC, and its selected analysis; you do not submit separate sample or preprocessing jobs. The browser shows the input, output, and key settings for the selected module:

| Module | Additional input | Main results |
| --- | --- | --- |
| STAR + DESeq2 differential expression | At least two conditions in the sample sheet | Gene counts, DE table, PCA/volcano plots, QC |
| STAR + bcftools RNA SNV discovery | Single- or paired-end RNA reads and a reference | RNA-derived VCF and site summaries; not DNA genotypes |
| STAR + GATK ASE | Compatible DNA genotype VCF (with sample map if needed) | Per-allele RNA read counts at eligible DNA heterozygous sites |
| Trinity de novo transcriptome | Single- or paired-end RNA reads; no genome required for assembly | Transcript FASTA, assembly statistics, read-representation summary |

Review trimming, library strandedness, any module-specific filters, and the selected reference. For **DE and Trinity**, leave the strand setting on **Check a small alignment** unless you have a protocol-confirmed choice: the job maps up to 50,000 reads or read pairs from every sample with STAR and shows forward/reverse assigned-gene counts. It automatically selects forward or reverse only when all samples have strong, agreeing evidence. Balanced, low-count, intermediate, or disagreeing samples stop before full analysis with **Needs review**; the browser shows per-sample evidence and offers an evidence ZIP for three days. Check your library protocol, choose an explicit orientation, tick the manual-review confirmation, and create/submit a new job. An explicit choice that contradicts the check also needs confirmation. A balanced signal does **not** prove unstrandedness. This check does not block SNV or ASE, whose modules do not use stranded gene counts. The displayed biological-ploidy recommendation comes from the reference manifest; it does **not** measure your sample's ploidy or detect aneuploidy. If your sample's known ploidy differs, consult the lab maintainer before SNV/ASE analysis. The standard resource form permits 1–32 CPUs, 8–256 GB RAM, and 1 hour–30 days of walltime; your Slurm account or available nodes may be more restrictive. Click **Review and create job → Validate project**, then **Create Slurm job**. **This creates the script but does not submit the job.**

The browser shows the exact script path and a one-line submission command. The script is at `<personal-workspace>/projects/<project_folder>/results/<module>/<job-id>/rnaseq.sbatch`; the command uses the same job ID. In **Terminal on your Mac**, log in to Discovery normally with your own account:

```bash
ssh YOUR_NETID@discovery.dartmouth.edu
```

Enter your password in Terminal if prompted; never enter it in the browser. On Discovery, copy and run the exact `python3 .../scripts/submit_prepared.py <job-id>` command shown by RNA Atlas. **That one command submits the job** and prints its Slurm job ID; no second submission command or separate `id -un`/`klist` check is needed. It also verifies that this is your job and that its prepared files have not changed, so use it rather than typing a separate `sbatch` command. Do not submit the same prepared job twice. You can type `exit` after it confirms submission. Each job's read-only `_code/` snapshot is checksum-checked again on the compute node; do not edit or delete it while the job is queued or running. Relaunching the app does not replace code used by an already prepared job.

**Only if the command reports a missing DartFS credential:** Discovery login and DartFS file access are different checks. For example, [Dartmouth notes that SSH key login can succeed without a filesystem credential](https://services.dartmouth.edu/TDClient/1806/Portal/KB/Article/89203/Passwordless-SSH-login-to-research-servers); an earlier ticket can also expire. The submission command stops before submitting in that case and prints the exact `kinit YOUR_NETID@KIEWIT.DARTMOUTH.EDU` recovery command. Run it **on Discovery**, enter your password at its Terminal prompt, then repeat the same RNA Atlas submission command. If you see no credential error, do nothing extra.

Each job writes to `<personal-workspace>/projects/<project_folder>/results/<module>/<job-id>/`, including status and logs. Loading the same folder later retains earlier results. Result bundles up to 2 GB are available as ZIP downloads for three days after completion. Larger bundles and all underlying results remain on DartFS; the three-day browser window is **not** a DartFS deletion policy. Monitor your quota and follow your lab's retention rules.

The browser refreshes job status every 15 seconds while open and connected to Discovery. The app's SSH connection is separate from the Terminal session used to submit the job: exiting that Terminal does not disconnect the app. The SSH connection is configured to close after eight hours without use, and the browser connection cookie lasts 24 hours; a network change or sleep can disconnect it sooner. Reconnect when needed to see current status. Closing the browser or disconnecting pauses live updates, not the Slurm job. RNA Atlas does not automatically delete its job records, so older jobs remain visible while your workspace's `shared/service_registry/jobs/` records and project results are retained. The page shows five recent jobs first, with older jobs expandable. For a **newly submitted personal job**, RNA Atlas asks Slurm to email your own `NetID@dartmouth.edu` address when the job ends, fails, or reaches its time limit, even if the browser is closed. No email is sent for a job that was only prepared or rejected before Slurm accepted it. Delivery depends on Discovery's Slurm mail service; check job status in the app if a message does not arrive. Jobs already running when this update is installed do not gain email notifications retroactively.

Closing the browser or leaving Discovery after `sbatch` succeeds does **not** cancel the Slurm job. Reconnect using `mac/connect_discovery.command` if you need browser status updates later. Password-based login avoids the [specific macOS forwarded-ticket renewability problem](https://services.dartmouth.edu/TDClient/1806/Portal/KB/PrintArticle?ID=89203), but it does **not** by itself guarantee that a compute-node ticket will last through queue wait and runtime. The job checks for a ticket at startup; it does not renew one automatically. Until a password-submitted compute job and its credential lifetime have been verified on Discovery, do not assume long jobs are safe from DartFS ticket expiry.

## What this download does not include

The repo contains `mac/` (browser app and personal launcher), `discovery/` (pipeline code that the launcher copies to your private workspace), and `SOURCE_SHA256SUMS.txt`. It **does not** contain example FASTQs, the large reference genomes/STAR indexes, software runtimes, your reads, completed results, or anyone's credentials. The launcher checks access to shared reference/runtime files before opening the page.

**Validation:** Local tests and isolated service-account QA cover paired-end DE, RNA SNV, DNA-informed ASE, and a small Trinity run. Single-end support has local tests but no Discovery end-to-end result yet. Each personal job pins a checksum-verified pipeline-code snapshot. A member-owned end-to-end job and long-job compute-node ticket lifetime have not yet been verified; do not assume those are safe without that check. See `mac/PERSONAL.md` inside the extracted archive for the maintainer's handoff audit. Do not use RNA-derived variants for clinical decisions.
